/* Hydra Studio · subs-core.js
 * Pure logic of the Subtitles section (no After Effects, no DOM): reading and writing SRT, reading whisper.cpp's JSON,
 * tidying and wrapping the lines, finding the offline speech tools on the computer, building the command lines.
 * Tested with node (test/subs_test.js).
 */
(function (root) {
  "use strict";

  var ZW = "‌";

  function pad(n, w) { n = String(n); while (n.length < w) n = "0" + n; return n; }
  function fmtTime(sec, comma) {
    if (!(sec >= 0)) sec = 0;
    var ms = Math.round(sec * 1000), h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, s = Math.floor(ms / 1000) % 60;
    return pad(h, 2) + ":" + pad(m, 2) + ":" + pad(s, 2) + (comma === false ? "." : ",") + pad(ms % 1000, 3);
  }
  // "00:01:02,500" | "01:02.500" | "62.5" | "1:02" -> seconds, or NaN
  function parseTime(t) {
    t = String(t == null ? "" : t).trim().replace(",", ".");
    var m = /^(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)$/.exec(t), p;
    if (m) return (m[1] ? +m[1] * 3600 : 0) + +m[2] * 60 + +m[3];
    m = /^(\d+):(\d+(?:\.\d+)?)$/.exec(t);
    if (m) return +m[1] * 60 + +m[2];
    p = /^\d+(?:\.\d+)?$/.test(t) ? parseFloat(t) : NaN;
    return p;
  }

  // Persian letters only: the Arabic yeh / kaf that some tools write become the Persian ones
  function persianize(s) { return String(s).replace(/ي/g, "ی").replace(/ك/g, "ک").replace(/ى/g, "ی").replace(/[ً-ْـ]/g, ""); }

  // SRT and WebVTT -> [{ s, e, text }]  (text lines joined with \n)
  function parseSRT(text) {
    text = String(text || "").replace(/^﻿/, "").replace(/\r\n?/g, "\n");
    var blocks = text.split(/\n{2,}/), out = [], i, lines, k, m, s, e, body;
    for (i = 0; i < blocks.length; i++) {
      lines = blocks[i].split("\n").filter(function (l) { return l.length; });
      for (k = 0; k < lines.length; k++) {
        m = /^\s*([\d:.,]+)\s*-->\s*([\d:.,]+)/.exec(lines[k]);
        if (m) {
          s = parseTime(m[1]); e = parseTime(m[2]);
          body = lines.slice(k + 1).join("\n").replace(/<[^>]+>/g, "").trim();
          if (!isNaN(s) && !isNaN(e) && body) out.push({ s: s, e: Math.max(e, s + 0.05), text: body });
          break;
        }
      }
    }
    return out;
  }
  function toSRT(segs) {
    return segs.map(function (g, i) { return (i + 1) + "\n" + fmtTime(g.s) + " --> " + fmtTime(g.e) + "\n" + g.text + "\n"; }).join("\n");
  }

  // whisper.cpp "-oj" output
  function isNoise(t) {
    t = t.trim();
    return !t || /^[\[\(♪♫\s\.\-]*$/.test(t) || /^[\[\(].*[\]\)]$/.test(t) && t.length < 40 && /blank|music|silence|noise|موسیقی|سکوت/i.test(t);
  }
  function parseWhisperJson(src) {
    var j = src, list, out = [], i, o, s, e, t;
    if (typeof src === "string") { try { j = JSON.parse(src.replace(/^﻿/, "")); } catch (e0) { return []; } }
    list = (j && (j.transcription || j.segments)) || [];
    for (i = 0; i < list.length; i++) {
      o = list[i];
      if (o.offsets) { s = o.offsets.from / 1000; e = o.offsets.to / 1000; }
      else if (o.timestamps) { s = parseTime(o.timestamps.from); e = parseTime(o.timestamps.to); }
      else { s = o.start; e = o.end; }
      t = persianize(String(o.text || "")).replace(/\s+/g, " ").trim();
      if (isNaN(s) || isNaN(e) || isNoise(t)) continue;
      out.push({ s: s, e: Math.max(e, s + 0.05), text: t });
    }
    return out;
  }

  // two balanced lines at a word boundary when the text is longer than max characters
  function wrapLines(text, max) {
    text = String(text).replace(/\s*\n\s*/g, " ").replace(/\s+/g, " ").trim();
    if (!max || text.length <= max) return text;
    var words = text.split(" "), best = -1, bestD = 1e9, i, a, d;
    if (words.length < 2) return text;
    for (i = 1; i < words.length; i++) {
      a = words.slice(0, i).join(" ").length;
      d = Math.abs(a - (text.length - a - 1));
      if (d < bestD) { bestD = d; best = i; }
    }
    return words.slice(0, best).join(" ") + "\n" + words.slice(best).join(" ");
  }

  // gaps closed, too-short lines stretched, overlaps trimmed: { closeGaps (s), minDur (s), maxChars }
  function tidy(segs, o) {
    o = o || {};
    var out = segs.map(function (g) { return { s: g.s, e: g.e, text: g.text }; }).sort(function (a, b) { return a.s - b.s; }), i, n;
    for (i = 0; i < out.length; i++) {
      if (o.minDur && out[i].e - out[i].s < o.minDur) out[i].e = out[i].s + o.minDur;
      n = out[i + 1];
      if (n) {
        if (out[i].e > n.s) out[i].e = n.s;
        else if (o.closeGaps && n.s - out[i].e <= o.closeGaps) out[i].e = n.s;
      }
      if (o.maxChars) out[i].text = wrapLines(out[i].text, o.maxChars);
    }
    return out.filter(function (g) { return g.e > g.s; });
  }

  // hint words: "ارز دیجیتال، تتر USDT" -> ["ارز", "دیجیتال", "تتر"] (Persian words only)
  function parseHints(text) {
    var out = [], seen = {}, m, re = /[\u0621-\u064A\u067E\u0686\u0698\u06A9\u06AF\u06CC\u200c]+/g;
    text = persianize(String(text || ""));
    while ((m = re.exec(text))) { var w = m[0].replace(/^\u200c+|\u200c+$/g, ""); if (w.length >= 3 && !seen[w]) { seen[w] = 1; out.push(w); } }
    return out;
  }
  // "wrong = right" per line; whole words only
  var L2 = "\u0621-\u064A\u0671-\u06D3\u200c";
  function parseRules(text) {
    return String(text || "").split(/\n+/).map(function (l) { var i = l.indexOf("="); return i > 0 ? [persianize(l.slice(0, i)).trim(), persianize(l.slice(i + 1)).trim()] : null; }).filter(function (r) { return r && r[0] && r[1] !== undefined; });
  }
  function applyRules(text, rules) {
    var i, a, re;
    for (i = 0; i < rules.length; i++) {
      a = rules[i][0].replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\s+/g, "\\s+");
      re = new RegExp("(^|[^" + L2 + "])" + a + "(?![" + L2 + "])", "g");
      text = text.replace(re, function (m, pre) { return pre + rules[i][1]; });
    }
    return text;
  }

  // ---- finding the tools
  var WHISPER_NAMES = ["whisper-cli", "whisper-cpp", "whisper"];
  var MODEL_RANK = ["large-v3", "large", "medium", "small", "base", "tiny"];
  function modelRank(name) {
    var i;
    for (i = 0; i < MODEL_RANK.length; i++) if (name.indexOf(MODEL_RANK[i]) >= 0) return i;
    return 9;
  }
  // env: { fs, path, platform, dataDir, pathEnv, home }
  function findTools(env) {
    var fs = env.fs, path = env.path, win = env.platform === "win32", ext = win ? ".exe" : "";
    var dirs = [], seen = {}, found = { whisper: "", ffmpeg: "", models: [], speechDir: path.join(env.dataDir, "speech") };
    function addDir(d) { if (d && !seen[d]) { seen[d] = 1; dirs.push(d); } }
    function has(p) { try { return fs.existsSync(p) && fs.statSync(p).isFile(); } catch (e) { return false; } }
    addDir(found.speechDir); addDir(path.join(found.speechDir, "bin")); addDir(path.join(found.speechDir, "ffmpeg")); addDir(path.join(found.speechDir, "whisper"));
    if (!win) ["/opt/homebrew/bin", "/usr/local/bin", "/opt/local/bin", "/usr/bin"].forEach(addDir);
    String(env.pathEnv || "").split(win ? ";" : ":").forEach(addDir);
    dirs.forEach(function (d) {
      var i, p;
      if (!found.whisper) {
        for (i = 0; i < WHISPER_NAMES.length; i++) { p = path.join(d, WHISPER_NAMES[i] + ext); if (has(p)) { found.whisper = p; break; } }
        if (!found.whisper && d.indexOf(found.speechDir) === 0) { p = path.join(d, "main" + ext); if (has(p)) found.whisper = p; }   // the old name of whisper-cli, only inside our own folder
      }
      if (!found.ffmpeg) { p = path.join(d, "ffmpeg" + ext); if (has(p)) found.ffmpeg = p; }
    });
    [found.speechDir, path.join(found.speechDir, "models"), path.join(found.speechDir, "model")].forEach(function (d) {
      var names = [];
      try { names = fs.readdirSync(d); } catch (e) { names = []; }
      names.forEach(function (n) { if (/^ggml-.*\.bin$/i.test(n) && !/^ggml-(silero|vad)/i.test(n) && has(path.join(d, n))) found.models.push({ name: n, path: path.join(d, n), mb: Math.round(fs.statSync(path.join(d, n)).size / 1048576) }); });
    });
    found.models.sort(function (a, b) { return modelRank(a.name) - modelRank(b.name) || a.name.localeCompare(b.name); });
    return found;
  }
  function missing(t) {
    var m = [];
    if (!t.whisper) m.push("whisper");
    if (!t.ffmpeg) m.push("ffmpeg");
    if (!t.models.length) m.push("model");
    return m;
  }

  // ---- command lines
  function ffmpegArgs(media, wav, start, dur) {
    var a = ["-y", "-hide_banner", "-nostdin"];
    if (start > 0) a.push("-ss", String(start));
    a.push("-i", media);
    if (dur > 0) a.push("-t", String(dur));
    a.push("-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", wav);
    return a;
  }
  function whisperArgs(o) {
    var a = ["-m", o.model, "-f", o.wav, "-l", o.lang || "fa", "-oj", "-of", o.out, "-pp"];
    if (o.threads) a.push("-t", String(o.threads));
    if (o.maxLen) a.push("-ml", String(o.maxLen), "-sow");
    if (o.beam !== 0) a.push("-bs", String(o.beam || 5));                         // beam search: slower, clearly fewer wrong words
    if (o.prompt) a.push("--prompt", o.prompt);
    return a;
  }
  function parseProgress(line) {
    var m = /progress\s*=\s*(\d+)\s*%/.exec(line);
    return m ? +m[1] : null;
  }
  function parseClock(line) {
    var m = /time=(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(line);
    return m ? +m[1] * 3600 + +m[2] * 60 + +m[3] : null;
  }

  root.HydraSubs = {
    fmtTime: fmtTime, parseTime: parseTime, parseSRT: parseSRT, toSRT: toSRT, parseWhisperJson: parseWhisperJson, persianize: persianize,
    wrapLines: wrapLines, tidy: tidy, parseHints: parseHints, parseRules: parseRules, applyRules: applyRules, findTools: findTools, missing: missing, ffmpegArgs: ffmpegArgs, whisperArgs: whisperArgs,
    parseProgress: parseProgress, parseClock: parseClock, ZW: ZW
  };
  if (typeof module !== "undefined" && module.exports) module.exports = root.HydraSubs;
})(typeof window !== "undefined" ? window : global);
