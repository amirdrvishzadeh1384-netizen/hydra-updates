/* Hydra Studio · studio-spell.js
 * The Spell section: reads every text layer (active comp, selected layers or the whole project),
 * marks the spelling problems, lets you fix them one by one or all the sure ones at once, and writes the result back.
 * The checking itself is spell.js; reading / writing the texts is host.jsx (ops_textScan / ops_textApply / ops_textReveal).
 */
(function () {
  "use strict";
  var ST = { spoken: true, mode: "comp", items: null, summary: null, engine: null, loading: false, loadErr: "", only: true, busy: false, sel: null, words: [], scanned: false, skipped: 0, comps: 0 };
  var X = null;   // what the panel gives us (see init)

  var MODES = [["comp", "Open comp"], ["selected", "Selected layers"], ["project", "Whole project"]];
  var MODES_PP = [["comp", "This sequence"], ["selected", "Selected clips"], ["project", "All sequences"]];
  function PP() { return !!(X && X.ppro); }
  function APP() { return X && X.app ? X.app : "After Effects"; }
  var PPNOTE = "In Premiere Pro this reads the text of Graphics clips (the Type tool, Essential Graphics, .mogrt titles). Old Legacy Titles and the captions already on the timeline are not reachable by any panel: for captions export them as .srt (Captions panel → Export), then fix them in the Subtitles tab (“open an .srt file you already have”) and import the saved file back.";
  function SHORT() { return PP() ? "Premiere" : "AE"; }
  var KIND_LABEL = { arabic: "Arabic letter", zwnj: "Half-space", suffix: "Half-space", space: "Spacing", punct: "Punctuation", repeat: "Repeated", unknown: "Unknown word" };
  var CAP = 400;   // texts drawn at once (big projects: the rest is one click away)

  function wordsFile() { return X.files && X.files.data ? X.files.path.join(X.files.data, "spell-words.json") : ""; }
  function loadWords() {
    try { var f = wordsFile(); if (f && X.files.fs.existsSync(f)) return JSON.parse(X.files.fs.readFileSync(f, "utf8")) || []; } catch (e) {}
    return [];
  }
  function saveWords() { try { var f = wordsFile(); if (f) { X.files.mkdirp(X.files.data); X.files.fs.writeFileSync(f, JSON.stringify(ST.words, null, 1)); } } catch (e) {} }

  function readText(p) {
    try { if (X.files && X.files.fs) return Promise.resolve(X.files.fs.readFileSync(p, "utf8")); } catch (e) {}
    return new Promise(function (res, rej) {
      var x = new XMLHttpRequest();
      x.open("GET", "file://" + p.replace(/\\/g, "/").replace(/^([A-Za-z]:)/, "/$1"));
      x.onload = function () { if (x.responseText) res(x.responseText); else rej(new Error("dictionary file not found")); };
      x.onerror = function () { rej(new Error("dictionary file not found")); };
      x.send();
    });
  }
  function tick() { return new Promise(function (r) { setTimeout(r, 0); }); }

  // the dictionary lives next to the panel (client/dict); if it is missing there, a copy downloaded into the data folder is used
  var DICT_SHA = { "fa.aff": "dba0980816354ad969aa46dda0c040eeebda4a9381be331e17eae8647a2a1e1c", "fa.dic": "3454caf8c83dfe008ef554c052e23897425a53bc1546cc3ea40a63f6738c685b" };
  function dictDirs() { var d = [X.extDir + "/client/dict/"]; if (X.files && X.files.data) d.push(X.files.path.join(X.files.data, "dict") + "/"); return d; }

  function readPair(i, dirs) {
    if (i >= dirs.length) return Promise.reject(new Error("the Persian dictionary files are not on this computer"));
    return Promise.all([readText(dirs[i] + "fa.aff"), readText(dirs[i] + "fa.dic")]).catch(function () { return readPair(i + 1, dirs); });
  }

  // the dictionary is read once, the first time the section opens (about two seconds)
  function loadEngine() {
    if (ST.engine) return Promise.resolve(ST.engine);
    if (ST.loading) return ST.loading;
    ST.loadErr = "";
    ST.loading = tick().then(function () {
      if (!window.HydraNspell || !window.HydraSpell) throw new Error("the spell checker files are missing");
      return readPair(0, dictDirs());
    }).then(function (t) {
      return tick().then(function () {
        var e = window.HydraSpell.create(window.HydraNspell, t[0], t[1]);
        ST.words = loadWords(); e.addWords(ST.words); e.setSpoken(ST.spoken);
        ST.engine = e; ST.loading = false;
        return e;
      });
    }).catch(function (err) { ST.loading = false; ST.loadErr = String(err && err.message || err); throw err; });
    return ST.loading;
  }

  // downloads the dictionary from the same GitHub place the updates come from (checked against a fixed checksum)
  async function downloadDict() {
    var U = window.HydraUpdate, cfg = window.HYDRA_UPDATE || {}, D = X.deps, crypto = D && D.crypto, bases = [], names = ["fa.aff", "fa.dic"], got = {}, i, j, last = "";
    if (!U || !D || !X.files) throw new Error("this panel can’t download files here");
    (cfg.feeds || []).forEach(function (f) { var b = String(f).replace(/update\.json.*$/, "") + "dict/"; if (bases.indexOf(b) < 0) bases.push(b); });
    for (j = 0; j < names.length; j++) {
      for (i = 0; i < bases.length && !got[names[j]]; i++) {
        try {
          var buf = await U.httpGet(D, bases[i] + names[j], { maxBytes: 8 * 1048576, totalMs: 90000 });
          var sha = crypto.createHash("sha256").update(buf).digest("hex");
          if (sha !== DICT_SHA[names[j]]) { last = "the downloaded " + names[j] + " is damaged"; continue; }
          got[names[j]] = buf;
        } catch (e) { last = String(e && (e.detail || e.message) || e); }
      }
      if (!got[names[j]]) throw new Error("couldn’t download " + names[j] + " (" + (last || "no connection") + "). Check the internet or try a VPN, then try again.");
    }
    var dir = X.files.path.join(X.files.data, "dict");
    X.files.mkdirp(dir);
    names.forEach(function (n) { X.files.fs.writeFileSync(X.files.path.join(dir, n), got[n]); });
    ST.engine = null; ST.loading = false;
    return loadEngine();
  }

  function trouble(it) { return it.issues.length > 0; }
  function sureCount(it) { return it.issues.filter(function (i) { return i.fix !== null && i.fix !== undefined; }).length; }

  // ---- scanning
  async function scan(box) {
    if (ST.busy) return;
    if (!X.ready()) { X.toast(X.connected() ? "Not connected · click the status above" : "Open this panel inside " + APP(), true); return; }
    ST.busy = true; ST.sel = null; ST.summary = "Reading the texts…"; draw(box);
    try {
      var eng = await loadEngine();
      var r = await X.cep.call("ops_textScan", ST.mode === "comp" ? "active" : ST.mode);
      if (!r.ok) { X.toast(r.error || "Couldn’t read the texts", true); ST.summary = null; return; }
      ST.comps = r.comps; ST.skipped = r.skipped || 0; ST.items = [];
      var list = r.texts || [], i, it, t0 = Date.now();
      for (i = 0; i < list.length; i++) {
        it = list[i]; it.orig = it.text; it.cur = it.text; it.done = false;
        it.issues = eng.analyze(it.cur);
        ST.items.push(it);
        if (i % 25 === 24) { ST.summary = "Checking… " + (i + 1) + " of " + list.length; drawSummary(box); await tick(); }
      }
      ST.scanned = true; ST.summary = null;
    } catch (e) {
      X.toast("Spell check failed: " + ((e && e.message) || e), true);
      ST.summary = null;
    } finally { ST.busy = false; draw(box); }
  }

  function recheck(it) { it.issues = ST.engine.analyze(it.cur); }

  function changed() { return (ST.items || []).filter(function (it) { return it.cur !== it.orig; }); }

  async function applyItems(items, box) {
    if (!items.length || ST.busy) return;
    if (!X.ready()) { X.toast("Not connected · click the status above", true); return; }
    ST.busy = true; draw(box);
    try {
      var fixes = items.map(function (it) { return { compId: it.compId, li: it.li, layer: it.layer, old: it.orig, text: it.cur }; });
      var r = await X.cep.call("ops_textApply", JSON.stringify(fixes));
      if (!r.ok) { X.toast(r.error || "Couldn’t write the corrections", true); return; }
      items.forEach(function (it) { it.orig = it.cur; it.done = true; recheck(it); });
      X.toast("Corrected " + r.applied + (r.applied === 1 ? " text" : " texts") + (r.missed ? " · " + r.missed + " not found (changed since the scan?)" : "") + (PP() ? " · Undo in Premiere goes one text at a time" : " · one Undo in After Effects"));
    } catch (e) { X.toast(String((e && e.message) || e), true); }
    finally { ST.busy = false; draw(box); }
  }

  // ---- drawing
  function drawSummary(box) {
    var el = box.querySelector(".sp-sum");
    if (el) el.textContent = ST.summary || "";
  }

  function textView(it, box) {
    var wrap = X.h("div", { class: "sp-text", dir: "auto" }), t = it.cur, pos = 0, sel = ST.sel;
    it.issues.forEach(function (iss, n) {
      if (iss.start > pos) wrap.appendChild(document.createTextNode(t.slice(pos, iss.start).replace(/\r/g, "\n")));
      var label = t.slice(iss.start, iss.end) || "•";
      if (iss.start === iss.end) label = "•";
      var m = X.h("button", { type: "button", class: "sp-bad k-" + iss.kind + (sel && sel.it === it && sel.n === n ? " on" : "") }, [label.replace(/\r/g, "↵")]);
      if (/^\s+$/.test(label)) m.textContent = "•";
      m.addEventListener("click", function () { ST.sel = (sel && sel.it === it && sel.n === n) ? null : { it: it, n: n }; draw(box); });
      wrap.appendChild(m);
      pos = iss.end;
    });
    if (pos < t.length) wrap.appendChild(document.createTextNode(t.slice(pos).replace(/\r/g, "\n")));
    return wrap;
  }

  function detail(it, box) {
    var iss = it.issues[ST.sel.n], d = X.h("div", { class: "sp-detail" }), row, sugs = [], eng = ST.engine;
    if (!iss) return d;
    d.appendChild(X.h("div", { class: "sp-msg" }, [iss.msg || ""]));
    row = X.h("div", { class: "sp-sugs" });
    if (iss.fix !== null && iss.fix !== undefined) sugs.push(iss.fix);
    else sugs = eng.suggest(iss.word);
    sugs.forEach(function (s) {
      var shown = s === "" ? "remove" : (/^\s+$/.test(s) ? "single space" : s);
      var b = X.h("button", { type: "button", class: "sp-sug" }, [shown]);
      b.addEventListener("click", function () { it.cur = eng.applyOne(it.cur, iss, s); recheck(it); ST.sel = null; draw(box); });
      row.appendChild(b);
    });
    if (!sugs.length) row.appendChild(X.h("span", { class: "sp-none" }, ["No suggestion · type it yourself in " + APP() + ", or keep it"]));
    d.appendChild(row);
    var acts = X.h("div", { class: "sp-acts" });
    var keep = X.h("button", { type: "button", class: "sp-link" }, ["Keep this"]);
    keep.addEventListener("click", function () { it.issues.splice(ST.sel.n, 1); ST.sel = null; draw(box); });
    acts.appendChild(keep);
    if (iss.kind === "unknown") {
      var add = X.h("button", { type: "button", class: "sp-link" }, ["Add to my words"]);
      add.addEventListener("click", function () {
        var w = iss.word; if (ST.words.indexOf(w) < 0) ST.words.push(w); saveWords(); eng.addWords([w]);
        ST.items.forEach(recheck); ST.sel = null; X.toast("“" + w + "” is now one of your words"); draw(box);
      });
      acts.appendChild(add);
    }
    d.appendChild(acts);
    return d;
  }

  function fmtT(t) { t = Math.max(0, t || 0); var m = Math.floor(t / 60), s = Math.floor(t % 60); return m + ":" + (s < 10 ? "0" : "") + s; }

  function card(it, box) {
    var c = X.h("div", { class: "sp-card" + (it.cur !== it.orig ? " edited" : "") + (it.done && !trouble(it) ? " clean" : "") });
    var head = X.h("div", { class: "sp-head" });
    var title = X.h("button", { type: "button", class: "sp-where", title: "Open it in " + APP() }, [it.comp + "  ·  " + it.layer + "  ·  " + fmtT(it.t)]);
    title.addEventListener("click", function () { X.cep.call("ops_textReveal", it.compId, it.li, it.layer, it.t).then(function (r) { if (!r.ok) X.toast(r.error || "Couldn’t open it", true); }); });
    head.appendChild(title);
    c.appendChild(head);
    c.appendChild(textView(it, box));
    if (ST.sel && ST.sel.it === it) c.appendChild(detail(it, box));
    var foot = X.h("div", { class: "sp-foot" });
    var n = sureCount(it);
    if (n) {
      var fx = X.h("button", { type: "button", class: "sp-link" }, ["Fix " + n + " sure " + (n === 1 ? "one" : "ones")]);
      fx.addEventListener("click", function () { it.cur = ST.engine.applySure(it.cur, it.issues); recheck(it); ST.sel = null; draw(box); });
      foot.appendChild(fx);
    }
    if (it.cur !== it.orig) {
      var rev = X.h("button", { type: "button", class: "sp-link" }, ["Undo my changes"]);
      rev.addEventListener("click", function () { it.cur = it.orig; recheck(it); ST.sel = null; draw(box); });
      foot.appendChild(rev);
      var ap = X.h("button", { type: "button", class: "sp-apply" }, ["Apply in " + SHORT()]);
      ap.addEventListener("click", function () { applyItems([it], box); });
      foot.appendChild(ap);
    } else if (it.done) {
      foot.appendChild(X.h("span", { class: "sp-ok" }, ["Applied"]));
    }
    c.appendChild(foot);
    return c;
  }

  function draw(box) {
    box.innerHTML = "";
    var root = X.h("div", { class: "spell", style: X.colorVars(X.rgb) });
    root.appendChild(X.h("p", { class: "tools-lead" }, ["Finds Persian spelling mistakes in every text of your project. Persian only: Arabic letters, digits and vowel marks are reported as mistakes too. Spoken forms are accepted unless you switch that off."]));

    var seg = X.h("div", { class: "sp-seg" });
    (PP() ? MODES_PP : MODES).forEach(function (m) {
      var b = X.h("button", { type: "button", class: m[0] === ST.mode ? "on" : "" }, [m[1]]);
      b.addEventListener("click", function () { if (ST.busy) return; ST.mode = m[0]; draw(box); });
      seg.appendChild(b);
    });
    root.appendChild(seg);

    var go = X.h("button", { type: "button", class: "sp-scan" + (ST.busy ? " busy" : "") }, [ST.busy ? "Working…" : (ST.scanned ? "Scan again" : "Scan texts")]);
    if (ST.busy) go.disabled = true;
    go.addEventListener("click", function () { scan(box); });
    root.appendChild(go);

    var sp = X.h("label", { class: "sp-only sp-spoken" }, [X.h("input", { type: "checkbox" }), " Allow spoken Persian (خونه، می‌رم، هستش)"]);
    sp.firstChild.checked = ST.spoken;
    sp.firstChild.addEventListener("change", function () {
      ST.spoken = this.checked;
      if (ST.engine) { ST.engine.setSpoken(ST.spoken); (ST.items || []).forEach(function (it) { it.issues = ST.engine.analyze(it.cur); }); ST.sel = null; }
      draw(box);
    });
    root.appendChild(sp);
    var sum = X.h("div", { class: "sp-sum" }, [ST.summary || ""]);
    root.appendChild(sum);
    if (ST.loading) root.appendChild(X.h("div", { class: "sp-note" }, ["Loading the Persian dictionary (a couple of seconds, only the first time)…"]));
    if (ST.loadErr) {
      root.appendChild(X.h("div", { class: "sp-note err" }, ["Couldn’t load the dictionary: " + ST.loadErr]));
      var dl = X.h("button", { type: "button", class: "sp-main go" + (ST.dl ? " busy" : "") }, [ST.dl ? "Downloading…" : "Download the dictionary"]);
      if (ST.dl) dl.disabled = true;
      dl.addEventListener("click", function () {
        ST.dl = true; draw(box);
        downloadDict().then(function () { ST.dl = false; ST.loadErr = ""; X.toast("Dictionary ready"); draw(box); }).catch(function (e) { ST.dl = false; ST.loadErr = String(e && e.message || e); draw(box); });
      });
      root.appendChild(dl);
    }

    if (ST.scanned && ST.items) {
      var bad = ST.items.filter(trouble), edits = changed(), sure = 0, shown;
      ST.items.forEach(function (it) { sure += sureCount(it); });
      var total = bad.reduce(function (a, it) { return a + it.issues.length; }, 0);
      root.appendChild(X.h("div", { class: "sp-stats" }, [
        ST.items.length + (ST.items.length === 1 ? " text" : " texts") + " in " + ST.comps + (PP() ? (ST.comps === 1 ? " sequence" : " sequences") : (ST.comps === 1 ? " comp" : " comps")) + "  ·  ",
        X.h("b", {}, [total ? total + (total === 1 ? " thing to check" : " things to check") : "no problems found"]),
        ST.skipped ? "  ·  " + ST.skipped + " driven by expressions (skipped)" : ""
      ]));
      if (PP() && !ST.items.length) root.appendChild(X.h("div", { class: "sp-note" }, ["No Graphics text found. " + PPNOTE]));
      var bar = X.h("div", { class: "sp-bar" });
      if (sure) {
        var all = X.h("button", { type: "button", class: "sp-main" }, ["Fix all " + sure + " sure ones"]);
        all.addEventListener("click", function () { ST.items.forEach(function (it) { if (sureCount(it)) { it.cur = ST.engine.applySure(it.cur, it.issues); recheck(it); } }); ST.sel = null; draw(box); });
        bar.appendChild(all);
      }
      if (edits.length) {
        var wr = X.h("button", { type: "button", class: "sp-main go" }, ["Apply " + edits.length + (edits.length === 1 ? " change" : " changes") + " in " + SHORT()]);
        wr.addEventListener("click", function () { applyItems(edits, box); });
        bar.appendChild(wr);
      }
      var only = X.h("label", { class: "sp-only" }, [X.h("input", { type: "checkbox" }), " Only texts with a problem"]);
      only.firstChild.checked = ST.only;
      only.firstChild.addEventListener("change", function () { ST.only = this.checked; draw(box); });
      bar.appendChild(only);
      root.appendChild(bar);

      shown = ST.items.filter(function (it) { return !ST.only || trouble(it) || it.cur !== it.orig || it.done; });
      var list = X.h("div", { class: "sp-list" });
      shown.slice(0, CAP).forEach(function (it) { list.appendChild(card(it, box)); });
      if (shown.length > CAP) list.appendChild(X.h("div", { class: "sp-note" }, ["Showing the first " + CAP + " of " + shown.length + ". Fix these, then scan again."]));
      if (!shown.length) list.appendChild(X.h("div", { class: "sp-empty" }, ["Everything reads clean."]));
      root.appendChild(list);
    } else if (!ST.busy) {
      if (PP()) root.appendChild(X.h("div", { class: "sp-note" }, [PPNOTE]));
      root.appendChild(X.h("div", { class: "sp-note" }, ["Texts that are English only, numbers and names written in Latin letters are left alone. Words that are right but not in the dictionary (brand names, people) can be added with “Add to my words”."]));
    }
    box.appendChild(root);
  }

  window.HydraSpellUI = {
    reset: function () { ST.items = null; ST.scanned = false; ST.sel = null; ST.summary = null; },
    init: function (ctx) { X = ctx; },
    // the loaded checker (for the Subtitles section), or null
    engine: function () { return loadEngine().then(function () { return ST.engine; }, function () { return null; }); },
    ready: function () { return !!X; },
    download: downloadDict,
    error: function () { return ST.loadErr; },
    render: function (box) {
      var p = loadEngine().catch(function () {});
      draw(box);
      p.then(function () { if (box.isConnected && !ST.busy) draw(box); });
    },
    _state: ST
  };
})();
