/* Hydra Studio · spell.js
 * Persian spell checker for the texts of a video: the Lilak dictionary (Hunspell, Apache-2.0) through nspell,
 * plus rules that a dictionary can not see: Arabic letters (ي ك), the half-space of می‌ / ها, spacing, ? , ; in Persian text,
 * a word typed twice. Pure logic: no After Effects and no DOM here, so it is tested with node.
 *   var sp = HydraSpell.create(nspellFunction, affText, dicText);
 *   sp.analyze("متن")  -> [{ kind, start, end, word, fix, msg }]
 *   sp.suggest("کلمع") -> ["کلمه", ...]
 */
(function (root) {
  "use strict";

  var ZW = "\u200c";
  var LET = "\u0621-\u064A\u0640\u064B-\u0652\u0671-\u06D3\u06FA-\u06FF";   // Persian / Arabic letters, tatweel, marks
  var WORD = new RegExp("[" + LET + ZW + "]+", "g");
  var HASLET = new RegExp("[" + LET + "]");
  var ARABIC = { "\u064A": "\u06CC", "\u0643": "\u06A9", "\u0649": "\u06CC", "\u0629": "\u0647" };
  var DIAC = /[\u064B-\u0652\u0640]/g;                       // Arabic vowel marks and the tatweel: not Persian
  var ARDIG = { "\u0660": "\u06F0", "\u0661": "\u06F1", "\u0662": "\u06F2", "\u0663": "\u06F3", "\u0664": "\u06F4", "\u0665": "\u06F5", "\u0666": "\u06F6", "\u0667": "\u06F7", "\u0668": "\u06F8", "\u0669": "\u06F9" };
  // look-alike / sound-alike letters, the likeliest confusion first: ظ→ض ز ذ · ث→س ص · ط→ت · ح→ه · غ→ق · ع→ا · ئ→ی
  var CONF = { "\u0638": "\u0636\u0632\u0630", "\u0636": "\u0638\u0632\u0630", "\u0632": "\u0630\u0636\u0638", "\u0630": "\u0632\u0636\u0638", "\u062B": "\u0633\u0635", "\u0633": "\u0635\u062B", "\u0635": "\u0633\u062B", "\u0637": "\u062A", "\u062A": "\u0637", "\u062D": "\u0647", "\u0647": "\u062D", "\u063A": "\u0642", "\u0642": "\u063A", "\u0639": "\u0627", "\u0627": "\u0639", "\u06CC": "\u0626", "\u0626": "\u06CC", "\u067E": "\u0628", "\u0628": "\u067E", "\u0686": "\u062C", "\u062C": "\u0686" };

  var MSG = {
    arabic: "Arabic letter, digit or mark (ي ك ة ٠-٩ ً) instead of the Persian one",
    zwnj: "Needs a half-space (نیم‌فاصله)",
    suffix: "A suffix (ها، ترین) is joined with a half-space",
    space: "Extra or missing space",
    punct: "Persian punctuation is used in Persian text",
    repeat: "The same word is typed twice",
    unknown: "Not in the dictionary"
  };

  function create(nspellFn, aff, dic) {
    var sp = nspellFn(aff, dic), cache = {}, sugCache = {}, ignore = {};

    function ok(w) {
      if (cache[w] !== undefined) return cache[w];
      var r = false;
      try { r = sp.correct(w); } catch (e) { r = true; }
      cache[w] = r;
      return r;
    }
    function norm(w) {
      var out = "", i;
      for (i = 0; i < w.length; i++) out += ARABIC[w.charAt(i)] || w.charAt(i);
      return out;
    }
    function trimZ(w) { return w.replace(/^\u200c+|\u200c+$/g, ""); }

    function addWords(list) { (list || []).forEach(function (w) { w = String(w || "").trim(); if (!w) return; ignore[w] = 1; ignore[norm(w)] = 1; cache = {}; }); }
    function isIgnored(w) { return !!(ignore[w] || ignore[norm(w)] || ignore[w.replace(DIAC, "")]); }


    // ---- spoken Persian (خونه، هستش، می‌رم): never reported as a mistake while "allow spoken forms" is on
    var spokenOn = true, spokenCache = {}, SPOKEN = null;
    function buildSpoken() {
      var set = {}, i, j, k, stems, ends, pre, pr, P1 = ["م", "ت", "ش", "مون", "تون", "شون"], ex;
      function add(x) { set[x] = 1; }
      // verbs: spoken present / subjunctive / past forms, with and without می / نمی / ب / ن
      ends = ["م", "ی", "ه", "یم", "ین", "ن"];                       // م ی ه یم ین ن
      stems = ["دون", "خوا", "گ", "ر", "ش", "د", "تون", "ذار", "زار", "مون", "خون", "رسون", "بیا", "آ", "برن", "نشون", "بذار"];
      // دون خوا گ ر ش د تون ذار زار مون خون رسون بیا آ برن نشون بذار
      pre = ["", "می", "نمی", "ب", "ن"];
      for (i = 0; i < stems.length; i++) for (j = 0; j < pre.length; j++) for (k = 0; k < ends.length; k++) {
        add(pre[j] + stems[i] + ends[k]);
        add(pre[j] + stems[i] + "د");                                                                       // ـد : میخواد، بخواد
      }
      // past: اومد خوند موند دونست ... with the personal endings
      ["اومد", "خوند", "موند", "دونست", "رسوند", "نشوند", "ذاشت", "زاشت", "برد", "خورد"].forEach(function (st) {
        add(st); ["م", "ی", "یم", "ین", "ن"].forEach(function (e) { add(st + e); add("ن" + st + e); add("ن" + st); });
      });
      ["هستش", "هسش", "نیس", "نیسش", "هسن", "هسیم", "هسین"].forEach(add);   // هستش ...
      // prepositions with the short pronoun: ازم ازت ازش بهش باهاش برات واسه‌ش روش توش ...
      ["از", "به", "باها", "برا", "واس", "واسه", "رو", "تو", "پیش", "با", "بهم", "بین", "در"].forEach(function (pp) {
        P1.forEach(function (c) { add(pp + c); add(pp + c + "و"); });
      });
      // frequent spoken words and forms
      ("اون اونا اونجا اونجوری اینجوری اینطوری اونطوری چیکار چیکاره چطوری چجوری چیه کیه کجاست کجایی یه اینا اونا اینم اونم اونو اینو آره آره باشه مرسی داداش آبجی بیخیال اصن اصلن هیچی هیشکی هیچکی همش همهم همچی واسه اگه آخه یهو یواش بهتره خیلیا بعضیا چیزا همها جون مامان بابا بچها دوستام نگری خفن شیک ماشینش").split(" ").forEach(add);
      return set;
    }
    // ---- colloquial -> formal: the spoken word is turned into its written form and the dictionary has the last word.
    // میاد -> می‌آید، میوفتن -> می‌افتند، میاره -> می‌آورد، بذار -> بگذار، گفتین -> گفتید، دونستم -> دانستم
    var STRIP = ["رو", "و", "مون", "تون", "شون", "م", "ت", "ش", "ی", "ها", "ه", "ا"];
    var END_MAP = { "ه": ["د", "ید"], "د": ["د", "ید"], "ن": ["ند", "یند"], "ین": ["ید"], "م": ["م", "یم"], "ی": ["ی", "یی"], "یم": ["یم"], "ید": ["ید"] };
    var END_KEYS = ["ین", "ید", "یم", "ه", "د", "ن", "م", "ی"];
    var STEM_EXACT = {
      "ا": ["آ", "آی"], "یا": ["یا", "یای"], "ار": ["آور"], "یار": ["یاور"], "ر": ["رو"], "ش": ["شو"], "گ": ["گو"], "د": ["ده"],
      "دون": ["دان"], "تون": ["توان"], "خوا": ["خواه"], "ذار": ["گذار"], "زار": ["گذار"], "شین": ["نشین"], "نشین": ["نشین"],
      "رسون": ["رسان"], "مون": ["مان"], "خون": ["خوان", "خان"], "برن": ["برن"]
    };
    var START_RULES = [[/^او/, ["آ", "ا"]], [/^و(?=[^\u0627\u0648\u06CC\u0622])/, ["ا", "آ"]], [/^یو/, ["یا"]], [/^ذا(?=[رش])/, ["گذا"]], [/^زا(?=[رش])/, ["گذا"]], [/^شین/, ["نشین"]], [/^فت/, ["افت"]]];
    function stemAlts(s) {
      var out = [s], i, j, r, t, u, ex = STEM_EXACT[s];
      if (ex) for (i = 0; i < ex.length; i++) out.push(ex[i]);
      for (i = 0; i < START_RULES.length; i++) {
        if (START_RULES[i][0].test(s)) for (j = 0; j < START_RULES[i][1].length; j++) out.push(s.replace(START_RULES[i][0], START_RULES[i][1][j]));
      }
      for (i = 0, r = out.length; i < r; i++) {
        t = out[i];
        if (t.indexOf("ون") >= 0) { out.push(t.replace(/ون/g, "ان")); out.push(t.replace(/ون/g, "وان")); }
      }
      return out;
    }
    function formalOk(core) {
      var pres = [["", core]], pf, i, j, k, rest, alts, e, stem, fs, c;
      if (/^نمی/.test(core)) pres.push(["نمی" + ZW, core.slice(3)]);
      if (/^می/.test(core)) pres.push(["می" + ZW, core.slice(2)]);
      if (/^ن./.test(core)) pres.push(["ن", core.slice(1)]);
      if (/^ب./.test(core)) pres.push(["ب", core.slice(1)]);
      for (i = 0; i < pres.length; i++) {
        pf = pres[i][0]; rest = pres[i][1];
        if (rest.length < 1) continue;
        alts = stemAlts(rest);                                                  // a stem or a past form without an ending
        for (j = 0; j < alts.length; j++) if (pf + alts[j] !== core && ok(pf + alts[j])) return true;
        for (k = 0; k < END_KEYS.length; k++) {
          e = END_KEYS[k];
          if (rest.length - e.length < 1 || rest.slice(-e.length) !== e) continue;
          stem = rest.slice(0, -e.length);
          alts = stemAlts(stem);
          for (j = 0; j < alts.length; j++) for (c = 0; c < END_MAP[e].length; c++) {
            fs = pf + alts[j] + END_MAP[e][c];
            if (fs !== core && ok(fs)) return true;
          }
        }
      }
      return false;
    }
    function plainOk(v) {                                                           // colloquial plural and short forms of ordinary words
      if (/ایی$/.test(v) && v.length > 4 && (ok(v.slice(0, -3) + "هایی") || ok(v.slice(0, -3) + ZW + "هایی"))) return true;
      if (/ای$/.test(v) && v.length > 3 && (ok(v.slice(0, -2) + "های") || ok(v.slice(0, -2) + ZW + "های"))) return true;
      if (/ا$/.test(v) && v.length > 2 && (ok(v.slice(0, -1) + "ها") || ok(v.slice(0, -1) + ZW + "ها"))) return true;
      if (/قد$/.test(v) && ok(v + "ر")) return true;                                // چقد اینقد
      var m = /^(.{2,})(تایی|تا)$/.exec(v);                                       // دوتا چندتایی
      if (m && ok(m[1])) return true;
      return false;
    }
    function spoken(word) {
      if (spokenCache[word] !== undefined) return spokenCache[word];
      var w = word.replace(/\u200c/g, "").replace(/(.)\1{2,}/g, "$1"), vars = [w], seen = {}, res = false, i, j, v, t, n;
      if (!SPOKEN) SPOKEN = buildSpoken();
      if (SPOKEN[w]) res = true;
      // peel the clitics: خونتو -> خونت -> خون,  میزش -> میز
      for (n = 0; n < 3 && !res; n++) {
        for (i = vars.length - 1; i >= 0; i--) {
          for (j = 0; j < STRIP.length; j++) {
            v = vars[i];
            if (v.length - STRIP[j].length >= 2 && v.slice(-STRIP[j].length) === STRIP[j]) { t = v.slice(0, -STRIP[j].length); if (!seen[t]) { seen[t] = 1; vars.push(t); } }
          }
        }
      }
      for (i = 0; i < vars.length && !res; i++) {
        v = vars[i];
        if (SPOKEN[v] && i > 0) res = true;
        else if (ok(v) && v.length >= 2) { if (i > 0 || v !== w) res = true; }
        else if (plainOk(v) || formalOk(v) || plainOk(v.replace(/ون/g, "ان").replace(/^ان/, "\u0622ن"))) res = true;
        else if (/ون/.test(v) && (ok(v.replace(/ون/g, "ان")) || ok(v.replace(/ون/g, "ان") + "ه"))) res = true;   // خونه، تهرون
        else if (/^او/.test(v) && ok("آ" + v.slice(2))) res = true;
        if (!res && i > 0 && v.length >= 3) { if (plainOk(v + "") || formalOk(v)) res = true; }
      }
      spokenCache[word] = res;
      return res;
    }
    function setSpoken(on) { spokenOn = !!on; }
    var COMMON = { "\u0627\u0632": 1, "\u0628\u0647": 1, "\u0628\u0627": 1, "\u062F\u0631": 1, "\u062A\u0627": 1, "\u0628\u0631": 1, "\u06A9\u0647": 1, "\u0631\u0627": 1, "\u0647\u0645": 1, "\u0645\u0646": 1, "\u0627\u06CC\u0646": 1, "\u0622\u0646": 1 };
    function dist(a, b) {                                                          // Damerau-Levenshtein: how many letters apart
      var d = [], i, j, c;
      for (i = 0; i <= a.length; i++) { d[i] = [i]; }
      for (j = 1; j <= b.length; j++) d[0][j] = j;
      for (i = 1; i <= a.length; i++) for (j = 1; j <= b.length; j++) {
        c = a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1;
        d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + c);
        if (i > 1 && j > 1 && a.charAt(i - 1) === b.charAt(j - 2) && a.charAt(i - 2) === b.charAt(j - 1)) d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
      }
      return d[a.length][b.length];
    }
    function suggest(word) {
      if (sugCache[word]) return sugCache[word].slice();
      var out = [], splits = [], strong = [], w = trimZ(norm(word)), i, a, b, m, list;
      // a missing space: both halves are words
      if (w.length >= 4 && w.length <= 24) {
        for (i = 2; i <= w.length - 2; i++) {
          a = w.slice(0, i); b = w.slice(i);
          if (ok(a) && ok(b)) {
            splits.push(a + " " + b);
            if ((a.length >= 3 && b.length >= 3) || COMMON[a] || COMMON[b]) strong.push(a + " " + b);
          }
          if (splits.length >= 3) break;
        }
      }
      try { list = sp.suggest(w); } catch (e) { list = []; }
      list = list.map(function (x, n) { return { x: x, d: dist(w, x.replace(/\u200c/g, "")), n: n }; }).sort(function (p, q) { return (p.d - q.d) || (p.n - q.n); }).map(function (o) { return o.x; });
      // look-alike / sound-alike letters (ظمانت -> ضمانت): a single swap that gives a real word comes first
      var conf = [], ci, cj, ch, g, cand;
      for (ci = 0; ci < w.length && conf.length < 4; ci++) {
        ch = w.charAt(ci); g = CONF[ch];
        if (!g) continue;
        for (cj = 0; cj < g.length; cj++) {
          cand = w.slice(0, ci) + g.charAt(cj) + w.slice(ci + 1);
          if (ok(cand) && conf.indexOf(cand) < 0) conf.push(cand);
        }
      }
      conf.forEach(function (x) { out.push(x); });
      strong.slice(0, 2).forEach(function (x) { if (out.indexOf(x) < 0) out.push(x); });
      list.slice(0, 3).forEach(function (x) { if (out.indexOf(x) < 0) out.push(x); });
      splits.forEach(function (x) { if (out.indexOf(x) < 0) out.push(x); });
      list.slice(3).forEach(function (x) { if (out.indexOf(x) < 0) out.push(x); });
      // the verb prefix without its half-space
      m = /^(ن?می)(.{2,})$/.exec(w);
      if (m && ok(m[1] + ZW + m[2])) out.unshift(m[1] + ZW + m[2]);
      sugCache[word] = out.slice(0, 6);
      return sugCache[word].slice();
    }

    // ---- the checks: each pushes {kind, start, end, word, fix}
    function analyze(text) {
      text = String(text || "");
      var issues = [], m, re, w, base, fixed, last = null, lastEnd = -1, pm;

      function push(kind, start, end, fix, extra) {
        var i, o;
        for (i = 0; i < issues.length; i++) if (start < issues[i].end && end > issues[i].start) return;   // never two issues on the same characters
        o = { kind: kind, start: start, end: end, word: text.slice(start, end), fix: fix, msg: MSG[kind] };
        if (extra) for (var k in extra) if (extra.hasOwnProperty(k)) o[k] = extra[k];
        issues.push(o);
      }

      // spacing and punctuation (text level)
      re = /[\u0660-\u0669]+/g;
      while ((m = re.exec(text))) push("arabic", m.index, m.index + m[0].length, m[0].replace(/[\u0660-\u0669]/g, function (d) { return ARDIG[d]; }));
      re = /[ \t]{2,}/g;
      while ((m = re.exec(text))) push("space", m.index, m.index + m[0].length, " ");
      re = new RegExp("([" + LET + "])[ \\t]+(\u0647\u0627|\u0647\u0627\u06CC|\u062A\u0631\u06CC\u0646)(?![" + LET + "])", "g");
      while ((m = re.exec(text))) push("suffix", m.index + 1, m.index + m[0].length - m[2].length, ZW);
      re = /[ \t]+([\u060C\u061B\u061F!:.\)])/g;
      while ((m = re.exec(text))) { if (m.index > 0 && m[1] !== ")" ) push("space", m.index, m.index + m[0].length - 1, ""); }
      re = new RegExp("([" + LET + "])([\u060C\u061B\u061F])(?=[" + LET + "])", "g");
      while ((m = re.exec(text))) push("space", m.index + 2, m.index + 2, " ", { word: m[2] });
      re = new RegExp("([" + LET + "])(\\?|,|;)(?![A-Za-z0-9])", "g");
      while ((m = re.exec(text))) push("punct", m.index + 1, m.index + 2, m[2] === "?" ? "\u061F" : (m[2] === "," ? "\u060C" : "\u061B"));

      // words
      WORD.lastIndex = 0;
      while ((m = WORD.exec(text))) {
        w = m[0];
        // a word stuck to Latin letters or digits belongs to another script: leave it
        if ((m.index > 0 && /[A-Za-z0-9]/.test(text.charAt(m.index - 1))) || /[A-Za-z0-9]/.test(text.charAt(m.index + w.length))) continue;
        if (!HASLET.test(w)) continue;
        if (w.length < 2 && !/[\u0622-\u06CC]/.test(w)) continue;
        pm = { s: m.index, e: m.index + w.length };
        // the suffix that the spacing check already joins (کتاب ها) is not a stray word
        if (issues.some(function (q) { return q.kind === "suffix" && q.end === pm.s; })) { last = null; continue; }

        // the same word twice in a row
        if (last && last.w === w && w.length > 1 && /^[ \t]$/.test(text.slice(lastEnd, pm.s)) && ok(trimZ(norm(w)))) {
          push("repeat", lastEnd, pm.e, "", { word: w });
        }
        last = { w: w }; lastEnd = pm.e;

        base = trimZ(w);
        if (base.length < 2) continue;
        fixed = norm(base);
        if (isIgnored(base)) continue;
        // Arabic vowel marks and the tatweel are not part of Persian writing
        if (DIAC.test(base)) {
          DIAC.lastIndex = 0;
          fixed = norm(base.replace(DIAC, ""));
          if (ok(fixed) || isIgnored(fixed)) { push("arabic", pm.s, pm.e, norm(w.replace(DIAC, ""))); continue; }
        }
        DIAC.lastIndex = 0;
        if (fixed !== base) {
          // Arabic letters: the Persian spelling is the fix (and it may still be a misspelling after that)
          if (ok(fixed) || isIgnored(fixed)) { push("arabic", pm.s, pm.e, norm(w)); continue; }
        }
        if (ok(fixed)) continue;
        if (/[\u0623\u0624]/.test(fixed) && ok(fixed.replace(/\u0623/g, "\u0627").replace(/\u0624/g, "\u0648"))) continue;   // متأسفم / متاسفم: both are written
        // می / نمی without the half-space (میام، میاد are spoken words with no half-space: left to the spoken layer)
        var vm = /^(ن?می)([\u0621-\u06FF]{2,})$/.exec(fixed);
        if (vm && ok(vm[1] + ZW + vm[2]) && !(/^\u0627/.test(vm[2]) && vm[2].length <= 3)) { push("zwnj", pm.s, pm.e, vm[1] + ZW + vm[2]); continue; }
        if (spokenOn && spoken(fixed)) continue;
        var zi, zf = null;                                                       // لپتاپ -> لپ‌تاپ: one half-space makes a real word
        if (fixed.indexOf(ZW) < 0 && fixed.length >= 5) for (zi = 2; zi <= fixed.length - 2; zi++) { if (ok(fixed.slice(0, zi) + ZW + fixed.slice(zi))) { zf = fixed.slice(0, zi) + ZW + fixed.slice(zi); break; } }
        if (zf) { push("zwnj", pm.s, pm.e, zf); continue; }
        push("unknown", pm.s, pm.e, null);
      }
      issues.sort(function (a, b) { return a.start - b.start; });
      return issues;
    }

    // text after a replacement for one issue
    function applyOne(text, issue, replacement) {
      return text.slice(0, issue.start) + replacement + text.slice(issue.end);
    }
    // all "sure" fixes (everything but unknown words), from the end so the positions stay valid
    function applySure(text, issues) {
      var list = issues.filter(function (i) { return i.fix !== null && i.fix !== undefined; }).sort(function (a, b) { return b.start - a.start; }), i;
      for (i = 0; i < list.length; i++) text = applyOne(text, list[i], list[i].fix);
      return text;
    }

    return { setSpoken: setSpoken, analyze: analyze, suggest: suggest, applyOne: applyOne, applySure: applySure, addWords: addWords, correct: ok, norm: norm, MSG: MSG };
  }

  root.HydraSpell = { create: create, MSG: MSG };
  if (typeof module !== "undefined" && module.exports) module.exports = root.HydraSpell;
})(typeof window !== "undefined" ? window : global);
