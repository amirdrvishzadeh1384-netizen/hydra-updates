/* Hydra Studio · speech-dl.js
 * Fills the Subtitles "speech folder" from inside the panel: the newest whisper.cpp and ffmpeg builds (Windows, from GitHub)
 * and a Whisper model (from Hugging Face). Mac: whisper + ffmpeg come from Homebrew (brew install), the model is downloaded.
 * Every download goes to "<file>.part" first (continues where it stopped), is checked (size + sha256 when the server gives one),
 * and only then gets its real name. Used by studio-subs.js; works in node too (tests).
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module && module.exports) module.exports = api;
  else root.HydraSpeechDL = api;
})(typeof window !== "undefined" ? window : this, function () {
  "use strict";

  var HF = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/";
  // the models you can pick (sizes as Hugging Face reports them)
  var MODELS = [
    { file: "ggml-large-v3-turbo-q5_0.bin", label: "Best for Persian, fast", mb: 548 },
    { file: "ggml-small.bin", label: "Small and quick", mb: 465 },
    { file: "ggml-large-v3-q5_0.bin", label: "Most accurate, slow", mb: 1031 },
    { file: "ggml-medium.bin", label: "Medium", mb: 1463 }
  ];
  var WHISPER_REPO = "ggml-org/whisper.cpp", FFMPEG_REPO = "BtbN/FFmpeg-Builds";
  var GYAN = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip";
  var UA = "HydraStudio-Speech";

  function err(msg, kind) { var e = new Error(msg); e.kind = kind || "net"; return e; }
  function cancelled() { return err("Stopped.", "stop"); }

  // ---- picking the right release files
  function winArch(arch) { return arch === "arm64" ? "arm64" : "x64"; }
  // releases: GitHub's list (newest first). Whisper puts its Windows builds on the "bNNNN" releases, not on every one.
  function pickWhisper(releases, arch) {
    var want = winArch(arch) === "arm64" ? "whisper-bin-win-cpu-arm64.zip" : "whisper-bin-x64.zip", i, j, r, a;
    for (i = 0; i < (releases || []).length; i++) {
      r = releases[i]; if (!r || r.draft) continue;
      for (j = 0; j < (r.assets || []).length; j++) {
        a = r.assets[j];
        if (a && a.name === want && a.browser_download_url) return { tag: String(r.tag_name || ""), name: a.name, url: a.browser_download_url, size: a.size || 0, sha: digest(a) };
      }
    }
    return null;
  }
  // BtbN: newest numbered release (ffmpeg-n9.0-latest-win64-gpl-9.0.zip), else the master build
  function pickFfmpeg(release, arch) {
    var plat = winArch(arch) === "arm64" ? "winarm64" : "win64", best = null, bestV = null, master = null;
    var re = new RegExp("^ffmpeg-n([0-9.]+)-latest-" + plat + "-gpl-[0-9.]+\\.zip$");
    ((release && release.assets) || []).forEach(function (a) {
      if (!a || !a.browser_download_url) return;
      var m = re.exec(a.name);
      if (m) { var v = m[1].split(".").map(Number); if (!bestV || cmp(v, bestV) > 0) { bestV = v; best = a; } }
      else if (a.name === "ffmpeg-master-latest-" + plat + "-gpl.zip") master = a;
    });
    var a = best || master;
    return a ? { tag: bestV ? "n" + bestV.join(".") : "master", name: a.name, url: a.browser_download_url, size: a.size || 0, sha: digest(a) } : null;
  }
  function cmp(a, b) { var i; for (i = 0; i < Math.max(a.length, b.length); i++) { var x = a[i] || 0, y = b[i] || 0; if (x !== y) return x < y ? -1 : 1; } return 0; }
  function digest(a) { var m = /^sha256:([0-9a-f]{64})$/i.exec(a && a.digest || ""); return m ? m[1].toLowerCase() : ""; }

  // ---- HTTP: JSON + streaming a file to disk (redirects, resume, progress, stop)
  function request(D, url, headers, token, onRes, onErr) {
    var redirects = 0, info = {};
    function go(u) {
      if (token && token.stopped) return onErr(cancelled());
      var p; try { p = new URL(u); } catch (e) { return onErr(err("bad address")); }
      if (p.protocol !== "https:" && p.protocol !== "http:") return onErr(err("unsupported address"));
      var mod = p.protocol === "https:" ? D.https : D.http, h = { "User-Agent": UA, "Accept": "*/*" }, k;
      for (k in headers || {}) h[k] = headers[k];
      var req = mod.get({ protocol: p.protocol, hostname: p.hostname.replace(/^\[|\]$/g, ""), port: p.port || undefined, path: (p.pathname || "/") + (p.search || ""), headers: h }, function (res) {
        var code = res.statusCode || 0, loc = res.headers.location, et = res.headers["x-linked-etag"], sz = res.headers["x-linked-size"];
        if (et) { var m = /([0-9a-f]{64})/i.exec(et); if (m) info.sha = m[1].toLowerCase(); }
        if (sz && +sz > 0) info.size = +sz;
        if (code >= 300 && code < 400 && loc) {
          res.resume();
          if (++redirects > 8) return onErr(err("too many redirects"));
          var next; try { next = new URL(loc, u).href; } catch (e) { return onErr(err("bad redirect")); }
          return go(next);
        }
        onRes(res, info, req);
      });
      if (token) token.abort = function () { try { req.destroy(); } catch (e) {} };
      req.setTimeout(30000, function () { req.destroy(err("timed out")); });
      req.on("error", function (e) { onErr(token && token.stopped ? cancelled() : err(e && e.message || "connection error")); });
    }
    go(url);
  }

  function getJSON(D, url, token) {
    return new Promise(function (resolve, reject) {
      request(D, url, { "Accept": "application/vnd.github+json" }, token, function (res) {
        var chunks = [], n = 0;
        if (res.statusCode !== 200) { res.resume(); return reject(err(res.statusCode === 403 || res.statusCode === 429 ? "GitHub is busy (too many requests). Try again in an hour." : "HTTP " + res.statusCode, "http")); }
        res.on("data", function (c) { n += c.length; if (n > 16 * 1048576) { res.destroy(); return reject(err("answer too big")); } chunks.push(c); });
        res.on("end", function () { try { resolve(JSON.parse(Buffer.concat(chunks).toString("utf8"))); } catch (e) { reject(err("unexpected answer")); } });
        res.on("error", function (e) { reject(err(e.message)); });
      }, reject);
    });
  }

  function sha256File(D, file) {
    return new Promise(function (resolve, reject) {
      var h = D.crypto.createHash("sha256"), s = D.fs.createReadStream(file);
      s.on("data", function (c) { h.update(c); });
      s.on("end", function () { resolve(h.digest("hex")); });
      s.on("error", reject);
    });
  }
  function size(D, f) { try { return D.fs.statSync(f).size; } catch (e) { return -1; } }
  function rm(D, f) { try { D.fs.unlinkSync(f); } catch (e) {} }

  // opt: { size, sha, onProgress(got, total), token }  ->  resolves with the final path
  function download(D, url, dest, opt) {
    opt = opt || {};
    var part = dest + ".part", token = opt.token || {};
    function once(retried) {
      return new Promise(function (resolve, reject) {
        var have = Math.max(0, size(D, part));
        if (opt.size && have > opt.size) { rm(D, part); have = 0; }
        request(D, url, have ? { "Range": "bytes=" + have + "-" } : {}, token, function (res, info, req) {
          var code = res.statusCode, total = opt.size || info.size || 0, append = false;
          if (code === 416 && have) { res.resume(); return resolve({ info: info, done: true }); }   // the .part is already whole
          if (code === 206) append = true;
          else if (code === 200) have = 0;
          else { res.resume(); return reject(err("HTTP " + code, "http")); }
          var len = parseInt(res.headers["content-length"], 10);
          if (!total && len > 0) total = have + len;
          var out = D.fs.createWriteStream(part, { flags: append ? "a" : "w" }), got = have, last = 0, failed = false;
          function fail(e) { if (failed) return; failed = true; try { res.destroy(); } catch (x) {} out.end(function () { reject(e); }); }
          res.on("data", function (c) {
            if (token.stopped) return fail(cancelled());
            got += c.length;
            if (!out.write(c)) { res.pause(); out.once("drain", function () { res.resume(); }); }
            var now = Date.now();
            if (opt.onProgress && now - last > 200) { last = now; try { opt.onProgress(got, total); } catch (x) {} }
          });
          res.on("end", function () {
            if (failed) return;
            out.end(function () {
              if (token.stopped) return reject(cancelled());
              if (len > 0 && got !== have + len) return reject(err("connection dropped"));
              if (opt.onProgress) try { opt.onProgress(got, total); } catch (x) {}
              resolve({ info: info, done: true });
            });
          });
          res.on("aborted", function () { fail(token.stopped ? cancelled() : err("connection dropped")); });
          res.on("error", function (e) { fail(token.stopped ? cancelled() : err(e.message || "connection error")); });
          out.on("error", function (e) { fail(err("couldn’t write the file: " + (e.code || e.message), "disk")); });
        }, reject);
      }).then(function (r) {
        var want = opt.size || r.info.size || 0, sha = opt.sha || r.info.sha || "";
        if (want && size(D, part) !== want) { if (size(D, part) > want) rm(D, part); throw err("the file came down incomplete, try again (it continues where it stopped)"); }
        if (!sha) return dest;
        if (opt.onCheck) opt.onCheck();
        return sha256File(D, part).then(function (h) {
          if (h !== sha) { rm(D, part); if (!retried) return once(true); throw err("the downloaded file is damaged", "bad"); }
          return dest;
        });
      });
    }
    try { D.fs.mkdirSync(D.path.dirname(dest), { recursive: true }); } catch (e) {}
    return once(false).then(function (d) {
      if (d === dest && size(D, part) >= 0) { rm(D, dest); D.fs.renameSync(part, dest); }
      return dest;
    });
  }

  // ---- reading a zip: only the files we ask for (whisper's folder, ffmpeg.exe), so a 190 MB ffmpeg zip is fine
  function zipEntries(buf) {
    var n = buf.length, i, eocd = -1, out = [], p, count, cdOff;
    for (i = n - 22; i >= Math.max(0, n - 22 - 65535); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
    if (eocd < 0) throw err("the downloaded zip is damaged", "zip");
    count = buf.readUInt16LE(eocd + 10); cdOff = buf.readUInt32LE(eocd + 16);
    if (count === 0xFFFF || cdOff === 0xFFFFFFFF) throw err("zip64 is not supported", "zip");
    p = cdOff;
    for (i = 0; i < count; i++) {
      if (p + 46 > n || buf.readUInt32LE(p) !== 0x02014b50) throw err("the downloaded zip is damaged", "zip");
      var nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32);
      out.push({ name: buf.toString("utf8", p + 46, p + 46 + nl).replace(/\\/g, "/"), method: buf.readUInt16LE(p + 10), flags: buf.readUInt16LE(p + 8), crc: buf.readUInt32LE(p + 16), csize: buf.readUInt32LE(p + 20), usize: buf.readUInt32LE(p + 24), lho: buf.readUInt32LE(p + 42) });
      p += 46 + nl + xl + cl;
    }
    return out;
  }
  function zipRead(buf, e, zlib, crc32) {
    if (e.flags & 1) throw err("encrypted zip", "zip");
    if (e.lho + 30 > buf.length || buf.readUInt32LE(e.lho) !== 0x04034b50) throw err("the downloaded zip is damaged", "zip");
    var start = e.lho + 30 + buf.readUInt16LE(e.lho + 26) + buf.readUInt16LE(e.lho + 28), comp = buf.slice(start, start + e.csize), data;
    if (e.method === 0) data = Buffer.from(comp);
    else if (e.method === 8) data = zlib.inflateRawSync(comp);
    else throw err("unsupported zip compression", "zip");
    if (data.length !== e.usize || (crc32 && crc32(data) !== e.crc)) throw err("the downloaded zip is damaged (" + e.name + ")", "zip");
    return data;
  }
  function base(n) { return String(n).split("/").pop(); }
  function safeName(n) { return /^[A-Za-z0-9._ +-]{1,120}$/.test(n) && n !== "." && n !== ".."; }

  // every file next to whisper-cli.exe in the zip  ->  <into>/ (flat)
  function extractWhisper(D, buf, into, crc32) {
    var all = zipEntries(buf), cli = null;
    all.forEach(function (e) { if (!cli && /(^|\/)whisper-cli\.exe$/i.test(e.name)) cli = e; });
    if (!cli) throw err("whisper-cli.exe is not in this whisper build", "zip");
    var dir = cli.name.slice(0, cli.name.length - base(cli.name).length), files = [];
    all.forEach(function (e) { var rest = e.name.slice(dir.length); if (e.name.indexOf(dir) === 0 && rest && rest.indexOf("/") < 0 && safeName(rest) && !/^test-/i.test(rest)) files.push(e); });
    return swapInto(D, into, files.map(function (e) { return { name: base(e.name), data: zipRead(buf, e, D.zlib, crc32) }; }));
  }
  function extractFfmpeg(D, buf, into, crc32) {
    var e = null;
    zipEntries(buf).forEach(function (x) { if (!e && /(^|\/)bin\/ffmpeg\.exe$/i.test(x.name)) e = x; });
    if (!e) zipEntries(buf).forEach(function (x) { if (!e && /(^|\/)ffmpeg\.exe$/i.test(x.name)) e = x; });
    if (!e) throw err("ffmpeg.exe is not in this ffmpeg build", "zip");
    return swapInto(D, into, [{ name: "ffmpeg.exe", data: zipRead(buf, e, D.zlib, crc32) }]);
  }
  // write the new files into a fresh folder, then put it in place of the old one
  function swapInto(D, into, files) {
    var fs = D.fs, tmp = into + ".new", old = into + ".old";
    rmrf(D, tmp); fs.mkdirSync(tmp, { recursive: true });
    files.forEach(function (f) { fs.writeFileSync(D.path.join(tmp, f.name), f.data); });
    rmrf(D, old);
    if (size(D, into) >= 0) fs.renameSync(into, old);
    fs.renameSync(tmp, into);
    rmrf(D, old);
    return files.map(function (f) { return f.name; });
  }
  function rmrf(D, p) {
    try { if (D.fs.rmSync) D.fs.rmSync(p, { recursive: true, force: true }); else D.fs.rmdirSync(p, { recursive: true }); } catch (e) {}
  }

  // ---- what the panel installed (speech/installed.json) so "newer versions" can be told
  function readInstalled(D, speechDir) { try { return JSON.parse(D.fs.readFileSync(D.path.join(speechDir, "installed.json"), "utf8")) || {}; } catch (e) { return {}; } }
  function writeInstalled(D, speechDir, key, val) {
    var o = readInstalled(D, speechDir); o[key] = val;
    try { D.fs.writeFileSync(D.path.join(speechDir, "installed.json"), JSON.stringify(o, null, 1)); } catch (e) {}
  }

  // ---- the three jobs. ctx: { D, speechDir, arch, token, onProgress(got,total), onStep(text), crc32 }
  function getZip(ctx, pick, file) {
    var zip = ctx.D.path.join(ctx.speechDir, "downloads", file);
    return download(ctx.D, pick.url, zip, { size: pick.size, sha: pick.sha, token: ctx.token, onProgress: ctx.onProgress, onCheck: function () { step(ctx, "Checking the file…"); } })
      .then(function () { step(ctx, "Unpacking…"); return zip; });
  }
  function step(ctx, t) { if (ctx.onStep) try { ctx.onStep(t); } catch (e) {} }
  function done(ctx, zip) { rm(ctx.D, zip); try { ctx.D.fs.rmdirSync(ctx.D.path.dirname(zip)); } catch (e) {} }

  function installWhisper(ctx) {
    step(ctx, "Finding the newest Whisper…");
    return getJSON(ctx.D, "https://api.github.com/repos/" + WHISPER_REPO + "/releases?per_page=20", ctx.token).then(function (list) {
      var pick = pickWhisper(list, ctx.arch);
      if (!pick) throw err("no Windows build of Whisper was found on GitHub");
      if (ctx.ifNewer && readInstalled(ctx.D, ctx.speechDir).whisper === pick.tag) return null;
      step(ctx, "Downloading Whisper " + pick.tag + "…");
      return getZip(ctx, pick, pick.name).then(function (zip) {
        extractWhisper(ctx.D, ctx.D.fs.readFileSync(zip), ctx.D.path.join(ctx.speechDir, "whisper"), ctx.crc32);
        done(ctx, zip); writeInstalled(ctx.D, ctx.speechDir, "whisper", pick.tag);
        return pick.tag;
      });
    });
  }
  function installFfmpeg(ctx) {
    step(ctx, "Finding the newest ffmpeg…");
    return getJSON(ctx.D, "https://api.github.com/repos/" + FFMPEG_REPO + "/releases/latest", ctx.token).then(function (rel) { return pickFfmpeg(rel, ctx.arch); }, function (e) { if (e.kind === "stop") throw e; return null; })
      .then(function (pick) {
        if (!pick && winArch(ctx.arch) === "x64") pick = { tag: "release", name: "ffmpeg-release-essentials.zip", url: GYAN, size: 0, sha: "" };
        if (!pick) throw err("no Windows build of ffmpeg was found");
        if (ctx.ifNewer && readInstalled(ctx.D, ctx.speechDir).ffmpeg === pick.tag) return null;
        step(ctx, "Downloading ffmpeg " + pick.tag + "…");
        return getZip(ctx, pick, pick.name).then(function (zip) {
          extractFfmpeg(ctx.D, ctx.D.fs.readFileSync(zip), ctx.D.path.join(ctx.speechDir, "ffmpeg"), ctx.crc32);
          done(ctx, zip); writeInstalled(ctx.D, ctx.speechDir, "ffmpeg", pick.tag);
          return pick.tag;
        });
      });
  }
  function installModel(ctx, file) {
    var m = MODELS.filter(function (x) { return x.file === file; })[0];
    if (!m) return Promise.reject(err("unknown model"));
    step(ctx, "Downloading the model (" + m.mb + " MB)…");
    var dest = ctx.D.path.join(ctx.speechDir, m.file);
    return download(ctx.D, HF + m.file, dest, { token: ctx.token, onProgress: ctx.onProgress, onCheck: function () { step(ctx, "Checking the model…"); } }).then(function () {
      var fd = ctx.D.fs.openSync(dest, "r"), b = Buffer.alloc(4);
      ctx.D.fs.readSync(fd, b, 0, 4, 0); ctx.D.fs.closeSync(fd);
      if (b.readUInt32LE(0) !== 0x67676d6c) { rm(ctx.D, dest); throw err("this is not a Whisper model file (blocked or changed download?)", "bad"); }
      return m.file;
    });
  }

  // Mac: whisper-cpp and ffmpeg from Homebrew
  function findBrew(fs) {
    var c = ["/opt/homebrew/bin/brew", "/usr/local/bin/brew"], i;
    for (i = 0; i < c.length; i++) { try { if (fs.statSync(c[i]).isFile()) return c[i]; } catch (e) {} }
    return "";
  }
  function brewInstall(cp, brew, pkgs, env, token, onLine) {
    return new Promise(function (resolve, reject) {
      var e = {}, k; for (k in env || {}) e[k] = env[k];
      e.PATH = brew.replace(/\/brew$/, "") + ":/usr/bin:/bin:/usr/sbin:/sbin" + (e.PATH ? ":" + e.PATH : "");
      e.HOMEBREW_NO_AUTO_UPDATE = "1"; e.HOMEBREW_NO_ENV_HINTS = "1"; e.NONINTERACTIVE = "1";
      var p = cp.spawn(brew, ["install"].concat(pkgs), { env: e }), tail = [];
      token.abort = function () { try { p.kill(); } catch (x) {} };
      function eat(b) { String(b).split(/[\r\n]+/).forEach(function (l) { if (!l) return; tail.push(l); if (tail.length > 8) tail.shift(); if (onLine) onLine(l); }); }
      p.stdout.on("data", eat); p.stderr.on("data", eat);
      p.on("error", function (x) { reject(err("couldn’t start Homebrew: " + x.message)); });
      p.on("close", function (code) { if (token.stopped) reject(cancelled()); else if (code === 0) resolve(); else reject(err("Homebrew stopped with an error:\n" + tail.slice(-4).join("\n"))); });
    });
  }

  return {
    MODELS: MODELS, HF: HF, pickWhisper: pickWhisper, pickFfmpeg: pickFfmpeg, download: download, getJSON: getJSON,
    zipEntries: zipEntries, extractWhisper: extractWhisper, extractFfmpeg: extractFfmpeg,
    installWhisper: installWhisper, installFfmpeg: installFfmpeg, installModel: installModel,
    readInstalled: readInstalled, findBrew: findBrew, brewInstall: brewInstall
  };
});
