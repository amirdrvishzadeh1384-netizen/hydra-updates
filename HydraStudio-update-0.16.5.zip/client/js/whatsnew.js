/* Hydra Studio · whatsnew.js
 * What changed, newest first. It ships inside every release, so the panel can tell what is new after an update.
 * tab = the section the note belongs to (that section gets a small NEW mark until it is opened), or "" for a general note.
 */
window.HYDRA_NEWS = [
  { v: "0.16.5", items: [
    { tab: "", t: "Smoother scrolling: while you scroll, the cards stop reacting to the pointer until you stop" }
  ] },
  { v: "0.16.4", items: [
    { tab: "", t: "Smoother and lighter: no blur or heavy shadows by default (Settings → Light effects turns the full look back on)" }
  ] },
  { v: "0.16.3", items: [
    { tab: "", t: "Preview follows you: scroll down in Timer, Pixel, Glass, Curve, Expr or Morph and the preview shrinks to half and stays on top, over a soft fade" },
    { tab: "subs", t: "Subtitles: opening another project no longer leaves the old listening or lines behind" }
  ] },
  { v: "0.16.2", items: [
    { tab: "", t: "Small screens: on a short panel the header, the apply bar and the preview shrink so the controls get the room" }
  ] },
  { v: "0.16.1", items: [
    { tab: "subs", t: "Subtitles: built-in fixes for words Whisper often mishears (تهتر → تتر, ارض دیجیتال → ارز دیجیتال…)" },
    { tab: "subs", t: "Subtitles: set the maximum words per subtitle and cut the lines before creating the layers" },
    { tab: "spell", t: "Spell: if the Persian dictionary is missing, one button downloads it" }
  ] },
  { v: "0.16.0", items: [
    { tab: "ban", t: "Banned words: paste a client’s list and find every place those words appear in your texts" },
    { tab: "ban", t: "Swap a banned word for another one, right from the results" },
    { tab: "", t: "This notice: after an update you see what changed, and new sections carry a NEW mark" }
  ] },
  { v: "0.15.4", items: [
    { tab: "subs", t: "Subtitles: spelling clean-up never changes the length of a word" }
  ] },
  { v: "0.15.3", items: [
    { tab: "subs", t: "Subtitles: automatic spelling clean-up and “My corrections”" }
  ] },
  { v: "0.15.2", items: [
    { tab: "subs", t: "Subtitles: hint words and a more careful listening mode" }
  ] },
  { v: "0.15.1", items: [
    { tab: "subs", t: "Subtitles: edit the subtitle layers already in the comp" }
  ] },
  { v: "0.15.0", items: [
    { tab: "subs", t: "New Subtitles section: listens offline (Whisper) and builds the subtitle layers" }
  ] }
];
