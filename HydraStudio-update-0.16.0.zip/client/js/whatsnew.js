/* Hydra Studio · whatsnew.js
 * What changed, newest first. It ships inside every release, so the panel can tell what is new after an update.
 * tab = the section the note belongs to (that section gets a small NEW mark until it is opened), or "" for a general note.
 */
window.HYDRA_NEWS = [
  { v: "0.16.0", items: [
    { tab: "ban", t: "Banned words: paste a client’s list and find every place those words appear in your texts" },
    { tab: "ban", t: "Swap a banned word for another one, right from the results" },
    { tab: "", t: "This notice: after an update you see what changed, and new sections carry a NEW mark" }
  ] },
  { v: "0.15.4", items: [
    { tab: "subs", t: "Subtitles: spelling clean-up never changes the length of a word" }
  ] },
  { v: "0.15.3", items: [
    { tab: "subs", t: "Subtitles: automatic spelling clean-up and “My corrections”" }
  ] },
  { v: "0.15.2", items: [
    { tab: "subs", t: "Subtitles: hint words and a more careful listening mode" }
  ] },
  { v: "0.15.1", items: [
    { tab: "subs", t: "Subtitles: edit the subtitle layers already in the comp" }
  ] },
  { v: "0.15.0", items: [
    { tab: "subs", t: "New Subtitles section: listens offline (Whisper) and builds the subtitle layers" }
  ] }
];
