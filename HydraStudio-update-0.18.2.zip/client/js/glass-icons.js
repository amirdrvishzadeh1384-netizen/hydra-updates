/* Hydra Studio · glass-icons.js
 * The Liquid Glass shape library: simple, original vector icons as After Effects shape paths
 * ({ v: vertices, i: in tangents, o: out tangents, c: closed }) in a 100-unit box around 0,0 (y down).
 * Outer paths run clockwise, holes counter-clockwise, so one non-zero fill draws them (in AE and on a canvas).
 */
(function () {
  "use strict";
  var K = 0.5523, D = Math.PI / 180;

  function area(p) { var a = 0, n = p.v.length, k, q; for (k = 0; k < n; k++) { q = p.v[(k + 1) % n]; a += p.v[k][0] * q[1] - q[0] * p.v[k][1]; } return a / 2; }
  function reverse(p) {
    var n = p.v.length, v = [], i = [], o = [], k, j;
    for (k = 0; k < n; k++) { j = n - 1 - k; v.push(p.v[j]); i.push(p.o[j]); o.push(p.i[j]); }
    return { v: v, i: i, o: o, c: 1 };
  }
  function cw(p) { return area(p) < 0 ? reverse(p) : p; }       // y down: positive area = clockwise on screen
  function hole(p) { return area(p) > 0 ? reverse(p) : p; }
  function poly(pts) { var z = pts.map(function () { return [0, 0]; }); return cw({ v: pts.map(function (q) { return [q[0], q[1]]; }), i: z, o: z.map(function () { return [0, 0]; }), c: 1 }); }
  function ell(cx, cy, rx, ry) {
    var a = K * rx, b = K * ry;
    return cw({ v: [[cx, cy - ry], [cx + rx, cy], [cx, cy + ry], [cx - rx, cy]], i: [[-a, 0], [0, -b], [a, 0], [0, b]], o: [[a, 0], [0, b], [-a, 0], [0, -b]], c: 1 });
  }
  function circ(cx, cy, r) { return ell(cx, cy, r, r); }
  function rr(cx, cy, w, h, r) {
    var hw = w / 2, hh = h / 2, q, z = [0, 0];
    r = Math.max(0, Math.min(r, hw, hh)); q = K * r;
    if (r < 0.01) return poly([[cx - hw, cy - hh], [cx + hw, cy - hh], [cx + hw, cy + hh], [cx - hw, cy + hh]]);
    var v = [[-hw + r, -hh], [hw - r, -hh], [hw, -hh + r], [hw, hh - r], [hw - r, hh], [-hw + r, hh], [-hw, hh - r], [-hw, -hh + r]];
    return cw({ v: v.map(function (p) { return [p[0] + cx, p[1] + cy]; }), i: [[-q, 0], z, [0, -q], z, [q, 0], z, [0, q], z], o: [z, [q, 0], z, [0, q], z, [-q, 0], z, [0, -q]], c: 1 });
  }
  function rot(p, deg, cx, cy) {
    var c = Math.cos(deg * D), s = Math.sin(deg * D);
    cx = cx || 0; cy = cy || 0;
    function pt(q) { var x = q[0] - cx, y = q[1] - cy; return [cx + x * c - y * s, cy + x * s + y * c]; }
    function vec(q) { return [q[0] * c - q[1] * s, q[0] * s + q[1] * c]; }
    return { v: p.v.map(pt), i: p.i.map(vec), o: p.o.map(vec), c: 1 };
  }
  // a bar with round ends from (x1, y1) to (x2, y2)
  function cap(x1, y1, x2, y2, w) {
    var L = Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
    return rot(rr((x1 + x2) / 2, (y1 + y2) / 2, L + w, w, w / 2), Math.atan2(y2 - y1, x2 - x1) / D, (x1 + x2) / 2, (y1 + y2) / 2);
  }
  function arcPts(cx, cy, r, a0, a1, n) { var p = [], k, a; for (k = 0; k <= n; k++) { a = (a0 + (a1 - a0) * k / n) * D; p.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]); } return p; }
  // a ring segment (angles in degrees, 0 = right, 90 = down)
  function band(cx, cy, r1, r2, a0, a1) { var n = Math.max(6, Math.round(Math.abs(a1 - a0) / 12)); return poly(arcPts(cx, cy, r2, a0, a1, n).concat(arcPts(cx, cy, r1, a1, a0, n))); }
  function cross(w, L) { return poly([[-w, -L], [w, -L], [w, -w], [L, -w], [L, w], [w, w], [w, L], [-w, L], [-w, w], [-L, w], [-L, -w], [-w, -w]]); }
  function gear() {
    var p = [], k, a, n = 8, t = 360 / n;
    for (k = 0; k < n; k++) {
      a = k * t - 90;
      p = p.concat(arcPts(0, 0, 46, a - t * 0.17, a + t * 0.17, 2), arcPts(0, 0, 34, a + t * 0.3, a + t * 0.7, 2));
    }
    return [poly(p), hole(circ(0, 0, 15))];
  }
  function star(n, R, r, dy) { var p = [], k, a; for (k = 0; k < n * 2; k++) { a = -Math.PI / 2 + k * Math.PI / n; p.push([Math.cos(a) * (k % 2 ? r : R), Math.sin(a) * (k % 2 ? r : R) + (dy || 0)]); } return poly(p); }
  function heart() {
    var s = 42, dy = -4;
    return cw({ v: [[0, 1.05 * s + dy], [0, -0.35 * s + dy]], i: [[1.6 * s, -0.9 * s], [-1.15 * s, -0.7 * s]], o: [[-1.6 * s, -0.9 * s], [1.15 * s, -0.7 * s]], c: 1 });
  }
  function chainLink(cx, cy) { return [rot(rr(cx, cy, 62, 30, 15), -45, cx, cy), hole(rot(rr(cx, cy, 44, 12, 6), -45, cx, cy))]; }
  function ticket() {
    var p = [[-46, -28], [46, -28]].concat(arcPts(46, 0, 11, -90, -270, 8)).concat([[46, 28], [-46, 28]]).concat(arcPts(-46, 0, 11, 90, -90, 8));
    return [poly(p), hole(rr(10, 0, 4, 34, 2))];
  }
  var CURSOR = [[0, 0], [0, 17], [4.2, 13.2], [7, 19.6], [10, 18.3], [7.3, 12], [12.6, 12]].map(function (q) { return [q[0] * 4.8 - 30, q[1] * 4.8 - 47]; });
  function ray(k) { var a = k * 45 * D; return cap(Math.cos(a) * 32, Math.sin(a) * 32, Math.cos(a) * 44, Math.sin(a) * 44, 8); }

  // [key, label, paths, thick (half thickness / size, for the bevel), corners]
  var ICONS = [
    ["star", "Star", [star(5, 50, 23, 4)], 0.15, 4],
    ["heart", "Heart", [heart()], 0.26, 0],
    ["play", "Play", [circ(0, 0, 46), hole(poly([[-12, -22], [24, 0], [-12, 22]]))], 0.12, 2],
    ["check", "Check", [circ(0, 0, 46), hole(poly([[-27, -2], [-16, -13], [-6, -3], [16, -25], [27, -14], [-6, 19]]))], 0.12, 2],
    ["plus", "Plus", [circ(0, 0, 46), hole(cross(6, 27))], 0.12, 2],
    ["close", "Close", [circ(0, 0, 46), hole(rot(cross(6, 27), 45))], 0.12, 2],
    ["home", "Home", [poly([[-46, -2], [0, -44], [46, -2], [34, -2], [34, 44], [10, 44], [10, 16], [-10, 16], [-10, 44], [-34, 44], [-34, -2]])], 0.14, 3],
    ["search", "Search", [circ(-8, -8, 34), hole(circ(-8, -8, 22)), cap(18, 18, 40, 40, 14)], 0.08, 0],
    ["user", "User", [circ(0, -22, 22), rr(0, 30, 84, 36, 18)], 0.18, 0],
    ["mail", "Mail", [rr(0, 0, 96, 70, 10), hole(poly([[-38, -26], [38, -26], [38, -19], [0, 8], [-38, -19]]))], 0.14, 2],
    ["pin", "Pin", [circ(0, -12, 32), poly([[-27, 2], [27, 2], [0, 48]]), hole(circ(0, -12, 12))], 0.16, 2],
    ["chat", "Chat", [rr(0, -8, 84, 60, 24), poly([[-22, 12], [-4, 18], [-28, 40]])], 0.26, 3],
    ["bell", "Bell", [poly([[-32, 24], [-28, -10], [-16, -32], [0, -38], [16, -32], [28, -10], [32, 24], [42, 32], [-42, 32]]), circ(0, 40, 8), circ(0, -40, 6)], 0.2, 6],
    ["gear", "Settings", gear(), 0.12, 2],
    ["sliders", "Sliders", [cap(-28, -42, -28, 42, 8), cap(0, -42, 0, 42, 8), cap(28, -42, 28, 42, 8), rr(-28, -16, 24, 14, 6), rr(0, 18, 24, 14, 6), rr(28, -4, 24, 14, 6)], 0.06, 0],
    ["cloud", "Cloud", [circ(-22, 8, 22), circ(6, -8, 28), circ(30, 10, 18), rr(2, 18, 92, 32, 16)], 0.24, 0],
    ["globe", "Globe", [circ(0, 0, 46), hole(ell(0, 0, 30, 46)), ell(0, 0, 21, 45), hole(rr(0, 0, 36, 6, 3)), hole(rr(-38, 0, 12, 6, 3)), hole(rr(38, 0, 12, 6, 3))], 0.08, 0],
    ["compass", "Compass", [circ(0, 0, 46), hole(rot(poly([[0, -32], [10, 0], [0, 32], [-10, 0]]), 45))], 0.12, 2],
    ["like", "Like", [rr(-36, 14, 16, 52, 4), poly([[-24, -6], [-6, -6], [2, -40], [14, -40], [18, -30], [14, -6], [40, -6], [46, 2], [38, 40], [-24, 40]])], 0.14, 4],
    ["card", "Card", [rr(0, 0, 96, 68, 10), hole(rr(0, -13, 84, 10, 2)), hole(rr(-24, 14, 26, 10, 3))], 0.14, 0],
    ["timer", "Timer", [circ(0, 6, 40), hole(circ(0, 6, 31)), cap(0, 6, 0, -14, 7), cap(0, 6, 12, 14, 7), rr(0, -38, 8, 10, 2), rr(0, -44, 22, 8, 3)], 0.08, 0],
    ["share", "Share", [circ(26, -28, 14), circ(-26, 0, 14), circ(26, 28, 14), cap(-26, 0, 26, -28, 8), cap(-26, 0, 26, 28, 8)], 0.08, 0],
    ["link", "Link", chainLink(-13, 13).concat(chainLink(13, -13)), 0.07, 0],
    ["doc", "Document", [poly([[-34, -46], [12, -46], [36, -22], [36, 46], [-34, 46]]), hole(rr(-6, -10, 32, 6, 3)), hole(rr(0, 6, 44, 6, 3)), hole(rr(0, 22, 44, 6, 3))], 0.14, 3],
    ["bag", "Basket", [band(0, -8, 24, 32, 180, 360), poly([[-46, -8], [46, -8], [36, 42], [-36, 42]]), hole(rr(-16, 17, 7, 26, 3)), hole(rr(0, 17, 7, 26, 3)), hole(rr(16, 17, 7, 26, 3))], 0.12, 3],
    ["notebook", "Notebook", [rr(6, 0, 76, 94, 8), rr(-36, -30, 18, 7, 3), rr(-36, -10, 18, 7, 3), rr(-36, 10, 18, 7, 3), rr(-36, 30, 18, 7, 3)], 0.2, 0],
    ["bookmark", "Bookmark", [poly([[-28, -46], [28, -46], [28, 46], [0, 24], [-28, 46]])], 0.2, 4],
    ["save", "Save", [rr(0, 0, 90, 90, 10), hole(rr(-6, -28, 46, 26, 3)), hole(circ(0, 20, 14))], 0.12, 0],
    ["lifebuoy", "Lifebuoy", [circ(0, 0, 46), hole(circ(0, 0, 20)), hole(rot(rr(33, 0, 22, 9, 2), 45)), hole(rot(rr(33, 0, 22, 9, 2), 135)), hole(rot(rr(33, 0, 22, 9, 2), 225)), hole(rot(rr(33, 0, 22, 9, 2), 315))], 0.1, 0],
    ["image", "Image", [rr(0, 0, 96, 76, 8), hole(rr(0, 0, 82, 62, 4)), poly([[-34, 24], [-10, -6], [6, 12], [16, 2], [34, 24]]), circ(18, -14, 8)], 0.06, 2],
    ["ticket", "Ticket", ticket(), 0.2, 2],
    ["shield", "Shield", [poly([[0, -46], [40, -32], [38, 6], [0, 46], [-38, 6], [-40, -32]])], 0.26, 6],
    ["box", "Box", [poly([[0, -46], [40, -24], [40, 24], [0, 46], [-40, 24], [-40, -24]]), hole(cap(0, 8, 0, 38, 5)), hole(cap(-6, -3, -32, -18, 5)), hole(cap(6, -3, 32, -18, 5))], 0.12, 3],
    ["headset", "Headset", [band(0, 4, 34, 42, 180, 360), rr(-38, 16, 16, 32, 6), rr(38, 16, 16, 32, 6), cap(38, 30, 10, 42, 5)], 0.08, 0],
    ["exit", "Exit", [poly([[-40, -46], [10, -46], [10, -18], [0, -18], [0, -36], [-30, -36], [-30, 36], [0, 36], [0, 18], [10, 18], [10, 46], [-40, 46]]), poly([[-12, -6], [24, -6], [24, -20], [46, 0], [24, 20], [24, 6], [-12, 6]])], 0.07, 2],
    ["tag", "Tag", [poly([[-46, 0], [-4, -42], [38, -42], [46, -34], [46, 4], [4, 46]]), hole(circ(24, -20, 8))], 0.18, 4],
    ["map", "Map", [poly([[-46, -34], [-16, -44], [16, -34], [46, -44], [46, 34], [16, 44], [-16, 34], [-46, 44]]), hole(rr(-16, 0, 4, 60, 2)), hole(rr(16, 0, 4, 60, 2))], 0.14, 2],
    ["speaker", "Speaker", [poly([[-44, -16], [-20, -16], [4, -40], [4, 40], [-20, 16], [-44, 16]]), band(6, 0, 20, 28, -50, 50), band(6, 0, 34, 42, -50, 50)], 0.1, 2],
    ["bolt", "Bolt", [poly([[10, -48], [-32, 6], [-4, 6], [-12, 48], [32, -8], [4, -8]])], 0.14, 2],
    ["sun", "Sun", [circ(0, 0, 22)].concat([0, 1, 2, 3, 4, 5, 6, 7].map(ray)), 0.1, 0],
    ["triangle", "Triangle", [poly([[0, -44], [50, 40], [-50, 40]])], 0.2, 8],
    ["cursor", "Cursor", [poly(CURSOR)], 0.14, 2],
    ["mouse", "Mouse", [rr(0, 0, 52, 82, 26), hole(rr(0, -22, 8, 18, 4))], 0.24, 0],
    ["arrow", "Arrow", [poly([[-46, -10], [10, -10], [10, -30], [46, 0], [10, 30], [10, 10], [-46, 10]])], 0.16, 3],
    ["chevron", "Chevron", [poly([[-42, -14], [-30, -26], [0, 4], [30, -26], [42, -14], [0, 28]])], 0.1, 3],
    ["x", "X", [rot(cross(8, 46), 45)], 0.1, 2],
    ["done", "Done", [poly([[-46, 2], [-34, -10], [-14, 10], [32, -36], [44, -24], [-14, 34]])], 0.1, 3],
    ["download", "Download", [poly([[-8, -46], [8, -46], [8, 0], [24, 0], [0, 26], [-24, 0], [-8, 0]]), poly([[-46, 10], [-34, 10], [-34, 34], [34, 34], [34, 10], [46, 10], [46, 46], [-46, 46]])], 0.08, 2],
    ["menu", "Menu", [rr(0, -28, 88, 14, 7), rr(0, 0, 88, 14, 7), rr(0, 28, 88, 14, 7)], 0.07, 0],
    ["chart", "Chart", [rr(-30, 22, 20, 44, 4), rr(0, 10, 20, 68, 4), rr(30, -2, 20, 92, 4)], 0.1, 0],
    ["target", "Target", [circ(0, 0, 46), hole(circ(0, 0, 36)), circ(0, 0, 26), hole(circ(0, 0, 16)), circ(0, 0, 7)], 0.05, 0],
    ["eye", "Eye", [ell(0, 0, 48, 30), hole(circ(0, 0, 19)), circ(0, 0, 10)], 0.12, 0],
    ["bulb", "Idea", [circ(0, -12, 30), rr(0, 20, 30, 20, 4), rr(0, 37, 22, 8, 4)], 0.24, 0],
    ["lock", "Lock", [rr(0, 14, 72, 56, 10), band(0, -10, 15, 26, 180, 360), rr(-20.5, -2, 11, 18, 0), rr(20.5, -2, 11, 18, 0), hole(circ(0, 10, 7)), hole(rr(0, 20, 6, 14, 3))], 0.2, 2],
    ["mic", "Mic", [rr(0, -16, 32, 56, 16), band(0, -6, 26, 34, 0, 180), cap(0, 30, 0, 42, 8), rr(0, 44, 40, 8, 4)], 0.1, 0],
    ["folder", "Folder", [poly([[-46, -34], [-12, -34], [-4, -24], [46, -24], [46, 38], [-46, 38]])], 0.24, 5],
    ["people", "People", [circ(0, -18, 17), rr(0, 28, 54, 34, 17), circ(-32, -10, 12), rr(-34, 26, 30, 28, 14), circ(32, -10, 12), rr(34, 26, 30, 28, 14)], 0.14, 0],
    ["phone", "Phone", [rr(0, 0, 58, 94, 12), hole(rr(0, -4, 46, 70, 4)), hole(circ(0, 38, 4))], 0.06, 0],
    ["plane", "Plane", [rot(poly([[0, -48], [6, -40], [6, -12], [46, 10], [46, 18], [6, 6], [6, 30], [18, 40], [18, 46], [0, 41], [-18, 46], [-18, 40], [-6, 30], [-6, 6], [-46, 18], [-46, 10], [-6, -12], [-6, -40]]), 45)], 0.1, 2],
    ["power", "Power", [band(0, 4, 30, 40, -55, 235), cap(0, -44, 0, -6, 10)], 0.06, 0],
    ["reset", "Reset", [band(0, 2, 28, 40, -40, 250), poly([[6, -48], [40, -38], [16, -12]])], 0.08, 2],
    ["trash", "Trash", [rr(0, 12, 64, 70, 6), rr(0, -32, 84, 10, 4), rr(0, -40, 26, 10, 3), hole(rr(-14, 12, 6, 48, 3)), hole(rr(0, 12, 6, 48, 3)), hole(rr(14, 12, 6, 48, 3))], 0.1, 0],
    ["wifi", "Wi-Fi", [band(0, 36, 62, 74, 225, 315), band(0, 36, 40, 52, 225, 315), circ(0, 34, 9)], 0.06, 2],
    ["pencil", "Pencil", [rot(poly([[-44, -9], [28, -9], [46, 0], [28, 9], [-44, 9]]), -45)], 0.14, 2],
    ["bot", "Bot", [rr(0, 8, 78, 58, 16), hole(circ(-16, 6, 8)), hole(circ(16, 6, 8)), cap(0, -22, 0, -36, 6), circ(0, -40, 7), rr(-44, 8, 8, 22, 3), rr(44, 8, 8, 22, 3)], 0.16, 0],
    ["car", "Car", [poly([[-46, 4], [-32, -24], [32, -24], [46, 4], [46, 28], [-46, 28]]), hole(poly([[-24, -14], [24, -14], [32, 2], [-32, 2]])), circ(-26, 30, 11), circ(26, 30, 11)], 0.14, 4],
    ["wrench", "Tools", [cap(-30, 30, 14, -14, 16), circ(22, -22, 20), hole(rot(rr(27, -27, 10, 18, 3), 45, 27, -27))], 0.12, 2]
  ];

  // ------------------------------------------------------------------ tracing a picture (PNG / SVG) into icon paths
  // The picture is drawn big and smooth, its outline found with marching squares, simplified, and turned into
  // smooth curves (sharp corners stay sharp). Outlines inside an odd number of others are holes.
  var TN = 384, PADN = 24;
  function grid(src) {
    var c = document.createElement("canvas"); c.width = TN; c.height = TN;
    var g = c.getContext("2d"), w = src.naturalWidth || src.width, h = src.naturalHeight || src.height, k = (TN - PADN) / Math.max(w, h);
    g.imageSmoothingEnabled = true; g.imageSmoothingQuality = "high";
    g.drawImage(src, (TN - w * k) / 2, (TN - h * k) / 2, w * k, h * k);
    var d = g.getImageData(0, 0, TN, TN).data, N = TN * TN, a = new Float32Array(N), i, opaque = true, lum;
    for (i = 0; i < N; i++) if (d[i * 4 + 3] < 250) { opaque = false; break; }
    for (i = 0; i < N; i++) {
      if (!opaque) a[i] = d[i * 4 + 3] / 255;
      else { lum = (d[i * 4] * 0.3 + d[i * 4 + 1] * 0.59 + d[i * 4 + 2] * 0.11) / 255; a[i] = 1 - lum; }   // no transparency: dark = shape
    }
    // a small picture blown up keeps its pixel steps: soften by about half a source pixel so the outline comes out smooth
    var r = Math.round(k * 0.5);
    if (r >= 1) { a = boxF(a, r); a = boxF(a, r); }
    for (i = 0; i < TN; i++) { a[i] = 0; a[(TN - 1) * TN + i] = 0; a[i * TN] = 0; a[i * TN + TN - 1] = 0; }
    return a;
  }
  function boxF(a, r) {
    var t = new Float32Array(TN * TN), o = new Float32Array(TN * TN), x, y, k, acc, n = 2 * r + 1;
    for (y = 0; y < TN; y++) {
      acc = 0; for (k = -r; k <= r; k++) acc += a[y * TN + Math.min(TN - 1, Math.max(0, k))];
      for (x = 0; x < TN; x++) { t[y * TN + x] = acc / n; acc += a[y * TN + Math.min(TN - 1, x + r + 1)] - a[y * TN + Math.max(0, x - r)]; }
    }
    for (x = 0; x < TN; x++) {
      acc = 0; for (k = -r; k <= r; k++) acc += t[Math.min(TN - 1, Math.max(0, k)) * TN + x];
      for (y = 0; y < TN; y++) { o[y * TN + x] = acc / n; acc += t[Math.min(TN - 1, y + r + 1) * TN + x] - t[Math.max(0, y - r) * TN + x]; }
    }
    return o;
  }
  function contours(a) {
    var iso = 0.5, segs = {}, x, y, v0, v1, v2, v3, idx, k, loops = [];
    function pt(key) {
      var p = key.split(","), t, x1 = +p[1], y1 = +p[2];
      if (p[0] === "h") { t = (iso - a[y1 * TN + x1]) / (a[y1 * TN + x1 + 1] - a[y1 * TN + x1]); return [x1 + t, y1]; }
      t = (iso - a[y1 * TN + x1]) / (a[(y1 + 1) * TN + x1] - a[y1 * TN + x1]); return [x1, y1 + t];
    }
    function link(e1, e2) { (segs[e1] = segs[e1] || []).push(e2); (segs[e2] = segs[e2] || []).push(e1); }
    for (y = 0; y < TN - 1; y++) for (x = 0; x < TN - 1; x++) {
      v0 = a[y * TN + x] > iso; v1 = a[y * TN + x + 1] > iso; v2 = a[(y + 1) * TN + x + 1] > iso; v3 = a[(y + 1) * TN + x] > iso;
      idx = (v0 ? 1 : 0) | (v1 ? 2 : 0) | (v2 ? 4 : 0) | (v3 ? 8 : 0);
      if (idx === 0 || idx === 15) continue;
      var T = "h," + x + "," + y, R = "v," + (x + 1) + "," + y, B = "h," + x + "," + (y + 1), L = "v," + x + "," + y;
      switch (idx) {
        case 1: case 14: link(L, T); break;
        case 2: case 13: link(T, R); break;
        case 3: case 12: link(L, R); break;
        case 4: case 11: link(R, B); break;
        case 6: case 9: link(T, B); break;
        case 7: case 8: link(L, B); break;
        case 5: case 10:
          var mid = (a[y * TN + x] + a[y * TN + x + 1] + a[(y + 1) * TN + x + 1] + a[(y + 1) * TN + x]) / 4 > iso;
          if ((idx === 5) === mid) { link(L, B); link(T, R); } else { link(L, T); link(R, B); }
          break;
      }
    }
    var used = {};
    for (k in segs) {
      if (used[k] || !segs.hasOwnProperty(k)) continue;
      var loop = [], cur = k, prev = null, guard = 0;
      while (cur && !used[cur] && guard++ < 100000) {
        used[cur] = 1; loop.push(pt(cur));
        var nx = segs[cur], nxt = null;
        for (var j = 0; j < nx.length; j++) if (nx[j] !== prev && !used[nx[j]]) { nxt = nx[j]; break; }
        prev = cur; cur = nxt;
      }
      if (loop.length >= 6) loops.push(loop);
    }
    return loops;
  }
  function rdp(pts, eps) {
    if (pts.length < 4) return pts;
    var keep = new Uint8Array(pts.length), st = [[0, pts.length - 1]], s, e, i, dmax, id, d, ax, ay, bx, by, L;
    keep[0] = keep[pts.length - 1] = 1;
    while (st.length) {
      s = st.pop(); e = s[1]; s = s[0]; dmax = 0; id = -1;
      ax = pts[s][0]; ay = pts[s][1]; bx = pts[e][0]; by = pts[e][1]; L = Math.sqrt((bx - ax) * (bx - ax) + (by - ay) * (by - ay)) || 1;
      for (i = s + 1; i < e; i++) { d = Math.abs((bx - ax) * (ay - pts[i][1]) - (ax - pts[i][0]) * (by - ay)) / L; if (d > dmax) { dmax = d; id = i; } }
      if (dmax > eps && id > 0) { keep[id] = 1; st.push([s, id], [id, e]); }
    }
    return pts.filter(function (p, i2) { return keep[i2]; });
  }
  // even out the wobble a small picture leaves in the outline; real corners (a sharp turn over a few points) stay put
  function relax(pts) {
    var n = pts.length, K = 8, corner = new Uint8Array(n), i, a, b, ux, uy, wx, wy, l1, l2, pass, q;
    if (n < 12) return pts;
    for (i = 0; i < n; i++) {
      a = pts[(i - K + n) % n]; b = pts[(i + K) % n];
      ux = pts[i][0] - a[0]; uy = pts[i][1] - a[1]; wx = b[0] - pts[i][0]; wy = b[1] - pts[i][1];
      l1 = Math.sqrt(ux * ux + uy * uy) || 1; l2 = Math.sqrt(wx * wx + wy * wy) || 1;
      if ((ux * wx + uy * wy) / (l1 * l2) < 0.2) corner[i] = 1;
    }
    for (pass = 0; pass < 6; pass++) {
      q = pts.slice();
      for (i = 0; i < n; i++) {
        if (corner[i]) continue;
        a = pts[(i - 1 + n) % n]; b = pts[(i + 1) % n];
        q[i] = [pts[i][0] * 0.5 + (a[0] + b[0]) * 0.25, pts[i][1] * 0.5 + (a[1] + b[1]) * 0.25];
      }
      pts = q;
    }
    return pts;
  }
  function closedRdp(pts, eps) {
    // split the loop at its farthest point so both halves simplify well
    var far = 0, fd = 0, i, d;
    for (i = 1; i < pts.length; i++) { d = Math.pow(pts[i][0] - pts[0][0], 2) + Math.pow(pts[i][1] - pts[0][1], 2); if (d > fd) { fd = d; far = i; } }
    var a1 = rdp(pts.slice(0, far + 1), eps), a2 = rdp(pts.slice(far).concat([pts[0]]), eps);
    return a1.slice(0, -1).concat(a2.slice(0, -1));
  }
  function inside(p, poly0) {
    var c = false, i, j, n = poly0.length;
    for (i = 0, j = n - 1; i < n; j = i++) {
      var a = poly0[i], b = poly0[j];
      if (((a[1] > p[1]) !== (b[1] > p[1])) && (p[0] < (b[0] - a[0]) * (p[1] - a[1]) / (b[1] - a[1]) + a[0])) c = !c;
    }
    return c;
  }
  function smoothPath(pts) {
    var n = pts.length, v = [], ii = [], oo = [], k;
    for (k = 0; k < n; k++) {
      var p = pts[k], a = pts[(k - 1 + n) % n], b = pts[(k + 1) % n];
      var ux = p[0] - a[0], uy = p[1] - a[1], wx = b[0] - p[0], wy = b[1] - p[1], lu = Math.sqrt(ux * ux + uy * uy) || 1, lw = Math.sqrt(wx * wx + wy * wy) || 1;
      var cos = (ux * wx + uy * wy) / (lu * lw);
      v.push([p[0], p[1]]);
      if (cos < 0.35) { ii.push([0, 0]); oo.push([0, 0]); continue; }   // a real corner
      var dx = b[0] - a[0], dy = b[1] - a[1], ld = Math.sqrt(dx * dx + dy * dy) || 1;
      dx /= ld; dy /= ld;
      ii.push([-dx * lu / 3, -dy * lu / 3]); oo.push([dx * lw / 3, dy * lw / 3]);
    }
    return { v: v, i: ii, o: oo, c: 1 };
  }
  // -> { paths, thick } in the 100-unit box, or null when nothing was found
  function trace(src) {
    var a = grid(src), loops = contours(a);
    if (!loops.length) return null;
    var minx = 1e9, miny = 1e9, maxx = -1e9, maxy = -1e9, k, j;
    loops = loops.map(function (l) { return closedRdp(relax(l), 0.5); }).filter(function (l) { return l.length >= 3; });
    loops.forEach(function (l) { l.forEach(function (p) { if (p[0] < minx) minx = p[0]; if (p[0] > maxx) maxx = p[0]; if (p[1] < miny) miny = p[1]; if (p[1] > maxy) maxy = p[1]; }); });
    // the picture's own frame is the 100-unit box: an icon keeps exactly its place and size inside its file
    var sc = 100 / (TN - PADN), cx = TN / 2, cy = TN / 2;
    // drop specks (smaller than 1.5 % of the icon)
    loops = loops.filter(function (l) { var b = poly(l); return Math.abs(area(b)) * sc * sc > 15; });
    var paths = [];
    for (k = 0; k < loops.length; k++) {
      var depth = 0;
      for (j = 0; j < loops.length; j++) if (j !== k && inside(loops[k][0], loops[j])) depth++;
      var pts = loops[k].map(function (p) { return [Math.round((p[0] - cx) * sc * 100) / 100, Math.round((p[1] - cy) * sc * 100) / 100]; });
      var sp = smoothPath(pts);
      paths.push(depth % 2 ? hole(sp) : cw(sp));
    }
    // half thickness: the deepest inside point of the shape, against its size
    var N = TN * TN, on = 0, maxd = 0, i;
    for (i = 0; i < N; i++) if (a[i] > 0.5) on++;
    var thick = Math.max(0.04, Math.min(0.3, Math.sqrt(on) / (TN - PADN) * 0.25));
    return { paths: paths, thick: Math.round(thick * 1000) / 1000 };
  }

  window.HydraGlassIcons = { list: ICONS, rr: rr, poly: poly, circ: circ, hole: hole, area: area, trace: trace };
})();
