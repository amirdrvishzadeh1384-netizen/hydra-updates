/* Hydra Studio · studio-subs.js
 * The Subtitles section: listens to the voice of a video OFFLINE (whisper.cpp + ffmpeg from the "speech folder"),
 * lets you read and fix the lines (the Persian spell checker underlines the problems), and builds one text layer per line in the open comp
 * (in Premiere Pro: imports them as a caption .srt file).
 * An .srt can be imported or exported too. The pure logic is subs-core.js; the After Effects side is host.jsx (ops_sub*, ops_pick*, ops_saveText).
 */
(function () {
  "use strict";
  var ST = {
    tools: null, comp: null, media: null, trim: true, lang: "fa", lines: 56, model: "", prompt: "", rules: "", autofix: true, builtin: true, words: 0, dictErr: "", dl: false, fixed: [], segs: null, gen: 0, busy: "", prog: 0, note: "", err: "", proc: null, engine: null,
    style: { font: "", size: 54, color: "#ffffff", stroke: true, bottom: 12, chars: 28 }, closeGaps: true, made: 0, hint: "", edit: false
  };
  var X = null, S = null;

  function settingsFile() { return X.files && X.files.data ? X.files.path.join(X.files.data, "subs-settings.json") : ""; }
  function loadSettings() {
    try {
      var f = settingsFile();
      if (f && X.files.fs.existsSync(f)) {
        var o = JSON.parse(X.files.fs.readFileSync(f, "utf8")) || {}, k;
        for (k in o.style || {}) ST.style[k] = o.style[k];
        if (o.lang) ST.lang = o.lang;
        if (o.lines !== undefined) ST.lines = o.lines;
        if (o.model) ST.model = o.model;
        if (o.prompt) ST.prompt = o.prompt;
        if (o.rules) ST.rules = o.rules;
        if (o.autofix === false) ST.autofix = false;
        if (o.builtin === false) ST.builtin = false;
        if (o.words) ST.words = o.words | 0;
      }
    } catch (e) {}
  }
  function saveSettings() { try { var f = settingsFile(); if (f) { X.files.mkdirp(X.files.data); X.files.fs.writeFileSync(f, JSON.stringify({ style: ST.style, lang: ST.lang, lines: ST.lines, model: ST.model, prompt: ST.prompt, rules: ST.rules, autofix: ST.autofix, builtin: ST.builtin, words: ST.words }, null, 1)); } } catch (e) {} }

  function node() {
    try { return { cp: window.require("child_process"), os: window.require("os") }; } catch (e) { return null; }
  }
  function refreshTools() {
    if (!X.files) { ST.tools = null; return; }
    ST.tools = S.findTools({ fs: X.files.fs, path: X.files.path, platform: window.process.platform, dataDir: X.files.data, pathEnv: (window.process.env || {}).PATH || "" });
    if (ST.tools.models.length && !ST.tools.models.some(function (m) { return m.path === ST.model; })) ST.model = ST.tools.models[0].path;
  }
  function baseName(p) { return String(p || "").split(/[\\\/]/).pop(); }
  function hex(c) { var m = /^#?([0-9a-f]{6})$/i.exec(c || ""); if (!m) return [1, 1, 1]; return [parseInt(m[1].slice(0, 2), 16) / 255, parseInt(m[1].slice(2, 4), 16) / 255, parseInt(m[1].slice(4, 6), 16) / 255]; }
  // inside Premiere Pro: clips and sequences instead of layers and comps, and the lines go in as a caption (.srt) file
  function PP() { return !!(X && X.ppro); }
  function say(msg, bad) { ST.note = bad ? "" : msg; ST.err = bad ? msg : ""; }

  // ---- source of the voice
  async function useLayer(box) {
    var r = await X.cep.call("ops_subSource");
    if (!r.ok) { say(r.error || (PP() ? "Couldn’t read the sequence" : "Couldn’t read the composition"), true); return draw(box); }
    ST.comp = r.comp;
    if (r.found) { ST.media = { path: r.path, name: r.name, layer: true, startTime: r.startTime, inPoint: r.inPoint, outPoint: r.outPoint }; say((PP() ? "Using the clip “" : "Using the layer “") + r.name + "”."); }
    else say(r.note || (r.comp ? (PP() ? "Select the video or audio clip in the timeline first." : "Select the video or audio layer in the timeline first.") : (PP() ? "Open a sequence first." : "Open a composition first.")), true);
    draw(box);
  }
  async function pickFile(box) {
    var r = await X.cep.call("ops_pickMedia");
    if (!r.ok) { say(r.error || "Couldn’t open the file", true); return draw(box); }
    if (r.path) { ST.media = { path: r.path, name: r.name || baseName(r.path), layer: false }; say(""); }
    draw(box);
  }

  // ---- listening
  function run(cmd, args, onLine) {
    var n = node(), tail = [];
    return new Promise(function (resolve, reject) {
      var p;
      try { p = n.cp.spawn(cmd, args, { windowsHide: true }); } catch (e) { return reject(new Error("Couldn’t start " + baseName(cmd) + ": " + (e && e.message))); }
      ST.proc = p;
      function eat(b) { String(b).split(/[\r\n]+/).forEach(function (l) { if (!l) return; tail.push(l); if (tail.length > 14) tail.shift(); if (onLine) onLine(l); }); }
      p.stdout.on("data", eat); p.stderr.on("data", eat);
      p.on("error", function (e) { reject(new Error(e && e.code === "EACCES" ? "The system blocked " + baseName(cmd) + " (permission). On a Mac run in Terminal:  xattr -dr com.apple.quarantine <the speech folder>  and  chmod +x on the program." : "Couldn’t start " + baseName(cmd) + ": " + (e && e.message))); });
      p.on("close", function (code, sig) { ST.proc = null; if (sig) reject(new Error("Stopped.")); else if (code === 0) resolve(); else reject(new Error(baseName(cmd) + " stopped with an error:\n" + tail.slice(-5).join("\n"))); });
    });
  }
  function exec(p) { try { if (window.process.platform !== "win32") X.files.fs.chmodSync(p, 493); } catch (e) {} }

  async function listen(box) {
    var gen = ST.gen, t = ST.tools, n = node(), m = ST.media, tmp, wav, out, start = 0, dur = 0, offset = 0, model;
    if (!n) { say("This part needs the panel’s Node.js, which is off.", true); return draw(box); }
    if (!m) { say(PP() ? "Choose the voice first: a selected clip, or a file." : "Choose the voice first: a selected layer, or a file.", true); return draw(box); }
    if (S.missing(t).length) { say("The speech folder is not complete yet (see the top card).", true); return draw(box); }
    model = ST.model || t.models[0].path;
    if (m.layer) {
      if (ST.trim) { start = Math.max(0, m.inPoint - m.startTime); dur = Math.max(0, m.outPoint - m.inPoint); offset = m.inPoint; } else offset = m.startTime;
    }
    tmp = n.os.tmpdir();
    wav = X.files.path.join(tmp, "hydra-subs-" + Date.now() + ".wav");
    out = X.files.path.join(tmp, "hydra-subs-" + Date.now());
    ST.busy = "Reading the sound…"; ST.prog = 2; ST.segs = null; say(""); draw(box);
    exec(t.ffmpeg); exec(t.whisper);
    try {
      var total = dur || 0;
      await run(t.ffmpeg, S.ffmpegArgs(m.path, wav, start, dur), function (l) {
        var c = S.parseClock(l);
        if (c !== null && total) { ST.prog = Math.min(10, 2 + 8 * c / total); tickProg(box); }
      });
      ST.busy = "Listening… (the first minute can be slow)"; ST.prog = 10; draw(box);
      await run(t.whisper, S.whisperArgs({ model: model, wav: wav, out: out, lang: ST.lang === "auto" ? "auto" : ST.lang, maxLen: ST.lines || 0, prompt: ST.prompt, threads: Math.max(2, Math.min(8, n.os.cpus().length - 1)) }), function (l) {
        var p = S.parseProgress(l);
        if (p !== null) { ST.prog = 10 + p * 0.9; tickProg(box); }
      });
      var js = X.files.fs.readFileSync(out + ".json", "utf8");
      var segs = S.parseWhisperJson(js);
      try { X.files.fs.unlinkSync(wav); X.files.fs.unlinkSync(out + ".json"); } catch (e1) {}
      if (!segs.length) throw new Error("Nothing was heard. Is there speech in this part? Is the language right?");
      ST.segs = S.tidy(S.splitWords(segs, ST.words), { closeGaps: ST.closeGaps ? 0.35 : 0, minDur: 0.6, maxChars: ST.style.chars }).map(function (g) { g.s += offset; g.e += offset; return g; });
      ST.edit = false;
      await ensureEngine();
      postProcess();
      say(segs.length + " lines." + (ST.fixed.length ? " Auto-corrected " + ST.fixed.length + (ST.fixed.length === 1 ? " word: " : " words: ") + ST.fixed.slice(0, 8).map(function (c) { return c.from + " → " + c.to; }).join("،  ") + (ST.fixed.length > 8 ? " …" : "") + "." : "") + " Read the lines, fix what needs fixing, then create the layers.");
    } catch (e) {
      try { X.files.fs.unlinkSync(wav); } catch (e2) {}
      if (gen !== ST.gen) return;   // the project changed while listening: that listening was dropped on purpose
      say(String(e && e.message || e), true);
    }
    if (gen !== ST.gen) return;
    ST.busy = ""; ST.prog = 0; ST.proc = null;
    await ensureEngine();
    draw(box);
  }
  // the words the speech engine got wrong: your own corrections first, then the safe spelling corrections (hint words, look-alike letters)
  function postProcess() {
    var hints = S.parseHints(ST.prompt), rules = (ST.builtin ? S.parseRules(S.BUILTIN) : []).concat(S.parseRules(ST.rules)), all = [];
    if (ST.engine && hints.length) ST.engine.addWords(hints);
    (ST.segs || []).forEach(function (g) {
      g.text = S.applyRules(g.text, rules, all);
      if (ST.engine && ST.autofix) { var r = ST.engine.autoFix(g.text, hints); g.text = r.text; all = all.concat(r.changes); }
    });
    ST.fixed = all;
  }
  var lastTick = 0;
  function tickProg(box) {
    var now = Date.now(); if (now - lastTick < 250) return; lastTick = now;
    var f = box.querySelector(".sb-fill"); if (f) f.style.width = Math.round(ST.prog) + "%";
  }
  function stop(box) { if (ST.proc) { try { ST.proc.kill(); } catch (e) {} } }

  // ---- the spell checker (when its dictionary is there)
  function ensureEngine() {
    if (ST.engine || !window.HydraSpellUI || !HydraSpellUI.ready()) return Promise.resolve();
    return HydraSpellUI.engine().then(function (e) {
      ST.engine = e;
      ST.dictErr = e ? "" : (HydraSpellUI.error() || "the Persian dictionary isn’t loaded");
    });
  }
  async function getDict(box) {
    ST.dl = true; draw(box);
    try { await HydraSpellUI.download(); ST.dictErr = ""; await ensureEngine(); X.toast("Dictionary ready"); }
    catch (e) { ST.dictErr = String(e && e.message || e); }
    ST.dl = false; draw(box);
  }
  // cuts the lines below into short ones (max words), keeps the times
  function resplit(box) {
    if (!ST.segs || !ST.words) return;
    ST.segs = S.tidy(S.splitWords(ST.segs, ST.words), { closeGaps: 0, minDur: 0.4, maxChars: ST.style.chars });
    ST.segs.forEach(function (g) { delete g.o; delete g.i; });
    say(ST.segs.length + " lines now.");
    draw(box);
  }
  function issues(text) { try { return ST.engine ? ST.engine.analyze(text) : []; } catch (e) { return []; } }

  // ---- the lines
  function segRow(g, i, box) {
    var row = X.h("div", { class: "sb-row" }), t1 = X.h("input", { class: "sb-time", type: "text", value: S.fmtTime(g.s, false).slice(3) }), t2 = X.h("input", { class: "sb-time", type: "text", value: S.fmtTime(g.e, false).slice(3) });
    var ta = X.h("textarea", { class: "sb-text", rows: String(Math.min(3, g.text.split("\n").length)), dir: "auto", spellcheck: "false" }), badge = X.h("span", { class: "sb-badge" }), del = X.h("button", { type: "button", class: "sb-x", title: "Remove this line" }, ["✕"]);
    ta.value = g.text;
    function mark() { var n = issues(g.text).filter(function (q) { return q.kind !== "space" || true; }).length; badge.textContent = n ? String(n) : ""; badge.className = "sb-badge" + (n ? " on" : ""); }
    ta.addEventListener("input", function () { g.text = ta.value; mark(); refreshGo(box); });
    function time(inp, key) { inp.addEventListener("change", function () { var v = S.parseTime(inp.value); if (isNaN(v)) { inp.value = S.fmtTime(g[key], false).slice(3); return; } g[key] = v; refreshGo(box); }); }
    time(t1, "s"); time(t2, "e");
    del.addEventListener("click", function () { ST.segs.splice(i, 1); draw(box); });
    mark();
    row.appendChild(X.h("div", { class: "sb-times" }, [t1, X.h("span", {}, ["→"]), t2, badge].concat(ST.edit ? [] : [del])));
    row.appendChild(ta);
    return row;
  }
  function fixSpelling(box) {
    var n = 0;
    if (!ST.engine) return;
    ST.segs.forEach(function (g) { var q = issues(g.text), t = ST.engine.applySure(g.text, q); if (t !== g.text) { g.text = t; n++; } });
    say(n ? "Fixed the sure spelling problems in " + n + " lines. The rest is for you to read." : "Nothing sure to fix.");
    draw(box);
  }
  async function exportSrt(box) {
    var r = await X.cep.call("ops_saveText", "subtitles.srt", S.toSRT(ST.segs.map(function (g) { return { s: g.s, e: g.e, text: g.text }; })));
    if (!r.ok) say(r.error || "Couldn’t save", true); else if (r.path) say("Saved " + baseName(r.path));
    draw(box);
  }
  async function importSrt(box) {
    var r = await X.cep.call("ops_pickText");
    if (!r.ok) { say(r.error || "Couldn’t read the file", true); return draw(box); }
    if (!r.path) return;
    var segs = S.parseSRT(r.text);
    if (!segs.length) { say("That file has no subtitle lines.", true); return draw(box); }
    ST.segs = segs; ST.edit = false; say(segs.length + " lines from " + baseName(r.path) + "."); await ensureEngine(); draw(box);
  }
  async function loadComp(box) {
    var r = await X.cep.call("ops_subList");
    if (!r.ok) { say(r.error || "Couldn’t read the composition", true); return draw(box); }
    var list = r.texts.filter(function (t) { return !r.anySub || t.sub; }).sort(function (a, b) { return a.s - b.s; });
    if (!list.length) { say("There are no text layers in this composition.", true); return draw(box); }
    ST.segs = list.map(function (t) { return { s: t.s, e: t.e, text: t.text, i: t.i, name: t.name, o: { s: t.s, e: t.e, text: t.text } }; });
    ST.edit = true; say(list.length + " subtitle layers. Change the text or the times, then apply.");
    await ensureEngine(); draw(box);
  }
  function changedRows() { return (ST.segs || []).filter(function (g) { return g.o && (g.text !== g.o.text || Math.abs(g.s - g.o.s) > 0.0005 || Math.abs(g.e - g.o.e) > 0.0005); }); }
  function refreshGo(box) {
    var b = box.querySelector(".sb-go"); if (!b || !ST.edit) return;
    var n = changedRows().length;
    b.textContent = "Apply " + n + (n === 1 ? " change" : " changes") + " in AE"; b.disabled = !n;
  }
  async function applyComp(box) {
    var ch = changedRows();
    ST.busy = "Writing the changes…"; draw(box);
    var r = await X.cep.call("ops_subUpdate", JSON.stringify(ch.map(function (g) { return { i: g.i, name: g.name, text: g.text, s: g.s, e: g.e }; })));
    ST.busy = "";
    if (!r.ok) say(r.error || "Couldn’t write the changes", true);
    else { ch.forEach(function (g) { g.o = { s: g.s, e: g.e, text: g.text }; }); say(r.updated + " layers updated." + (r.missed ? " " + r.missed + " layers were not found." : "")); }
    draw(box);
  }
  async function make(box) {
    var spec = { segs: ST.segs.map(function (g) { return { s: g.s, e: g.e, text: g.text }; }), offset: 0, style: { font: ST.style.font, size: ST.style.size, color: hex(ST.style.color), stroke: ST.style.stroke ? 1 : 0, strokeW: Math.max(2, Math.round(ST.style.size / 9)), bottom: ST.style.bottom } };
    ST.busy = PP() ? "Making the caption file…" : "Creating the layers…"; ST.prog = 0; draw(box);
    var r = await X.cep.call("ops_subMake", JSON.stringify(spec));
    ST.busy = "";
    if (!r.ok) say(r.error || (PP() ? "Couldn’t import the subtitles" : "Couldn’t create the layers"), true);
    else if (PP()) { ST.made = r.made; say(r.made + " lines saved as " + baseName(r.path) + (r.imported ? " and imported into the project. Drag it from the Project panel onto your sequence (it becomes a captions track)." : ". Import it with File → Import.")); }
    else { ST.made = r.made; say(r.made + " text layers are in the composition (Sub 001 …)." + (r.fontBad ? " The font name wasn’t found, so the default font is used." : "")); }
    draw(box);
  }

  // ---- the screen
  function field(label, el) { return X.h("label", { class: "sb-field" }, [X.h("span", {}, [label]), el]); }
  function select(opts, val, on) {
    var s = X.h("select", {}, opts.map(function (o) { var e = X.h("option", { value: o[0] }, [o[1]]); if (String(o[0]) === String(val)) e.selected = true; return e; }));
    s.addEventListener("change", function () { on(s.value); });
    return s;
  }
  function num(val, min, max, on) {
    var i = X.h("input", { type: "number", value: String(val), min: String(min), max: String(max) });
    i.addEventListener("change", function () { var v = parseFloat(i.value); if (!isNaN(v)) on(Math.max(min, Math.min(max, v))); });
    return i;
  }

  function packCard(box) {
    var t = ST.tools, card = X.h("div", { class: "sb-pack" }), miss;
    if (!t) { card.appendChild(X.h("div", { class: "sp-note err" }, ["This part needs the panel’s file access, which is off."])); return card; }
    miss = S.missing(t);
    function line(okk, label, val) { return X.h("div", { class: "sb-line " + (okk ? "ok" : "no") }, [X.h("i", {}, [okk ? "✓" : "✕"]), X.h("b", {}, [label]), X.h("span", {}, [val])]); }
    card.appendChild(line(!!t.whisper, "Whisper", t.whisper ? baseName(t.whisper) : "not found"));
    card.appendChild(line(!!t.ffmpeg, "ffmpeg", t.ffmpeg ? baseName(t.ffmpeg) : "not found"));
    card.appendChild(line(t.models.length > 0, "Model", t.models.length ? t.models.length + (t.models.length === 1 ? " file" : " files") : "not found"));
    if (t.models.length > 1) card.appendChild(field("Model", select(t.models.map(function (m) { return [m.path, m.name + " (" + m.mb + " MB)"]; }), ST.model, function (v) { ST.model = v; saveSettings(); })));
    if (miss.length) {
      card.appendChild(X.h("div", { class: "sp-note" }, ["Put these in the speech folder once (it works offline after that, and you can hand the folder to a friend):",
        X.h("br"), "• whisper-cli (Windows: whisper.cpp release; Mac: brew install whisper-cpp)",
        X.h("br"), "• ffmpeg", X.h("br"), "• a model, e.g. ggml-small.bin (better for Persian: ggml-medium.bin)"]));
    }
    var open = X.h("button", { type: "button", class: "sp-link" }, ["Open the speech folder"]);
    open.addEventListener("click", function () { try { X.files.mkdirp(t.speechDir); } catch (e) {} X.cep.call("ops_reveal", t.speechDir).then(function (r) { if (!r.ok) X.toast(r.error || "Couldn’t open it"); }); });
    var re = X.h("button", { type: "button", class: "sp-link" }, ["Check again"]);
    re.addEventListener("click", function () { refreshTools(); draw(box); });
    card.appendChild(X.h("div", { class: "sp-acts" }, [open, re]));
    return card;
  }

  function draw(box) {
    if (!box || !box.isConnected) return;
    var root = X.h("div", { class: "spell sb" }), busy = !!ST.busy, tools = ST.tools, ready = tools && !S.missing(tools).length;
    root.appendChild(packCard(box));

    // the voice
    var src = X.h("div", { class: "sb-src" });
    var b1 = X.h("button", { type: "button", class: "sp-main" }, [PP() ? "Use selected clip" : "Use selected layer"]), b2 = X.h("button", { type: "button", class: "sp-main" }, ["Choose a file…"]);
    b1.addEventListener("click", function () { useLayer(box); }); b2.addEventListener("click", function () { pickFile(box); });
    if (busy) { b1.disabled = true; b2.disabled = true; }
    src.appendChild(X.h("div", { class: "sp-bar" }, [b1, b2]));
    if (ST.media) {
      src.appendChild(X.h("div", { class: "sp-stats" }, ["Voice: ", X.h("b", {}, [ST.media.name || baseName(ST.media.path)])]));
      if (ST.media.layer) {
        var tr = X.h("label", { class: "sp-only sp-spoken" }, [X.h("input", { type: "checkbox" }), (PP() ? " Only the part used in the sequence" : " Only the part used in the comp")]);
        tr.firstChild.checked = ST.trim; tr.firstChild.addEventListener("change", function () { ST.trim = this.checked; });
        src.appendChild(tr);
      }
    }
    root.appendChild(src);

    root.appendChild(X.h("div", { class: "sb-grid" }, [
      field("Language", select([["fa", "Persian"], ["en", "English"], ["auto", "Detect"]], ST.lang, function (v) { ST.lang = v; saveSettings(); })),
      field("Line length", select([[32, "Short"], [56, "Normal"], [0, "Long"]], ST.lines, function (v) { ST.lines = +v; saveSettings(); })),
      field("Max words per subtitle", select([[0, "No limit"], [3, "3"], [4, "4"], [5, "5"], [6, "6"], [8, "8"], [10, "10"]], ST.words, function (v) { ST.words = +v; saveSettings(); draw(box); }))
    ]));
    if (ST.dictErr) {
      var dn = X.h("div", { class: "sp-note err" }, ["The Persian dictionary isn’t loaded, so the automatic spelling clean-up is off: " + ST.dictErr]);
      var db = X.h("button", { type: "button", class: "sp-main go" }, [ST.dl ? "Downloading…" : "Download the dictionary"]);
      if (ST.dl) db.disabled = true;
      db.addEventListener("click", function () { getDict(box); });
      root.appendChild(dn); root.appendChild(db);
    }

    var pr = X.h("textarea", { class: "sb-hint", rows: "2", dir: "auto", spellcheck: "false", placeholder: "Words that appear in the video (names, terms): ارز دیجیتال، تتر، کیف پول…" });
    pr.value = ST.prompt || "";
    pr.addEventListener("change", function () { ST.prompt = pr.value.trim(); saveSettings(); });
    root.appendChild(field("Hint words (helps Whisper spell them right)", pr));
    var ru = X.h("textarea", { class: "sb-hint", rows: "3", dir: "auto", spellcheck: "false", placeholder: "One per line:  wrong = right\nعرض دیجیتال = ارز دیجیتال" });
    ru.value = ST.rules || "";
    ru.addEventListener("change", function () { ST.rules = ru.value; saveSettings(); });
    var af = X.h("label", { class: "sp-only sp-spoken" }, [X.h("input", { type: "checkbox" }), " Fix the spelling of the words by itself"]);
    af.firstChild.checked = ST.autofix; af.firstChild.addEventListener("change", function () { ST.autofix = this.checked; saveSettings(); });
    var bi = X.h("label", { class: "sp-only sp-spoken" }, [X.h("input", { type: "checkbox" }), " Use the built-in fixes (" + S.parseRules(S.BUILTIN).length + ": تهتر → تتر, ارض دیجیتال → ارز دیجیتال…)"]);
    bi.firstChild.checked = ST.builtin; bi.firstChild.addEventListener("change", function () { ST.builtin = this.checked; saveSettings(); });
    var rd = X.h("details", { class: "sb-style" }, [X.h("summary", {}, ["My corrections"]), field("Words to replace each time (whole words)", ru), bi, af]);
    root.appendChild(rd);

    var go = X.h("button", { type: "button", class: "sp-scan" + (busy ? " busy" : "") }, [busy ? ST.busy : (ST.segs ? "Listen again" : "Listen and write")]);
    go.disabled = busy || !ready || !ST.media;
    go.addEventListener("click", function () { listen(box); });
    root.appendChild(go);
    if (busy && ST.proc) {
      root.appendChild(X.h("div", { class: "sb-prog" }, [X.h("div", { class: "sb-fill", style: "width:" + Math.round(ST.prog) + "%" })]));
      var st = X.h("button", { type: "button", class: "sp-link" }, ["Stop"]); st.addEventListener("click", function () { stop(box); }); root.appendChild(st);
    }
    var imp = X.h("button", { type: "button", class: "sp-link" }, ["…or open an .srt file you already have"]);
    imp.addEventListener("click", function () { importSrt(box); });
    var edc = X.h("button", { type: "button", class: "sp-link" }, ["…or edit the subtitle layers already in this comp"]);
    edc.addEventListener("click", function () { loadComp(box); });
    if (!busy) { root.appendChild(imp); if (!PP()) root.appendChild(edc); }

    if (ST.note) root.appendChild(X.h("div", { class: "sp-note" }, [ST.note]));
    if (ST.err) root.appendChild(X.h("div", { class: "sp-note err", style: "white-space:pre-wrap" }, [ST.err]));

    if (ST.segs && ST.segs.length) {
      var bar = X.h("div", { class: "sp-bar" }), n = 0;
      ST.segs.forEach(function (g) { if (issues(g.text).length) n++; });
      if (ST.engine) {
        var fx = X.h("button", { type: "button", class: "sp-main" }, ["Fix spelling" + (n ? " (" + n + ")" : "")]);
        fx.addEventListener("click", function () { fixSpelling(box); });
        bar.appendChild(fx);
      }
      if (ST.words && !ST.edit) {
        var rs = X.h("button", { type: "button", class: "sp-main" }, ["Cut to " + ST.words + " words"]);
        rs.addEventListener("click", function () { resplit(box); });
        bar.appendChild(rs);
      }
      var ex = X.h("button", { type: "button", class: "sp-main" }, ["Save .srt"]);
      ex.addEventListener("click", function () { exportSrt(box); });
      bar.appendChild(ex);
      var nch = ST.edit ? changedRows().length : 0;
      var mk = X.h("button", { type: "button", class: "sp-main go sb-go" }, [ST.edit ? "Apply " + nch + (nch === 1 ? " change" : " changes") + " in AE" : (PP() ? "Import " + ST.segs.length + " lines as captions" : "Create " + ST.segs.length + " layers")]);
      mk.addEventListener("click", function () { if (ST.edit) applyComp(box); else make(box); });
      if (busy || (ST.edit && !nch)) mk.disabled = true;
      bar.appendChild(mk);
      root.appendChild(bar);

      var det = X.h("details", { class: "sb-style" }, [X.h("summary", {}, ["Look of the subtitles"])]), fnt = X.h("input", { type: "text", value: ST.style.font, placeholder: "Font name, e.g. Vazirmatn-Bold (empty = default)" }), col = X.h("input", { type: "color", value: ST.style.color }), sk = X.h("input", { type: "checkbox" });
      fnt.addEventListener("change", function () { ST.style.font = fnt.value.trim(); saveSettings(); });
      col.addEventListener("change", function () { ST.style.color = col.value; saveSettings(); });
      sk.checked = ST.style.stroke; sk.addEventListener("change", function () { ST.style.stroke = sk.checked; saveSettings(); });
      det.appendChild(field("Font (PostScript name)", fnt));
      det.appendChild(X.h("div", { class: "sb-grid" }, [field("Size", num(ST.style.size, 12, 300, function (v) { ST.style.size = v; saveSettings(); })), field("From the bottom, %", num(ST.style.bottom, 0, 90, function (v) { ST.style.bottom = v; saveSettings(); })), field("Colour", col), field("Outline", sk)]));
      if (!PP()) root.appendChild(det);

      var list = X.h("div", { class: "sp-list" });
      ST.segs.slice(0, 600).forEach(function (g, i) { list.appendChild(segRow(g, i, box)); });
      if (ST.segs.length > 600) list.appendChild(X.h("div", { class: "sp-note" }, ["Showing the first 600 lines. Save the .srt to edit the rest elsewhere."]));
      root.appendChild(list);
    } else if (!busy && !ST.note && !ST.err) {
      root.appendChild(X.h("div", { class: "sp-note" }, [PP() ? "Everything runs on this computer, no internet. Select the video or audio clip in your sequence, press Listen and write, then read the lines and import them as captions. The result is a draft: always read it once. You can also open an .srt file you already have, fix its spelling and save it again." : "Everything runs on this computer, no internet. Select the video or audio layer, press Listen and write, then read the lines and create the layers. The result is a draft: always read it once."]));
    }
    box.innerHTML = ""; box.appendChild(root);
  }

  // another project (or comp) was opened: forget what belonged to the old one
  function reset(kind) {
    if (kind === "project") {
      ST.gen++; if (ST.proc) { try { ST.proc.kill(); } catch (e) {} }
      ST.busy = ""; ST.prog = 0; ST.proc = null; ST.media = null; ST.comp = null; ST.segs = null; ST.edit = false; ST.fixed = [];
      say(PP() ? "A different project was opened. Choose the clip or file again." : "A different project was opened. Choose the layer or file again.");
    } else if (!ST.busy) {
      var had = ST.edit || (ST.media && ST.media.layer);
      if (ST.edit) { ST.segs = null; ST.edit = false; }
      if (ST.media && ST.media.layer) ST.media = null;
      ST.comp = null;
      if (had) say(PP() ? "A different sequence is open. Choose the clip again." : "A different composition is open. Choose the layer again.");
    }
  }
  window.HydraSubsUI = {
    reset: reset,
    init: function (ctx) { X = ctx; S = window.HydraSubs; loadSettings(); refreshTools(); },
    render: function (box) { if (!S) return; refreshTools(); ensureEngine().then(function () { if (box.isConnected && !ST.busy && ST.segs) draw(box); }); draw(box); },
    _state: ST
  };
})();
