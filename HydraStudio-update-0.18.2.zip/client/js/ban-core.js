/* Hydra Studio · ban-core.js
 * Banned words: reads a client's list of forbidden words and finds them in a text, whatever the spelling habits
 * (Arabic ي ك, half-spaces, vowel marks, case, word forms like ها / های / ی / م / ش ...). Pure logic, tested with node (test/ban_test.js).
 *   var entries = HydraBan.parseList("کلمه\nعبارت دو کلمه‌ای = جایگزین");
 *   HydraBan.find("متن", entries, { variants: true, inside: false })  -> [{ start, end, found, word, repl }]
 */
(function (root) {
  "use strict";

  var SUFFIX = ["هایی", "های", "ها", "ترین", "تر", "ات", "ان", "ای", "یی", "ی", "ام", "ات", "اش", "مان", "تان", "شان", "م", "ت", "ش", "ه", "ا", "رو", "و"];
  SUFFIX.sort(function (a, b) { return b.length - a.length; });

  function isLetter(c) { return !!c && /[0-9A-Za-zء-يٱ-ۓ۰-۹٠-٩]/.test(c); }
  function normChar(c) {
    if (c === "ي" || c === "ى") return "ی";
    if (c === "ك") return "ک";
    if (c === "ة") return "ه";
    if (c >= "٠" && c <= "٩") return String.fromCharCode(c.charCodeAt(0) - 0x0660 + 0x06F0);
    if (c >= "A" && c <= "Z") return c.toLowerCase();
    return c;
  }
  // normalised text with no spaces and no half-spaces (شرط بندی = شرط‌بندی), where every character came from, and which ones start a word
  function prep(text) {
    var n = "", map = [], sep = [], i, c, gap = true;
    text = String(text || "");
    for (i = 0; i < text.length; i++) {
      c = text.charAt(i);
      if (c === "\u200c" || c === "\u200d" || c === "\u200e" || c === "\u200f" || /[\u064B-\u0652\u0640]/.test(c)) continue;
      if (/\s/.test(c)) { gap = true; continue; }
      n += normChar(c); map.push(i); sep.push(gap); gap = false;
    }
    return { n: n, map: map, sep: sep };
  }

  // "a, b\nc = replacement" -> [{ word, norm, repl }]; # starts a comment line
  function parseList(text) {
    var out = [], seen = {};
    String(text || "").split(/[\n\r،؛,;\t]+/).forEach(function (raw) {
      var line = raw.trim(), i, w, r, nn;
      if (!line || line.charAt(0) === "#") return;
      i = line.indexOf("=");
      w = (i > 0 ? line.slice(0, i) : line).trim(); r = i > 0 ? line.slice(i + 1).trim() : "";
      nn = prep(w).n;
      if (!nn || nn.length < 2 || seen[nn]) return;
      seen[nn] = 1;
      out.push({ word: w, norm: nn, repl: r });
    });
    out.sort(function (a, b) { return b.norm.length - a.norm.length; });
    return out;
  }

  function find(text, entries, opts) {
    opts = opts || {};
    var P = prep(text), n = P.n, sep = P.sep, hits = [], e, k, idx, end, after, j, s, tries, ok, from, m;
    function wordEdge(i) { return i >= n.length || sep[i] || !isLetter(n.charAt(i)) || !isLetter(n.charAt(i - 1)); }
    for (e = 0; e < entries.length; e++) {
      k = entries[e].norm; from = 0;
      while ((idx = n.indexOf(k, from)) >= 0) {
        from = idx + 1;
        if (!opts.inside && idx > 0 && !sep[idx] && isLetter(n.charAt(idx - 1))) continue;
        end = idx + k.length; ok = false;
        if (opts.inside || wordEdge(end)) ok = true;
        else if (opts.variants) {
          // up to two word endings: کتاب‌هایش (the ending is written without a space)
          after = end;
          for (tries = 0; tries < 2 && !ok; tries++) {
            m = false;
            for (j = 0; j < SUFFIX.length; j++) {
              s = SUFFIX[j];
              if (n.substr(after, s.length) === s && !sep[after]) { after += s.length; m = true; if (wordEdge(after)) { ok = true; end = after; } break; }
            }
            if (!m) break;
          }
        }
        if (!ok) continue;
        hits.push({ start: P.map[idx], end: P.map[end - 1] + 1, word: entries[e].word, repl: entries[e].repl, found: "" });
        from = end;
      }
    }
    hits.sort(function (a, b) { return a.start - b.start || b.end - a.end; });
    var out = [], lastEnd = -1;
    hits.forEach(function (h) { if (h.start >= lastEnd) { h.found = String(text).slice(h.start, h.end); out.push(h); lastEnd = h.end; } });
    return out;
  }

  // hits: [{ start, end, rep }] with a replacement text in rep (empty = leave)
  function replaceHits(text, hits) {
    var list = hits.filter(function (h) { return h.rep !== undefined && h.rep !== null && String(h.rep) !== ""; }).sort(function (a, b) { return b.start - a.start; }), i;
    for (i = 0; i < list.length; i++) text = text.slice(0, list[i].start) + list[i].rep + text.slice(list[i].end);
    return text;
  }

  root.HydraBan = { parseList: parseList, find: find, replaceHits: replaceHits, prep: prep, SUFFIX: SUFFIX };
  if (typeof module !== "undefined" && module.exports) module.exports = root.HydraBan;
})(typeof window !== "undefined" ? window : global);
