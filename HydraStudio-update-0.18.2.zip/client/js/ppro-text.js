/*
 * Hydra Studio - Premiere Pro texts read from the saved project file.
 *
 * Premiere 2025 does not give a title's text to scripts: for Graphics made with the Type tool, the "Source Text" parameter
 * of the "Text" component answers getValue() with a binary block that ExtendScript cuts after the first character.
 * The full text is in the .prproj file (gzip XML): ArbVideoComponentParam "Source Text" -> StartKeyframeValue (base64).
 * That value is a FlatBuffer: [u32 size][u32 0][magic 44 33 22 11][root] ; root.0 = style table ; .0 = vector of text runs ;
 * run.0 = the run's text (UTF-8). The runs joined are the title's text.
 *
 * In Premiere this module answers "ops_textScan" for the panel: the host part (Essential Graphics / .mogrt texts that the API
 * can read) plus every Type-tool title found in the project file, which pp_projInfo saves first.
 * Works in the panel (window.HydraPproText) and in node (module.exports) for the tests.
 */
(function (root) {
  "use strict";

  // ---- FlatBuffer helpers (little endian)
  function u16(b, p) { return b[p] | (b[p + 1] << 8); }
  function u32(b, p) { return (b[p] | (b[p + 1] << 8) | (b[p + 2] << 16)) + b[p + 3] * 16777216; }
  function i32(b, p) { return b[p] | (b[p + 1] << 8) | (b[p + 2] << 16) | (b[p + 3] << 24); }
  function utf8(b, s, e) {
    if (typeof Buffer !== "undefined" && Buffer.from) return Buffer.from(b.buffer ? b.buffer : b, b.byteOffset || 0, b.length).slice(s, e).toString("utf8");
    return new TextDecoder("utf-8").decode(b.subarray(s, e));
  }
  // field f of the table at t: absolute position of its value, or -1
  function field(b, t, f) {
    if (t < 0 || t + 4 > b.length) return -1;
    var vt = t - i32(b, t);
    if (vt < 0 || vt + 4 > b.length) return -1;
    var vs = u16(b, vt);
    if (4 + f * 2 >= vs || vt + 4 + f * 2 + 2 > b.length) return -1;
    var off = u16(b, vt + 4 + f * 2);
    return off ? t + off : -1;
  }
  function deref(b, p) { if (p < 0 || p + 4 > b.length) return -1; var q = p + u32(b, p); return q < b.length ? q : -1; }
  function str(b, p) {
    var q = deref(b, p);
    if (q < 0 || q + 4 > b.length) return null;
    var n = u32(b, q);
    if (q + 4 + n > b.length) return null;
    return utf8(b, q + 4, q + 4 + n);
  }

  // text of one "Source Text" / caption value (bytes); null when it is not that format
  function blobText(b) {
    if (!b || b.length < 24) return null;
    if (!(b[8] === 0x44 && b[9] === 0x33 && b[10] === 0x22 && b[11] === 0x11)) return null;
    var rootT = 12 + u32(b, 12);
    var style = deref(b, field(b, rootT, 0));
    if (style < 0) return null;
    var vec = deref(b, field(b, style, 0));
    if (vec < 0 || vec + 4 > b.length) return null;
    var n = u32(b, vec), out = [], k, run, s;
    if (n > 10000) return null;
    for (k = 0; k < n; k++) {
      run = deref(b, vec + 4 + k * 4);
      if (run < 0) return null;
      s = str(b, field(b, run, 0));
      if (s === null) return null;
      out.push(s);
    }
    return out.join("").replace(/\r\n?/g, "\n");
  }

  function b64(s) {
    s = String(s).replace(/\s+/g, "");
    if (typeof Buffer !== "undefined" && Buffer.from) return Buffer.from(s, "base64");
    var bin = atob(s), a = new Uint8Array(bin.length), i;
    for (i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i);
    return a;
  }

  // ---- project XML
  function index(xml) {
    var objs = {}, re = /\n\t<(\w+) Object(?:U?)ID="([^"]+)"[^>]*>/g, m, list = [], i;
    while ((m = re.exec(xml))) list.push({ tag: m[1], id: m[2], at: m.index });
    for (i = 0; i < list.length; i++) { list[i].end = i + 1 < list.length ? list[i + 1].at : xml.length; objs[list[i].id] = list[i]; }
    return { objs: objs, list: list, body: function (o) { return xml.slice(o.at, o.end); } };
  }
  function refs(s, tag) {
    var re = new RegExp("<" + tag + "(?: Index=\"(\\d+)\")? Object(?:U?)Ref=\"([^\"]+)\"", "g"), m, out = [];
    while ((m = re.exec(s))) out.push({ index: m[1] === undefined ? out.length : parseInt(m[1], 10), id: m[2] });
    return out;
  }
  function tagText(s, tag) { var m = new RegExp("<" + tag + ">([^<]*)</" + tag + ">").exec(s); return m ? m[1] : ""; }
  function unxml(s) { return String(s).replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, "\"").replace(/&apos;/g, "'").replace(/&#(\d+);/g, function (a, n) { return String.fromCharCode(+n); }).replace(/&amp;/g, "&"); }

  var TICKS = 254016000000;

  // -> [{ seqId, seqName, texts: [{ track, start (ticks string), end, t (seconds), text }] }]
  function parseProject(xml) {
    var I = index(xml), out = [];
    I.list.forEach(function (o) {
      if (o.tag !== "Sequence") return;
      var sb = I.body(o), groups = refs(sb, "Second"), seq = { seqId: o.id, seqName: unxml(tagText(sb, "Name")), texts: [] };
      groups.forEach(function (g) {
        var go = I.objs[g.id];
        if (!go || go.tag !== "VideoTrackGroup") return;
        refs(I.body(go), "Track").forEach(function (tr) {
          var to = I.objs[tr.id];
          if (!to || to.tag !== "VideoClipTrack") return;
          refs(I.body(to), "TrackItem").forEach(function (ti) {
            var io = I.objs[ti.id];
            if (!io || io.tag !== "VideoClipTrackItem") return;
            var ib = I.body(io), start = tagText(ib, "Start"), end = tagText(ib, "End"), chain = refs(ib, "Components")[0];
            var co = chain && I.objs[chain.id];
            if (!co) return;
            refs(I.body(co), "Component").forEach(function (c) {
              var fo = I.objs[c.id];
              if (!fo) return;
              refs(I.body(fo), "Param").forEach(function (p) {
                var po = I.objs[p.id];
                if (!po || po.tag !== "ArbVideoComponentParam") return;
                var pb = I.body(po);
                if (tagText(pb, "Name") !== "Source Text") return;
                var m = /<StartKeyframeValue Encoding="base64"[^>]*>([^<]+)</.exec(pb);
                if (!m) return;
                var text = null;
                try { text = blobText(b64(m[1])); } catch (e) { text = null; }
                if (text === null || !/\S/.test(text)) return;
                seq.texts.push({ track: tr.index, start: start, end: end, t: (+start || 0) / TICKS, text: text, comp: c.index, param: p.index });
              });
            });
          });
        });
      });
      seq.texts.sort(function (a, b) { return a.t - b.t || a.track - b.track; });
      out.push(seq);
    });
    return out;
  }

  // ---- the panel's scan in Premiere: host texts (.mogrt etc.) + titles from the project file
  // info (from pp_projInfo): { path, active: seqId, seqs: [{id, name}], selected: [{ track, start }] }
  function merge(hostRes, info, seqs, mode) {
    var texts = (hostRes && hostRes.ok && hostRes.texts) ? hostRes.texts.slice() : [], seen = {}, count = 0, sel = {};
    texts.forEach(function (t) { seen[t.compId + "|" + t.text + "|" + Math.round((t.t || 0) * 100)] = 1; });
    (info.selected || []).forEach(function (s) { sel[s.track + ":" + s.start] = 1; });
    // the file's sequence id is normally Premiere's sequenceID; if not, match by (unique) name
    var hostIds = {}, byName = {};
    (info.seqs || []).forEach(function (h) { hostIds[h.id] = 1; byName[h.name] = byName[h.name] === undefined ? h.id : null; });
    seqs.forEach(function (s) {
      var id = hostIds[s.seqId] ? s.seqId : (byName[s.seqName] || s.seqId);
      s.hostId = id;
      if (mode !== "project" && id !== info.active) return;
      count++;
      s.texts.forEach(function (x) {
        if (mode === "selected" && !sel[x.track + ":" + x.start]) return;
        var key = s.hostId + "|" + x.text + "|" + Math.round(x.t * 100);
        if (seen[key]) return;
        seen[key] = 1;
        texts.push({ comp: s.seqName, compId: s.hostId, li: "v" + x.track + "s" + x.start, layer: "Graphic · V" + (x.track + 1), text: x.text, keys: [], t: x.t, fromFile: true });
      });
    });
    return { ok: true, comps: mode === "project" ? count : 1, texts: texts, skipped: 0, fromFile: true };
  }

  function install(cep, req) {
    if (!cep || cep.__hydraPpro) return;
    var fs, zlib;
    try { fs = req("fs"); zlib = req("zlib"); } catch (e) { return; }
    var call = cep.call;
    cep.__hydraPpro = true;
    cep.call = function (fn) {
      if (fn !== "ops_textScan") return call.apply(cep, arguments);
      var mode = arguments[1];
      return call.call(cep, "pp_projInfo").then(function (info) {
        if (!info.ok) return info;
        return call.call(cep, "ops_textScan", mode).then(function (hostRes) {
          var seqs;
          try { seqs = parseProject(zlib.gunzipSync(fs.readFileSync(info.path)).toString("utf8")); }
          catch (e) { return hostRes && hostRes.ok ? hostRes : { ok: false, error: "Couldn't read the project file: " + ((e && e.message) || e) }; }
          return merge(hostRes, info, seqs, mode);
        });
      });
    };
  }

  var api = { blobText: blobText, parseProject: parseProject, merge: merge, install: install, TICKS: TICKS };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (root) root.HydraPproText = api;
})(typeof window !== "undefined" ? window : null);
