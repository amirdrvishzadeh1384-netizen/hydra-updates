/* Hydra Studio · studio-ban.js
 * The Banned words section: you paste (or import) the words a client does not want to see, and this scans every text layer
 * (open comp, selected layers or the whole project), shows where they appear, and can swap them for another word.
 * Matching is ban-core.js; reading / writing the texts is host.jsx (ops_textScan / ops_textApply / ops_textReveal).
 */
(function () {
  "use strict";
  var ST = { lists: [], cur: 0, mode: "comp", forms: true, inside: false, items: null, scanned: false, busy: false, comps: 0, skipped: 0, loaded: false, only: true };
  var X = null, B = null, saveT = 0;
  var MODES = [["comp", "Open comp"], ["selected", "Selected layers"], ["project", "Whole project"]];
  var CAP = 300;

  function file() { return X.files && X.files.data ? X.files.path.join(X.files.data, "banned-lists.json") : ""; }
  function load() {
    if (ST.loaded) return; ST.loaded = true;
    try {
      var f = file();
      if (f && X.files.fs.existsSync(f)) {
        var d = JSON.parse(X.files.fs.readFileSync(f, "utf8")) || {};
        if (Array.isArray(d.lists)) ST.lists = d.lists.filter(function (l) { return l && typeof l.text === "string"; }).map(function (l) { return { name: String(l.name || "List"), text: l.text }; });
        ST.cur = Math.max(0, Math.min(ST.lists.length - 1, d.cur | 0));
        if (d.mode) ST.mode = d.mode; if (d.forms === false) ST.forms = false; if (d.inside === true) ST.inside = true;
      }
    } catch (e) {}
    if (!ST.lists.length) { ST.lists = [{ name: "Client list", text: "" }]; ST.cur = 0; }
  }
  function save() {
    clearTimeout(saveT);
    saveT = setTimeout(function () {
      try { var f = file(); if (f) { X.files.mkdirp(X.files.data); X.files.fs.writeFileSync(f, JSON.stringify({ lists: ST.lists, cur: ST.cur, mode: ST.mode, forms: ST.forms, inside: ST.inside }, null, 1)); } } catch (e) {}
    }, 250);
  }
  function entries() { return B.parseList(ST.lists[ST.cur].text); }
  function fmtT(t) { t = Math.max(0, t || 0); var m = Math.floor(t / 60), s = Math.floor(t % 60); return m + ":" + (s < 10 ? "0" : "") + s; }
  function tick() { return new Promise(function (r) { setTimeout(r, 0); }); }

  async function scan(box) {
    if (ST.busy) return;
    var ents = entries();
    if (!ents.length) { X.toast("Add the banned words first", true); return; }
    if (!X.ready()) { X.toast(X.connected() ? "Not connected · click the status above" : "Open this panel inside After Effects", true); return; }
    ST.busy = true; draw(box);
    try {
      var r = await X.cep.call("ops_textScan", ST.mode === "comp" ? "active" : ST.mode);
      if (!r.ok) { X.toast(r.error || "Couldn’t read the texts", true); return; }
      ST.comps = r.comps; ST.skipped = r.skipped || 0; ST.items = [];
      (r.texts || []).forEach(function (it) {
        it.orig = it.text;
        it.hits = B.find(it.text, ents, { variants: ST.forms, inside: ST.inside });
        it.hits.forEach(function (h) { h.rep = h.repl || ""; });
        it.done = false; ST.items.push(it);
      });
      ST.scanned = true;
    } catch (e) { X.toast("Scan failed: " + ((e && e.message) || e), true); }
    finally { ST.busy = false; draw(box); }
  }

  function pending(it) { return B.replaceHits(it.text, it.hits) !== it.text; }

  async function apply(items, box) {
    items = items.filter(pending);
    if (!items.length || ST.busy) return;
    if (!X.ready()) { X.toast("Not connected · click the status above", true); return; }
    ST.busy = true; draw(box);
    try {
      var fixes = items.map(function (it) { return { compId: it.compId, li: it.li, layer: it.layer, old: it.orig, text: B.replaceHits(it.text, it.hits) }; });
      var r = await X.cep.call("ops_textApply", JSON.stringify(fixes));
      if (!r.ok) { X.toast(r.error || "Couldn’t write the changes", true); return; }
      var ents = entries();
      items.forEach(function (it, i) {
        it.text = fixes[i].text; it.orig = it.text; it.done = true;
        it.hits = B.find(it.text, ents, { variants: ST.forms, inside: ST.inside });
        it.hits.forEach(function (h) { h.rep = h.repl || ""; });
      });
      X.toast("Replaced in " + r.applied + (r.applied === 1 ? " text" : " texts") + (r.missed ? " · " + r.missed + " not found (changed since the scan?)" : "") + " · one Undo in After Effects");
    } catch (e) { X.toast(String((e && e.message) || e), true); }
    finally { ST.busy = false; draw(box); }
  }

  function report() {
    var lines = ["Banned words report — " + ST.lists[ST.cur].name, ""], n = 0;
    (ST.items || []).forEach(function (it) {
      if (!it.hits.length) return;
      it.hits.forEach(function (h) { n++; lines.push(it.comp + " · " + it.layer + " · " + fmtT(it.t) + " · “" + h.found + "”" + (h.found !== h.word ? " (" + h.word + ")" : "")); });
    });
    lines.splice(1, 0, n + (n === 1 ? " place" : " places") + " found");
    return lines.join("\n");
  }

  function textView(it) {
    var wrap = X.h("div", { class: "sp-text", dir: "auto" }), t = it.text, pos = 0;
    it.hits.forEach(function (h) {
      if (h.start > pos) wrap.appendChild(document.createTextNode(t.slice(pos, h.start).replace(/\r/g, "\n")));
      wrap.appendChild(X.h("mark", { class: "bn-hit" }, [t.slice(h.start, h.end)]));
      pos = h.end;
    });
    if (pos < t.length) wrap.appendChild(document.createTextNode(t.slice(pos).replace(/\r/g, "\n")));
    return wrap;
  }

  function card(it, box) {
    var c = X.h("div", { class: "sp-card" + (it.done && !it.hits.length ? " clean" : "") });
    var title = X.h("button", { type: "button", class: "sp-where", title: "Open it in After Effects" }, [it.comp + "  ·  " + it.layer + "  ·  " + fmtT(it.t)]);
    title.addEventListener("click", function () { X.cep.call("ops_textReveal", it.compId, it.li, it.layer, it.t).then(function (r) { if (!r.ok) X.toast(r.error || "Couldn’t open it", true); }); });
    c.appendChild(title);
    c.appendChild(textView(it));
    it.hits.forEach(function (h) {
      var row = X.h("div", { class: "bn-row" });
      row.appendChild(X.h("span", { class: "bn-found", dir: "auto" }, [h.found]));
      row.appendChild(X.h("span", { class: "bn-arrow" }, ["→"]));
      var inp = X.h("input", { type: "text", class: "bn-rep", placeholder: "replace with… (empty = leave)", dir: "auto" });
      inp.value = h.rep || "";
      inp.addEventListener("input", function () { h.rep = inp.value; });
      inp.addEventListener("change", function () { draw(box); });
      row.appendChild(inp);
      c.appendChild(row);
    });
    if (it.hits.length && it.hits.some(function (h) { return h.rep; })) {
      var foot = X.h("div", { class: "sp-foot" });
      var ap = X.h("button", { type: "button", class: "sp-apply" }, ["Replace in AE"]);
      ap.addEventListener("click", function () { apply([it], box); });
      foot.appendChild(ap); c.appendChild(foot);
    } else if (it.done && !it.hits.length) c.appendChild(X.h("div", { class: "sp-foot" }, [X.h("span", { class: "sp-ok" }, ["Replaced"])]));
    return c;
  }

  function draw(box) {
    load(); box.innerHTML = "";
    var root = X.h("div", { class: "spell", style: X.colorVars(X.rgb) }), L = ST.lists[ST.cur];
    root.appendChild(X.h("p", { class: "tools-lead" }, ["Paste the words a client doesn’t want. The panel finds every place they appear in your texts, and can swap them for another word."]));

    var top = X.h("div", { class: "bn-top" }), sel = X.h("select", { class: "bn-sel" });
    ST.lists.forEach(function (l, i) { var o = X.h("option", { value: String(i) }, [l.name || "List"]); if (i === ST.cur) o.selected = true; sel.appendChild(o); });
    sel.addEventListener("change", function () { ST.cur = +sel.value; ST.items = null; ST.scanned = false; save(); draw(box); });
    top.appendChild(sel);
    var nw = X.h("button", { type: "button", class: "sp-main" }, ["New list"]);
    nw.addEventListener("click", function () { ST.lists.push({ name: "List " + (ST.lists.length + 1), text: "" }); ST.cur = ST.lists.length - 1; ST.items = null; ST.scanned = false; save(); draw(box); });
    top.appendChild(nw);
    root.appendChild(top);

    var nm = X.h("input", { type: "text", class: "bn-name", placeholder: "List name (client)" });
    nm.value = L.name;
    nm.addEventListener("input", function () { L.name = nm.value; var o = sel.options[ST.cur]; if (o) o.textContent = L.name || "List"; save(); });
    root.appendChild(nm);

    var ta = X.h("textarea", { class: "sb-hint bn-words", rows: "6", dir: "auto", placeholder: "One word per line, or separated by commas.\nword = replacement  (optional)\n# a note" });
    ta.value = L.text;
    var cnt = X.h("div", { class: "sp-note" });
    function count() { var n = entries().length; cnt.textContent = n + (n === 1 ? " word in this list" : " words in this list"); }
    ta.addEventListener("input", function () { L.text = ta.value; count(); save(); });
    root.appendChild(ta); root.appendChild(cnt); count();

    var acts = X.h("div", { class: "sp-acts" });
    var imp = X.h("button", { type: "button", class: "sp-link" }, ["Import a .txt / .csv…"]);
    imp.addEventListener("click", async function () {
      if (!X.ready()) { X.toast("Open this panel inside After Effects", true); return; }
      var r = await X.cep.call("ops_pickText");
      if (!r.ok) { X.toast(r.error || "Couldn’t read the file", true); return; }
      if (!r.path) return;
      L.text = (L.text ? L.text.replace(/\s+$/, "") + "\n" : "") + String(r.text || "").replace(/^﻿/, ""); save(); draw(box);
    });
    acts.appendChild(imp);
    if (ST.lists.length > 1) {
      var del = X.h("button", { type: "button", class: "sp-link" }, ["Delete this list"]);
      del.addEventListener("click", function () { ST.lists.splice(ST.cur, 1); ST.cur = Math.max(0, ST.cur - 1); ST.items = null; ST.scanned = false; save(); draw(box); });
      acts.appendChild(del);
    }
    root.appendChild(acts);

    var seg = X.h("div", { class: "sp-seg" });
    MODES.forEach(function (m) {
      var b = X.h("button", { type: "button", class: m[0] === ST.mode ? "on" : "" }, [m[1]]);
      b.addEventListener("click", function () { if (ST.busy) return; ST.mode = m[0]; save(); draw(box); });
      seg.appendChild(b);
    });
    root.appendChild(seg);

    var f1 = X.h("label", { class: "sp-only bn-opt" }, [X.h("input", { type: "checkbox" }), " Also find word forms (کتاب‌ها، کتابش)"]);
    f1.firstChild.checked = ST.forms; f1.firstChild.addEventListener("change", function () { ST.forms = this.checked; save(); });
    var f2 = X.h("label", { class: "sp-only bn-opt" }, [X.h("input", { type: "checkbox" }), " Also inside longer words"]);
    f2.firstChild.checked = ST.inside; f2.firstChild.addEventListener("change", function () { ST.inside = this.checked; save(); });
    root.appendChild(f1); root.appendChild(f2);

    var go = X.h("button", { type: "button", class: "sp-scan" + (ST.busy ? " busy" : "") }, [ST.busy ? "Working…" : (ST.scanned ? "Scan again" : "Find banned words")]);
    if (ST.busy) go.disabled = true;
    go.addEventListener("click", function () { scan(box); });
    root.appendChild(go);

    if (ST.scanned && ST.items) {
      var withHits = ST.items.filter(function (it) { return it.hits.length; }), total = withHits.reduce(function (a, it) { return a + it.hits.length; }, 0);
      root.appendChild(X.h("div", { class: "sp-stats" }, [
        ST.items.length + (ST.items.length === 1 ? " text" : " texts") + " in " + ST.comps + (ST.comps === 1 ? " comp" : " comps") + "  ·  ",
        X.h("b", {}, [total ? total + (total === 1 ? " banned word found" : " banned words found") : "none found"]),
        ST.skipped ? "  ·  " + ST.skipped + " driven by expressions (skipped)" : ""
      ]));
      var bar = X.h("div", { class: "sp-bar" }), ready = withHits.filter(pending);
      if (ready.length) {
        var all = X.h("button", { type: "button", class: "sp-main go" }, ["Replace in " + ready.length + (ready.length === 1 ? " text" : " texts") + " in AE"]);
        all.addEventListener("click", function () { apply(ready, box); });
        bar.appendChild(all);
      }
      if (total) {
        var cp = X.h("button", { type: "button", class: "sp-main" }, ["Copy report"]);
        cp.addEventListener("click", function () {
          var t = report();
          try { var ta2 = document.createElement("textarea"); ta2.value = t; document.body.appendChild(ta2); ta2.select(); document.execCommand("copy"); ta2.remove(); X.toast("Report copied"); } catch (e) { X.toast("Couldn’t copy", true); }
        });
        bar.appendChild(cp);
        var sv = X.h("button", { type: "button", class: "sp-main" }, ["Save report…"]);
        sv.addEventListener("click", async function () {
          var r = await X.cep.call("ops_saveText", "banned-words-report.txt", report());
          if (!r.ok) X.toast(r.error || "Couldn’t save", true); else if (r.path) X.toast("Saved");
        });
        bar.appendChild(sv);
      }
      root.appendChild(bar);
      var list = X.h("div", { class: "sp-list" });
      var shown = ST.items.filter(function (it) { return it.hits.length || it.done; });
      shown.slice(0, CAP).forEach(function (it) { list.appendChild(card(it, box)); });
      if (shown.length > CAP) list.appendChild(X.h("div", { class: "sp-note" }, ["Showing the first " + CAP + " of " + shown.length + "."]));
      if (!shown.length) list.appendChild(X.h("div", { class: "sp-empty" }, ["No banned words in these texts."]));
      root.appendChild(list);
    }
    box.appendChild(root);
  }

  window.HydraBanUI = {
    reset: function () { ST.items = null; ST.scanned = false; },
    init: function (ctx) { X = ctx; B = window.HydraBan; },
    render: function (box) { draw(box); },
    _state: ST
  };
})();
