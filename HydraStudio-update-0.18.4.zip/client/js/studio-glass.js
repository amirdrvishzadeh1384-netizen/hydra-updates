/* Hydra Studio · studio-glass.js
 * Liquid Glass studio: six looks (Clear, Frosted, Tinted, Dark, Prism, Bubble) on a rounded panel, one of the icons of
 * glass-icons.js, or the selected layer itself. "Create" builds a light rig in After Effects (host: ops_glassShape):
 * one Controls null that moves / scales / turns the glass and holds the sliders, and shape layers that follow it.
 * The preview bends the picture behind the shape like the real glass. It stays cheap: the shape's distance field is built
 * once per shape (a rectangle needs none), slider moves only redo a per-pixel table, and each frame just samples it.
 */
(function () {
  "use strict";
  var S = window.Studio, U = S.u, mk = U.mk, clamp = U.clamp, esc = U.esc;
  var E = null, IC = window.HydraGlassIcons || { list: [] };

  var RW = 800, RH = 450;   // the preview is drawn at a fixed size and scaled by CSS

  // ------------------------------------------------------------------ the looks (each one only sets sliders)
  var LOOKS = [
    ["clear", "Clear", { glass: 100, bevel: 30, frost: 0, tint: "#FFFFFF", tintAmt: 4, light: 100, shadow: 30, zoom: 4, prism: false }],
    ["frosted", "Frosted", { glass: 70, bevel: 26, frost: 18, tint: "#FFFFFF", tintAmt: 16, light: 90, shadow: 30, zoom: 0, prism: false }],
    ["tinted", "Tinted", { glass: 90, bevel: 28, frost: 6, tint: "#2878FF", tintAmt: 14, light: 90, shadow: 40, zoom: 2, prism: false }],
    ["dark", "Dark", { glass: 85, bevel: 28, frost: 10, tint: "#08080E", tintAmt: 45, light: 80, shadow: 50, zoom: 0, prism: false }],
    ["prism", "Prism", { glass: 110, bevel: 34, frost: 0, tint: "#FFFFFF", tintAmt: 2, light: 110, shadow: 30, zoom: 4, prism: true }],
    ["bubble", "Bubble", { glass: 100, bevel: 90, frost: 0, tint: "#FFFFFF", tintAmt: 3, light: 120, shadow: 30, zoom: 12, prism: false }]
  ];
  var LOOK_KEYS = ["glass", "bevel", "frost", "tint", "tintAmt", "light", "shadow", "zoom", "prism"];
  var TINTS = ["#FFFFFF", "#2878FF", "#FF3B7F", "#30D158", "#FF9F0A", "#08080E"];
  var BGS = [["aurora", "Aurora"], ["grid", "Grid"], ["sunset", "Sunset"]];
  var ANIMS = [["none", "None"], ["pop", "Pop in"], ["float", "Float"], ["pulse", "Pulse"], ["spin", "Spin"]];

  // ------------------------------------------------------------------ the shapes: [key, label, kind, data]
  var PANELS = [
    ["pill", "Pill", "rect", { w: 0.46, h: 0.2, rad: 100 }],
    ["card", "Card", "rect", { w: 0.4, h: 0.5, rad: 22 }],
    ["circle", "Circle", "rect", { w: 0.3, h: 0.3 * 16 / 9, rad: 100 }],
    ["tile", "Tile", "rect", { w: 0.26, h: 0.26 * 16 / 9, rad: 44 }]
  ];
  var ICONS = IC.list.map(function (c) { return [c[0], c[1], "path", { paths: c[2], thick: c[3], round: c[4] }]; });
  var MINE = [["layer", "My layer", "layer", {}]];
  var USER = [];   // icons the user imported (PNG / SVG traced into paths), kept in <data>/glass-icons.json
  var PACK = [];   // the shared icon pack, downloaded from the update site (packs/glass-icons.json), cached in <data>/glass-pack.json
  var SHAPES = PANELS.concat(ICONS, PACK, USER, MINE);
  function reshape() { SHAPES = PANELS.concat(ICONS, PACK, USER, MINE); }
  function shapeOf(k) { return SHAPES.filter(function (s) { return s[0] === k; })[0] || SHAPES[0]; }
  function lookOf(k) { return LOOKS.filter(function (s) { return s[0] === k; })[0] || LOOKS[0]; }

  var DEF = { look: "clear", shape: "pill", w: 0.46, h: 0.2, rad: 100, size: 40, round: 4, glass: 100, bevel: 30, frost: 0, tint: "#FFFFFF", tintAmt: 4,
    light: 100, angle: 0, edge: 5, shadow: 30, zoom: 4, prism: false, anim: "none", bg: "aurora", name: "Liquid Glass" };

  // ------------------------------------------------------------------ background scenes (painted once per kind)
  function blob(g, x, y, r, c, a) {
    var gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, "rgba(" + c + "," + a + ")"); gr.addColorStop(1, "rgba(" + c + ",0)");
    g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
  }
  function paintScene(g, w, h, kind) {
    var i, x, y, u = Math.min(w, h) / 100;
    if (kind === "grid") {
      g.fillStyle = "#0b0a14"; g.fillRect(0, 0, w, h);
      blob(g, w * 0.2, h * 0.3, w * 0.5, "255,55,120", 0.5); blob(g, w * 0.82, h * 0.72, w * 0.5, "50,173,230", 0.5); blob(g, w * 0.55, h * 0.15, w * 0.35, "255,216,0", 0.25);
      g.lineWidth = Math.max(1, u * 0.3);
      var step = w / 16;
      for (i = 0; i <= 16; i++) { g.strokeStyle = i % 4 === 0 ? "rgba(255,255,255,.6)" : "rgba(255,255,255,.22)"; g.beginPath(); g.moveTo(i * step, 0); g.lineTo(i * step, h); g.stroke(); }
      for (i = 0; i * step <= h + step; i++) { g.strokeStyle = i % 4 === 0 ? "rgba(255,255,255,.6)" : "rgba(255,255,255,.22)"; g.beginPath(); g.moveTo(0, i * step); g.lineTo(w, i * step); g.stroke(); }
      g.fillStyle = "#fff";
      for (i = 0; i < 18; i++) { x = ((i * 53) % 17) * step; y = ((i * 31) % 9) * step; g.beginPath(); g.arc(x, y, u * 0.9, 0, 6.3); g.fill(); }
      g.lineWidth = u * 1; g.strokeStyle = "#ffd800"; g.beginPath(); g.arc(w * 0.3, h * 0.55, h * 0.22, 0, 6.3); g.stroke();
      g.strokeStyle = "#30d158"; g.beginPath(); g.arc(w * 0.72, h * 0.4, h * 0.16, 0, 6.3); g.stroke();
    } else if (kind === "sunset") {
      var sk = g.createLinearGradient(0, 0, 0, h);
      sk.addColorStop(0, "#1b1442"); sk.addColorStop(0.45, "#b0306a"); sk.addColorStop(0.72, "#ff7a45"); sk.addColorStop(1, "#ffd27a");
      g.fillStyle = sk; g.fillRect(0, 0, w, h);
      var sun = g.createRadialGradient(w * 0.64, h * 0.62, 0, w * 0.64, h * 0.62, h * 0.5);
      sun.addColorStop(0, "rgba(255,245,200,1)"); sun.addColorStop(0.18, "rgba(255,225,150,1)"); sun.addColorStop(0.19, "rgba(255,170,90,.55)"); sun.addColorStop(1, "rgba(255,120,80,0)");
      g.fillStyle = sun; g.fillRect(0, 0, w, h);
      [["#5a2a6e", 0.62, 0.1], ["#3a1f5c", 0.72, 0.13], ["#1d1238", 0.84, 0.1]].forEach(function (L, li) {
        g.fillStyle = L[0]; g.beginPath(); g.moveTo(0, h);
        for (i = 0; i <= 24; i++) { x = i / 24 * w; y = h * L[1] + Math.sin(i * 1.3 + li * 2) * h * L[2] * 0.5 + Math.sin(i * 0.5 + li) * h * L[2]; g.lineTo(x, y); }
        g.lineTo(w, h); g.closePath(); g.fill();
      });
      g.fillStyle = "rgba(255,240,200,.9)";
      for (i = 0; i < 26; i++) { x = ((i * 37) % 97) / 97 * w; y = ((i * 53) % 41) / 41 * h * 0.4; g.fillRect(x, y, u * 0.6, u * 0.6); }
    } else {
      var bgc = g.createLinearGradient(0, 0, w, h);
      bgc.addColorStop(0, "#0e1233"); bgc.addColorStop(1, "#2a0f3d");
      g.fillStyle = bgc; g.fillRect(0, 0, w, h);
      blob(g, w * 0.18, h * 0.28, w * 0.42, "255,138,61", 0.95); blob(g, w * 0.78, h * 0.25, w * 0.4, "61,200,255", 0.85);
      blob(g, w * 0.55, h * 0.85, w * 0.45, "255,61,129", 0.9); blob(g, w * 0.35, h * 0.7, w * 0.3, "122,92,255", 0.8);
      g.fillStyle = "rgba(255,255,255,.92)"; g.font = "800 " + (h * 0.34) + "px Outfit, -apple-system, Helvetica, sans-serif"; g.textAlign = "center"; g.textBaseline = "middle";
      g.fillText("HYDRA", w * 0.5, h * 0.4);
      g.fillStyle = "rgba(255,255,255,.55)"; g.font = "500 " + (h * 0.085) + "px Outfit, -apple-system, Helvetica, sans-serif";
      g.fillText("liquid glass studio", w * 0.5, h * 0.66);
      g.fillStyle = "rgba(255,255,255,.8)";
      for (i = 0; i < 9; i++) { g.beginPath(); g.arc(w * (0.28 + i * 0.055), h * 0.8, u * 0.9, 0, 6.3); g.fill(); }
    }
  }

  // ------------------------------------------------------------------ blur (running sums; the whole picture is blurred once and cached)
  function boxBlur(src, w, h, r) {
    var ir = Math.round(r);
    if (ir < 1) return src;
    var tmp = new Uint8ClampedArray(src.length), out = new Uint8ClampedArray(src.length), x, y, c, k, acc, win = ir * 2 + 1, a, b;
    for (y = 0; y < h; y++) {
      for (c = 0; c < 4; c++) {
        acc = 0;
        for (k = -ir; k <= ir; k++) acc += src[(y * w + clamp(k, 0, w - 1)) * 4 + c];
        for (x = 0; x < w; x++) {
          tmp[(y * w + x) * 4 + c] = acc / win;
          a = clamp(x + ir + 1, 0, w - 1); b = clamp(x - ir, 0, w - 1);
          acc += src[(y * w + a) * 4 + c] - src[(y * w + b) * 4 + c];
        }
      }
    }
    for (x = 0; x < w; x++) {
      for (c = 0; c < 4; c++) {
        acc = 0;
        for (k = -ir; k <= ir; k++) acc += tmp[(clamp(k, 0, h - 1) * w + x) * 4 + c];
        for (y = 0; y < h; y++) {
          out[(y * w + x) * 4 + c] = acc / win;
          a = clamp(y + ir + 1, 0, h - 1); b = clamp(y - ir, 0, h - 1);
          acc += tmp[(a * w + x) * 4 + c] - tmp[(b * w + x) * 4 + c];
        }
      }
    }
    return out;
  }


  // ------------------------------------------------------------------ distance fields
  // Felzenszwalb: for every pixel, the distance to the nearest pixel where on(i) is false
  function edt(on, w, h) {
    var INF = 1e20, n = Math.max(w, h), f = new Float64Array(n), d = new Float64Array(n), v = new Int32Array(n), z = new Float64Array(n + 1), g = new Float64Array(w * h), i, x, y;
    for (i = 0; i < w * h; i++) g[i] = on[i] ? INF : 0;
    function dt(len) {
      var k = 0, q, s;
      v[0] = 0; z[0] = -INF; z[1] = INF;
      for (q = 1; q < len; q++) {
        s = ((f[q] + q * q) - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]);
        while (s <= z[k]) { k--; s = ((f[q] + q * q) - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]); }
        k++; v[k] = q; z[k] = s; z[k + 1] = INF;
      }
      k = 0;
      for (q = 0; q < len; q++) { while (z[k + 1] < q) k++; d[q] = (q - v[k]) * (q - v[k]) + f[v[k]]; }
    }
    for (x = 0; x < w; x++) { for (y = 0; y < h; y++) f[y] = g[y * w + x]; dt(h); for (y = 0; y < h; y++) g[y * w + x] = d[y]; }
    for (y = 0; y < h; y++) { for (x = 0; x < w; x++) f[x] = g[y * w + x]; dt(w); for (x = 0; x < w; x++) g[y * w + x] = Math.sqrt(d[x]); }
    return g;
  }
  // signed distance (inside > 0) of a coverage mask
  function sdf(inside, w, h) {
    var N = w * h, a = new Uint8Array(N), b = new Uint8Array(N), i, din, dout, o = new Float32Array(N);
    for (i = 0; i < N; i++) { a[i] = inside[i] ? 1 : 0; b[i] = inside[i] ? 0 : 1; }
    din = edt(a, w, h); dout = edt(b, w, h);
    for (i = 0; i < N; i++) o[i] = inside[i] ? din[i] - 0.5 : 0.5 - dout[i];
    return o;
  }
  function blur1(a, w, h) {
    var o = new Float32Array(w * h), x, y, i;
    for (y = 1; y < h - 1; y++) for (x = 1; x < w - 1; x++) {
      i = y * w + x;
      o[i] = (a[i] * 4 + a[i - 1] + a[i + 1] + a[i - w] + a[i + w]) / 8;
    }
    for (x = 0; x < w; x++) { o[x] = a[x]; o[(h - 1) * w + x] = a[(h - 1) * w + x]; }
    for (y = 0; y < h; y++) { o[y * w] = a[y * w]; o[y * w + w - 1] = a[y * w + w - 1]; }
    return o;
  }

  // ------------------------------------------------------------------ drawing a shape
  function tracePath(g, p, s, cx, cy) {
    var n = p.v.length, k, a, b, j;
    g.moveTo(cx + p.v[0][0] * s, cy + p.v[0][1] * s);
    for (k = 0; k < n; k++) {
      a = p.v[k]; j = (k + 1) % n; b = p.v[j];
      g.bezierCurveTo(cx + (a[0] + p.o[k][0]) * s, cy + (a[1] + p.o[k][1]) * s, cx + (b[0] + p.i[j][0]) * s, cy + (b[1] + p.i[j][1]) * s, cx + b[0] * s, cy + b[1] * s);
    }
    g.closePath();
  }
  function drawShape(g, sh, s, cx, cy) {
    if (sh[2] === "layer") {
      g.font = "800 " + (s * 62) + "px Outfit, -apple-system, Helvetica, sans-serif"; g.textAlign = "center"; g.textBaseline = "middle";
      g.fillText("Aa", cx, cy + s * 3);
      return;
    }
    g.beginPath();
    sh[3].paths.forEach(function (p) { tracePath(g, p, s, cx, cy); });
    g.fill();
  }

  // ------------------------------------------------------------------ the renderer
  var REF = 240, RU = REF / 116;   // the reference raster of an icon: 116 units across
  var Ren = { scene: null, kind: "", sharp: null, blur: null, src: null, srcKey: "", drift: true, cx: 0.5, cy: 0.5, last: null, ref: null, refKey: "", lay: null, layKey: "", out: null };

  function ensureScene(P) {
    var g, f, N, i, src;
    if (!Ren.scene) { Ren.scene = document.createElement("canvas"); Ren.scene.width = RW; Ren.scene.height = RH; }
    if (Ren.kind !== P.bg) {
      g = Ren.scene.getContext("2d"); g.clearRect(0, 0, RW, RH); paintScene(g, RW, RH, P.bg);
      Ren.kind = P.bg; Ren.sharp = g.getImageData(0, 0, RW, RH).data; Ren.blur = null; Ren.srcKey = "";
    }
    // frost mixes the picture with one blurred copy (made once), so moving the Frost slider costs nothing
    f = clamp(P.frost, 0, 60) / 22; f = f > 1 ? 1 : f;
    var key = P.bg + "|" + Math.round(f * 40);
    if (Ren.srcKey === key) return;
    if (f <= 0) Ren.src = Ren.sharp;
    else {
      if (!Ren.blur) Ren.blur = boxBlur(boxBlur(Ren.sharp, RW, RH, 7), RW, RH, 7);
      N = Ren.sharp.length; src = new Uint8ClampedArray(N);
      for (i = 0; i < N; i++) src[i] = Ren.sharp[i] + (Ren.blur[i] - Ren.sharp[i]) * f;
      Ren.src = src;
    }
    Ren.srcKey = key;
  }

  // an icon's signed distance + its direction, at a fixed reference size (rebuilt only when the icon or its corners change)
  function ensureRef(P, sh) {
    var key = sh[0] + "|" + (sh[2] === "path" ? P.round : 0);
    if (Ren.refKey === key && Ren.ref) return Ren.ref;
    var c = document.createElement("canvas"); c.width = REF; c.height = REF;
    var g = c.getContext("2d"); g.fillStyle = "#fff";
    drawShape(g, sh, RU, REF / 2, REF / 2);
    var md = g.getImageData(0, 0, REF, REF).data, N = REF * REF, inside = new Uint8Array(N), i, sd, r = sh[2] === "path" ? clamp(P.round, 0, 20) * RU : 0;
    for (i = 0; i < N; i++) inside[i] = md[i * 4 + 3] > 127 ? 1 : 0;
    sd = sdf(inside, REF, REF);
    if (r > 0.5) {
      // round the corners like AE's Round Corners: shrink by r, grow back by r
      var core = new Uint8Array(N);
      for (i = 0; i < N; i++) core[i] = sd[i] > r ? 1 : 0;
      var s2 = sdf(core, REF, REF);
      for (i = 0; i < N; i++) sd[i] = s2[i] + r;
    }
    sd = blur1(sd, REF, REF);
    var gx = new Float32Array(N), gy = new Float32Array(N), x, y, ax, ay, l;
    for (y = 1; y < REF - 1; y++) for (x = 1; x < REF - 1; x++) {
      i = y * REF + x; ax = sd[i + 1] - sd[i - 1]; ay = sd[i + REF] - sd[i - REF]; l = Math.sqrt(ax * ax + ay * ay) || 1;
      gx[i] = -ax / l; gy[i] = -ay / l;   // outward
    }
    Ren.ref = { sd: sd, gx: gx, gy: gy };
    Ren.refKey = key;
    return Ren.ref;
  }

  // the per-pixel table: coverage, where each color is sampled from, how much light is added. Rebuilt when a slider moves.
  function layout(P) {
    var sh = shapeOf(P.shape), kind = sh[2];
    var key = [P.shape, P.w, P.h, P.rad, P.size, P.round, P.bevel, P.glass, P.zoom, P.prism, P.light, P.angle, P.edge].join("|");
    if (Ren.layKey === key && Ren.lay) return Ren.lay;
    var lw, lh, rad, thick, s = 0, ref = null, pad = 3;
    if (kind === "rect") {
      lw = clamp(P.w, 0.03, 1.4) * RW; lh = clamp(P.h, 0.03, 1.4) * RH; rad = clamp(P.rad, 0, 100) / 100 * Math.min(lw, lh) / 2; thick = Math.min(lw, lh) / 2;
    } else {
      s = clamp(P.size, 5, 140) / 100 * RH / 100;   // px per unit
      lw = lh = 112 * s; thick = 100 * s * (kind === "path" ? sh[3].thick : 0.09);
      ref = ensureRef(P, sh);
    }
    var w = Math.ceil(lw) + pad * 2, h = Math.ceil(lh) + pad * 2, N = w * h, cx = w / 2, cy = h / 2;
    var A = new Float32Array(N), HL = new Float32Array(N), DX = [new Float32Array(N), new Float32Array(N), new Float32Array(N)], DY = [new Float32Array(N), new Float32Array(N), new Float32Array(N)];
    var B = Math.max(1.2, thick * clamp(P.bevel, 2, 120) / 100), R = B * 0.55 * P.glass / 100, disp = P.prism ? 0.3 : 0.07, zoom = clamp(P.zoom, 0, 100) / 100 * 0.8;
    var li = clamp(P.light, 0, 250) / 100, ew = Math.max(0.6, thick * clamp(P.edge, 0, 40) / 100 * 0.7);
    var an = (P.angle || 0) * Math.PI / 180, Lx = -0.55 * Math.cos(an) + 0.83 * Math.sin(an), Ly = -0.55 * Math.sin(an) - 0.83 * Math.cos(an);
    var x, y, i, d, nx, ny, px, py, qx, qy, l, sgx, sgy, t, u, slope, k, rim, nd, hl, sheen, c, kc, m, fx, fy, x0, y0, j, ins = Math.min(lw, lh);
    var hw = lw / 2, hh = lh / 2;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      i = y * w + x; px = x + 0.5 - cx; py = y + 0.5 - cy;
      if (kind === "rect") {
        qx = Math.abs(px) - (hw - rad); qy = Math.abs(py) - (hh - rad);
        l = Math.sqrt(Math.max(qx, 0) * Math.max(qx, 0) + Math.max(qy, 0) * Math.max(qy, 0));
        d = -(l + Math.min(Math.max(qx, qy), 0) - rad);
        if (d < -0.6) continue;
        sgx = px >= 0 ? 1 : -1; sgy = py >= 0 ? 1 : -1;
        if (qx > 0 || qy > 0) { nx = sgx * Math.max(qx, 0) / (l || 1); ny = sgy * Math.max(qy, 0) / (l || 1); }
        else if (qx > qy) { nx = sgx; ny = 0; } else { nx = 0; ny = sgy; }
      } else {
        m = s / RU;   // local px per reference px
        fx = REF / 2 + px / m - 0.5; fy = REF / 2 + py / m - 0.5;
        if (fx < 0 || fy < 0 || fx >= REF - 1 || fy >= REF - 1) continue;
        x0 = fx | 0; y0 = fy | 0; fx -= x0; fy -= y0; j = y0 * REF + x0;
        d = ((ref.sd[j] * (1 - fx) + ref.sd[j + 1] * fx) * (1 - fy) + (ref.sd[j + REF] * (1 - fx) + ref.sd[j + REF + 1] * fx) * fy) * m;
        if (d < -0.6) continue;
        nx = (ref.gx[j] * (1 - fx) + ref.gx[j + 1] * fx) * (1 - fy) + (ref.gx[j + REF] * (1 - fx) + ref.gx[j + REF + 1] * fx) * fy;
        ny = (ref.gy[j] * (1 - fx) + ref.gy[j + 1] * fx) * (1 - fy) + (ref.gy[j + REF] * (1 - fx) + ref.gy[j + REF + 1] * fx) * fy;
        l = Math.sqrt(nx * nx + ny * ny) || 1; nx /= l; ny /= l;
      }
      A[i] = clamp(d + 0.5, 0, 1);
      // rounded bevel: steep at the rim, flat inside
      t = clamp(Math.max(d, 0) / B, 0, 1); u = 1 - t;
      slope = u / Math.sqrt(Math.max(0.01, 1 - u * u)); if (slope > 3) slope = 3;
      k = slope / Math.sqrt(slope * slope + 1);
      nx *= k; ny *= k;
      for (c = 0; c < 3; c++) {
        kc = 1 + (1 - c) * disp;
        DX[c][i] = -px * zoom - nx * R * kc; DY[c][i] = -py * zoom - ny * R * kc;
      }
      rim = 1 - 1 / Math.sqrt(slope * slope + 1); rim = rim * Math.sqrt(rim);
      nd = (nx * Lx + ny * Ly) / (k || 1);
      hl = rim * (0.16 + 0.95 * Math.max(nd, 0) * Math.max(nd, 0) + 0.45 * Math.max(-nd, 0) * Math.max(-nd, 0));
      hl += Math.exp(-Math.max(0, d) / ew) * (0.15 + 0.7 * Math.max(nd, 0) + 0.35 * Math.max(-nd, 0));
      sheen = 1 - Math.sqrt(Math.pow((px + hw * 0.4) / (hw * 0.9 + 1), 2) + Math.pow((py + hh * 0.64) / (hh * 0.56 + 1), 2));
      if (sheen > 0) hl += sheen * 0.1;
      HL[i] = Math.min(1, hl * li);
    }
    // the soft shadow, from the coverage
    var mc = document.createElement("canvas"); mc.width = w; mc.height = h;
    var mg = mc.getContext("2d"), id = mg.createImageData(w, h);
    for (i = 0; i < N; i++) id.data[i * 4 + 3] = A[i] * 255;
    mg.putImageData(id, 0, 0);
    var sp = Math.round(ins * 0.12 + 8), shc = document.createElement("canvas"); shc.width = w + sp * 2; shc.height = h + sp * 2;
    var sg = shc.getContext("2d"); sg.filter = "blur(" + Math.round(sp * 0.45) + "px)"; sg.drawImage(mc, sp, sp); sg.filter = "none";
    if (!Ren.out) Ren.out = document.createElement("canvas");
    Ren.out.width = w; Ren.out.height = h;
    // what never changes between frames: the covered pixels, and for each color where it is read from
    // (the glass only ever moves by whole pixels, so the integer offset and the blend weights stay the same)
    var cnt = 0;
    for (i = 0; i < N; i++) if (A[i] > 0) cnt++;
    var IDX = new Int32Array(cnt), AL = new Uint8ClampedArray(cnt), OFF = [new Int32Array(cnt), new Int32Array(cnt), new Int32Array(cnt)], WX = [new Float32Array(cnt), new Float32Array(cnt), new Float32Array(cnt)], WY = [new Float32Array(cnt), new Float32Array(cnt), new Float32Array(cnt)];
    var IXs = [new Int32Array(cnt), new Int32Array(cnt), new Int32Array(cnt)], IYs = [new Int32Array(cnt), new Int32Array(cnt), new Int32Array(cnt)];
    var minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9, n2 = 0, fxv, fyv, ixv, iyv;
    for (i = 0; i < N; i++) {
      if (A[i] <= 0) continue;
      x = i % w; y = (i / w) | 0;
      IDX[n2] = i; AL[n2] = A[i] * 255;
      for (c = 0; c < 3; c++) {
        fxv = x + DX[c][i]; fyv = y + DY[c][i]; ixv = Math.floor(fxv); iyv = Math.floor(fyv);
        IXs[c][n2] = ixv; IYs[c][n2] = iyv; WX[c][n2] = fxv - ixv; WY[c][n2] = fyv - iyv;
        OFF[c][n2] = iyv * RW * 4 + ixv * 4 + c;
        if (ixv < minX) minX = ixv; if (ixv > maxX) maxX = ixv; if (iyv < minY) minY = iyv; if (iyv > maxY) maxY = iyv;
      }
      n2++;
    }
    Ren.lay = { w: w, h: h, A: A, HL: HL, DX: DX, DY: DY, shadow: shc, sp: sp, img: Ren.out.getContext("2d").createImageData(w, h), ins: ins,
      n: cnt, IDX: IDX, AL: AL, OFF: OFF, WX: WX, WY: WY, IX: IXs, IY: IYs, HLs: (function () { var h2 = new Float32Array(cnt), k; for (k = 0; k < cnt; k++) h2[k] = HL[IDX[k]]; return h2; })(),
      box: [minX, maxX, minY, maxY] };
    Ren.layKey = key;
    return Ren.lay;
  }

  // the preview of the After Effects animation
  function animXf(P, t) {
    var a = P.anim, k, sc = 1, dx = 0, dy = 0, rot = 0;
    if (a === "pop") { k = (t % 3) / 0.5; if (k < 1) { sc = k < 0.6 ? 1.12 * Math.sin(k / 0.6 * Math.PI / 2) : 1.12 - 0.12 * Math.sin((k - 0.6) / 0.4 * Math.PI / 2); } }
    else if (a === "float") { dx = Math.sin(t * 1.6) * 3; dy = Math.sin(t * 2.1 + 1) * 7; rot = Math.sin(t * 1.3) * 2; }
    else if (a === "pulse") sc = 1 + 0.045 * Math.sin(t * 3.2);
    else if (a === "spin") rot = (t * 90) % 360;
    return { sc: Math.max(0.001, sc), dx: dx, dy: dy, rot: rot * Math.PI / 180 };
  }

  function renderGlass(cv, P, t) {
    if (cv.width !== RW || cv.height !== RH) { cv.width = RW; cv.height = RH; cv.__glDone = false; }
    ensureScene(P);
    var L = layout(P), g = cv.getContext("2d"), W = RW, H = RH, cx, cy;
    if (Ren.drift) { cx = W * (0.5 + 0.05 * Math.sin(t * 0.55)); cy = H * (0.5 + 0.04 * Math.sin(t * 0.8 + 1.2)); }
    else { cx = Ren.cx * W; cy = Ren.cy * H; }
    var X = animXf(P, t);
    cx += X.dx; cy += X.dy;
    Ren.last = { cx: cx / W, cy: cy / H };
    var w = L.w, h = L.h, ox = Math.round(cx - w / 2), oy = Math.round(cy - h / 2);
    var fk = [Ren.layKey, Ren.srcKey, ox, oy, X.rot.toFixed(4), X.sc.toFixed(4), P.tint, P.tintAmt, P.shadow, cv.__gl].join("|");
    if (fk === Ren.lastFrame && cv.__glDone) return;
    Ren.lastFrame = fk; cv.__glDone = true;
    g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1;
    g.drawImage(Ren.scene, 0, 0);
    function place() { g.setTransform(1, 0, 0, 1, 0, 0); g.translate(ox + w / 2, oy + h / 2); g.rotate(X.rot); g.scale(X.sc, X.sc); g.translate(-(ox + w / 2), -(oy + h / 2)); }
    if (P.shadow > 0) {
      place(); g.globalAlpha = clamp(P.shadow, 0, 100) / 100 * 0.85;
      g.drawImage(L.shadow, ox - L.sp, oy - L.sp + L.ins * 0.07 + 2);
      g.globalAlpha = 1; g.setTransform(1, 0, 0, 1, 0, 0);
    }
    var od = L.img.data, src = Ren.src, tc = U.hexToRgb(P.tint), ta = clamp(P.tintAmt, 0, 100) / 100;
    var t0 = tc[0] * ta, t1 = tc[1] * ta, t2 = tc[2] * ta, keep = 1 - ta, n = L.n, k, j, c, a, v, hl, fx, fy, W4 = W * 4, col = [0, 0, 0], base = oy * W4 + ox * 4;
    var bx = L.box, safe = ox + bx[0] >= 0 && ox + bx[1] + 1 <= W - 1 && oy + bx[2] >= 0 && oy + bx[3] + 1 <= H - 1;
    var OFF = L.OFF, WX = L.WX, WY = L.WY, IX = L.IX, IY = L.IY, IDX = L.IDX, AL = L.AL, HLs = L.HLs, sx, sy;
    for (k = 0; k < n; k++) {
      for (c = 0; c < 3; c++) {
        fx = WX[c][k]; fy = WY[c][k];
        if (safe) a = base + OFF[c][k];
        else {
          // near the edge of the preview: clamp like before
          sx = ox + IX[c][k] + fx; sy = oy + IY[c][k] + fy;
          if (sx < 0) sx = 0; else if (sx > W - 1.001) sx = W - 1.001;
          if (sy < 0) sy = 0; else if (sy > H - 1.001) sy = H - 1.001;
          a = (sy | 0) * W4 + (sx | 0) * 4 + c; fx = sx - (sx | 0); fy = sy - (sy | 0);
        }
        v = (src[a] * (1 - fx) + src[a + 4] * fx) * (1 - fy) + (src[a + W4] * (1 - fx) + src[a + W4 + 4] * fx) * fy;
        col[c] = v * keep;
      }
      hl = HLs[k]; j = IDX[k] * 4;
      v = col[0] + t0; od[j] = v + (255 - v) * hl;
      v = col[1] + t1; od[j + 1] = v + (255 - v) * hl;
      v = col[2] + t2; od[j + 2] = v + (255 - v) * hl;
      od[j + 3] = AL[k];
    }
    Ren.out.getContext("2d").putImageData(L.img, 0, 0);
    place();
    g.drawImage(Ren.out, ox, oy);
    g.setTransform(1, 0, 0, 1, 0, 0);
  }

  // ------------------------------------------------------------------ gallery tiles (drawn once)
  function drawTile(cv, sh) {
    var d = 2, n = 52 * d, g;
    cv.width = n; cv.height = n;
    g = cv.getContext("2d");
    g.save();
    if (sh[2] === "rect") {
      var dd = sh[3], ar = (dd.w * 16) / (dd.h * 9), bw = ar >= 1 ? n * 0.66 : n * 0.66 * ar, bh = ar >= 1 ? n * 0.66 / ar : n * 0.66;
      g.beginPath(); U.rrect(g, (n - bw) / 2, (n - bh) / 2, bw, bh, dd.rad / 100 * Math.min(bw, bh) / 2);
    } else if (sh[2] === "layer") {
      g.font = "800 " + (n * 0.4) + "px Outfit, -apple-system, Helvetica, sans-serif"; g.textAlign = "center"; g.textBaseline = "middle";
    } else {
      g.beginPath(); sh[3].paths.forEach(function (p) { tracePath(g, p, n * 0.0058, n / 2, n / 2); });
    }
    var gr = g.createLinearGradient(0, n * 0.15, n * 0.4, n * 0.9);
    gr.addColorStop(0, "rgba(255,255,255,.78)"); gr.addColorStop(0.55, "rgba(255,255,255,.26)"); gr.addColorStop(1, "rgba(255,255,255,.42)");
    g.shadowColor = "rgba(0,0,0,.35)"; g.shadowBlur = 6; g.shadowOffsetY = 3;
    g.fillStyle = gr;
    if (sh[2] === "layer") g.fillText("Aa", n / 2, n / 2 + 2); else g.fill();
    g.shadowColor = "transparent";
    g.lineWidth = 1.4; g.strokeStyle = "rgba(255,255,255,.9)";
    if (sh[2] === "layer") g.strokeText("Aa", n / 2, n / 2 + 2); else g.stroke();
    g.restore();
  }

  // ------------------------------------------------------------------ the user's own icons
  function userFile() { var F = E && E.files && E.files(); return F ? { F: F, p: F.path.join(F.data, "glass-icons.json") } : null; }
  function loadUser() {
    var u = userFile(), list = [];
    if (!u) return;
    try { if (u.F.fs.existsSync(u.p)) list = JSON.parse(u.F.fs.readFileSync(u.p, "utf8")).icons || []; } catch (e) { list = []; }
    USER = list.filter(function (x) { return x && x.k && x.paths && x.paths.length; }).map(function (x) { return [x.k, x.label || "Icon", "path", { paths: x.paths, thick: x.thick || 0.15, round: 0 }]; });
    reshape();
  }
  function saveUser() {
    var u = userFile();
    if (!u) return false;
    try {
      u.F.mkdirp(u.F.data);
      u.F.fs.writeFileSync(u.p, JSON.stringify({ v: 1, icons: USER.map(function (x) { return { k: x[0], label: x[1], paths: x[3].paths, thick: x[3].thick }; }) }));
      return true;
    } catch (e) { return false; }
  }
  function niceName(f) {
    return String(f).replace(/\.[a-z0-9]+$/i, "").replace(/^icons8[-_]/i, "").replace(/[-_]\d+(-\d+)?$/, "").replace(/[-_]+/g, " ").replace(/\b\w/g, function (c) { return c.toUpperCase(); }).slice(0, 28) || "Icon";
  }
  // PNG / SVG files -> traced icons in "My icons"
  function importFiles(files) {
    var list = Array.prototype.slice.call(files || []).filter(function (f) { return /\.(png|svg|jpe?g|webp)$/i.test(f.name); }), done = 0, added = 0, last = "";
    if (!list.length) return;
    function next() {
      if (done >= list.length) {
        saveUser(); refreshMine();
        if (last) setShape(last);
        if (E.toast) E.toast(added ? "Added " + added + " icon" + (added > 1 ? "s" : "") + " to My icons" : "No shape found in those pictures");
        return;
      }
      var f = list[done++], url = URL.createObjectURL(f), img = new Image();
      img.onload = function () {
        var t = null;
        try { t = IC.trace(img); } catch (e) { t = null; }
        URL.revokeObjectURL(url);
        if (t && t.paths.length) {
          var k = "u-" + Date.now().toString(36) + "-" + done;
          USER.push([k, niceName(f.name), "path", { paths: t.paths, thick: t.thick, round: 0 }]);
          reshape(); added++; last = k;
        }
        setTimeout(next, 0);
      };
      img.onerror = function () { URL.revokeObjectURL(url); setTimeout(next, 0); };
      img.src = url;
    }
    next();
  }
  function removeUser(k) {
    USER = USER.filter(function (x) { return x[0] !== k; }); reshape(); saveUser();
    if (st.shape === k) setShape(DEF.shape); else refreshMine();
  }
  function refreshMine() {
    if (!ui.mineBox) return;
    ui.tiles = ui.tiles.filter(function (b) { return !b.__user; });
    ui.mineBox.innerHTML = "";
    var grid = gallery(USER, true);
    var add = mk("button", "gtile gadd", "<span>+</span>"); add.type = "button"; add.title = "Add icons (PNG or SVG)"; add.setAttribute("aria-label", "Add icons");
    add.addEventListener("click", function () { ui.picker.value = ""; ui.picker.click(); });
    grid.appendChild(add);
    ui.mineBox.appendChild(grid);
    ui.tiles.forEach(function (b) { b.classList.toggle("on", b.dataset.k === st.shape); });
  }

  // ------------------------------------------------------------------ the shared icon pack
  // The pack is plain data (outlines as numbers), checked piece by piece before it is used; it never carries code.
  var PACK_EVERY = 6 * 3600 * 1000, packInfo = { version: "", at: 0 };
  function num(v) { return typeof v === "number" && isFinite(v) && Math.abs(v) < 1e4; }
  function cleanPack(o) {
    if (!o || typeof o !== "object" || !Array.isArray(o.icons) || o.icons.length > 2000) return null;
    var out = [];
    o.icons.forEach(function (x, n) {
      if (!x || !Array.isArray(x.paths) || !x.paths.length || x.paths.length > 64) return;
      var ok = x.paths.every(function (p) {
        if (!p || !Array.isArray(p.v) || p.v.length < 2 || p.v.length > 4000 || !Array.isArray(p.i) || !Array.isArray(p.o) || p.i.length !== p.v.length || p.o.length !== p.v.length) return false;
        return [p.v, p.i, p.o].every(function (a) { return a.every(function (q) { return Array.isArray(q) && q.length === 2 && num(q[0]) && num(q[1]); }); });
      });
      if (!ok) return;
      var key = "p-" + String(x.k || n).replace(/[^a-z0-9_-]/gi, "").slice(0, 40), label = String(x.label || "Icon").replace(/[<>&"'`]/g, "").slice(0, 32) || "Icon";
      out.push([key, label, "path", { paths: x.paths.map(function (p) { return { v: p.v, i: p.i, o: p.o, c: 1 }; }), thick: num(x.thick) ? Math.max(0.02, Math.min(0.5, x.thick)) : 0.15, round: 0 }]);
    });
    return out;
  }
  function packFile() { var F = E && E.files && E.files(); return F ? { F: F, p: F.path.join(F.data, "glass-pack.json") } : null; }
  function loadPack() {
    var u = packFile();
    if (!u) return;
    try {
      if (!u.F.fs.existsSync(u.p)) return;
      var o = JSON.parse(u.F.fs.readFileSync(u.p, "utf8")), list = cleanPack(o);
      if (list) { PACK = list; packInfo = { version: String(o.version || ""), at: +o.fetchedAt || 0 }; reshape(); }
    } catch (e) {}
  }
  // the pack sits next to update.json on every update mirror; the first mirror that answers wins
  function packUrls() {
    var cfg = window.HYDRA_UPDATE || {}, out = [];
    (cfg.feeds || []).forEach(function (f) { var b = String(f).replace(/update\.json.*$/, "") + "packs/glass-icons.json"; if (out.indexOf(b) < 0) out.push(b); });
    return out;
  }
  function getText(url) {
    if (window.__hydraPackGet) return window.__hydraPackGet(url);   // tests
    var Up = window.HydraUpdate;
    if (!Up || !window.require) return Promise.reject(new Error("offline"));
    return Up.httpGet(Up.defaultDeps(window.require), url + "?t=" + Math.floor(Date.now() / 600000), { maxBytes: 16 * 1048576, totalMs: 60000 }).then(function (b) { return String(b); });
  }
  function refreshPack(force) {
    if (!force && Date.now() - packInfo.at < PACK_EVERY) return Promise.resolve(false);
    var urls = packUrls(), i = 0;
    function next() {
      if (i >= urls.length) return Promise.resolve(false);
      var u = urls[i++];
      return getText(u).then(function (txt) {
        var o = JSON.parse(txt), list = cleanPack(o);
        if (!list) return next();
        var changed = String(o.version || "") !== packInfo.version || list.length !== PACK.length;
        packInfo = { version: String(o.version || ""), at: Date.now() };
        var pf = packFile();
        if (pf) { try { pf.F.mkdirp(pf.F.data); o.fetchedAt = packInfo.at; pf.F.fs.writeFileSync(pf.p, JSON.stringify(o)); } catch (e) {} }
        if (changed) { PACK = list; reshape(); refreshPackBox(); }
        return changed;
      }, function () { return next(); });
    }
    return next();
  }
  function refreshPackBox() {
    if (!ui.packBox) return;
    ui.tiles = ui.tiles.filter(function (b) { return !b.__pack; });
    ui.packBox.innerHTML = "";
    ui.packHead.style.display = PACK.length ? "" : "none";
    if (!PACK.length) return;
    var grid = gallery(PACK, false);
    Array.prototype.forEach.call(grid.children, function (b) { b.__pack = true; });
    ui.packBox.appendChild(grid);
    ui.tiles.forEach(function (b) { b.classList.toggle("on", b.dataset.k === st.shape); });
  }

  // ------------------------------------------------------------------ the pane
  var st, ui = {}, sl = {};

  function kind() { return shapeOf(st.shape)[2]; }
  function r4(v) { return Math.round(v * 1000) / 1000; }
  function toHost() {
    var sh = shapeOf(st.shape), k = sh[2], tc = U.hexToRgb(st.tint);
    var o = {
      kind: k, name: st.name || "Liquid Glass", look: st.look, anim: st.anim,
      glass: st.glass, bevel: U.round(st.bevel / 100, 4), frost: st.frost, zoom: st.zoom, tintAmt: st.tintAmt,
      tint: [U.round(tc[0] / 255, 4), U.round(tc[1] / 255, 4), U.round(tc[2] / 255, 4)],
      light: st.light, angle: st.angle, edge: st.edge, shadow: st.shadow, prism: !!st.prism
    };
    if (k === "rect") {
      o.w = U.round(st.w, 4); o.h = U.round(st.h, 4); o.rad = U.round(st.rad / 100, 4);
      // the same sizes in units of the comp's short side (the preview is 16:9, so its short side is its height):
      // a circle stays a circle and a square a square in a portrait, square or landscape comp
      o.ws = U.round(st.w * 16 / 9, 4); o.hs = U.round(st.h, 4);
    }
    if (k === "path") {
      o.name = "Glass " + sh[1];
      o.size = U.round(st.size / 100, 4); o.round = st.round; o.thick = sh[3].thick;
      o.paths = sh[3].paths.map(function (p) {
        var f = function (q) { return [r4(q[0]), r4(q[1])]; };
        return { v: p.v.map(f), i: p.i.map(f), o: p.o.map(f), c: 1 };
      });
    }
    return o;
  }

  // a Liquid Glass selected in the comp (its null or any of its layers): the sliders change it live
  function selGlass() { var s = E && E.sel(); return s && s.glass ? String(s.glass) : ""; }
  var live = { t: 0, busy: false, again: false };
  function pushLive() {
    if (!selGlass() || E.gate()) return;
    clearTimeout(live.t);
    live.t = setTimeout(function send() {
      if (live.busy) { live.again = true; return; }
      live.busy = true;
      E.call("ops_glassUpdate", toHost()).then(function () {
        live.busy = false;
        if (live.again) { live.again = false; send(); }
      }, function () { live.busy = false; });
    }, 220);
  }

  function title() { return "Liquid Glass · " + lookOf(st.look)[1] + " · " + shapeOf(st.shape)[1]; }
  function tag() {
    var k = kind();
    ui.pstage.tag.textContent = k === "rect" ? Math.round(st.w * 1920) + " × " + Math.round(st.h * 1080) : k === "path" ? Math.round(st.size * 10.8) + " px" : "your layer";
  }
  function sync() {
    var k = kind();
    ui.pstage.name.textContent = title();
    tag();
    ui.rectBox.style.display = k === "rect" ? "" : "none";
    ui.pathBox.style.display = k === "path" ? "" : "none";
    ui.layerNote.style.display = k === "layer" ? "" : "none";
    ui.sizeRow.style.display = k === "rect" ? "none" : "";
    Object.keys(sl).forEach(function (key) { var s = sl[key]; s.set(s.scale ? Math.round(st[key] * s.scale) : st[key]); });
    ui.prism.set(!!st.prism);
    ui.sw.set(st.tint);
    ui.anim.set(st.anim);
    ui.lookBtns.forEach(function (b) { b.classList.toggle("on", b.dataset.k === st.look); });
    ui.tiles.forEach(function (b) { b.classList.toggle("on", b.dataset.k === st.shape); });
    E.dockChanged();
  }

  function slider(label, key, min, max, step, fmt, scale) {
    var s = U.slider({
      label: label, min: min, max: max, step: step, value: scale ? Math.round(st[key] * scale) : st[key], def: scale ? Math.round(DEF[key] * scale) : DEF[key], fmt: fmt,
      onInput: function (v) { st[key] = scale ? v / scale : v; tag(); },
      onChange: function () { E.save(); E.dockChanged(); pushLive(); }
    });
    s.scale = scale;
    sl[key] = s;
    return s.el;
  }

  function setLook(k) {
    var L = lookOf(k)[2];
    st.look = k;
    LOOK_KEYS.forEach(function (key) { st[key] = L[key]; });
    st.angle = DEF.angle; st.edge = DEF.edge;
    sync(); E.save(); pushLive();
  }
  function setShape(k) {
    var sh = shapeOf(k);
    st.shape = k;
    if (sh[2] === "rect") { st.w = sh[3].w; st.h = sh[3].h; st.rad = sh[3].rad; }
    if (sh[2] === "path") st.round = sh[3].round;
    sync(); E.save(); pushLive();
  }

  function frame(t) { if (ui.pstage) renderGlass(ui.pstage.cv, st, t); }

  // tiles are drawn the first time they scroll into view (opening the tab stays quick with a big icon library)
  var tileIO = null;
  function lazyTile(b, cv, s) {
    if (!window.IntersectionObserver) { drawTile(cv, s); return; }
    if (!tileIO) {
      tileIO = new IntersectionObserver(function (es) {
        es.forEach(function (e) { if (e.isIntersecting && e.target.__draw) { e.target.__draw(); e.target.__draw = null; tileIO.unobserve(e.target); } });
      }, { rootMargin: "200px 0px" });
    }
    b.__draw = function () { drawTile(cv, s); };
    tileIO.observe(b);
  }
  function gallery(list, user) {
    var box = mk("div", "ggrid");
    list.forEach(function (s) {
      var b = mk("button", "gtile"), cv = mk("canvas");
      b.type = "button"; b.dataset.k = s[0]; b.title = s[1] + (user ? " · right-click to remove" : ""); b.setAttribute("aria-label", s[1]);
      b.appendChild(cv);
      lazyTile(b, cv, s);
      b.addEventListener("click", function () { setShape(s[0]); });
      if (user) {
        b.__user = true;
        b.addEventListener("contextmenu", function (e) { e.preventDefault(); if (window.confirm("Remove “" + s[1] + "” from My icons?")) removeUser(s[0]); });
      }
      box.appendChild(b); ui.tiles.push(b);
    });
    return box;
  }

  function sanitize() {
    var k;
    for (k in DEF) if (DEF.hasOwnProperty(k) && typeof st[k] !== typeof DEF[k]) st[k] = DEF[k];
    ["w", "h", "rad", "size", "round", "glass", "bevel", "frost", "tintAmt", "light", "angle", "edge", "shadow", "zoom"].forEach(function (k2) { if (isNaN(st[k2])) st[k2] = DEF[k2]; });
    if (!LOOKS.some(function (l) { return l[0] === st.look; })) st.look = DEF.look;
    if (!SHAPES.some(function (s) { return s[0] === st.shape; })) st.shape = DEF.shape;
    if (!ANIMS.some(function (s) { return s[0] === st.anim; })) st.anim = DEF.anim;
    if (!/^#[0-9a-f]{6}$/i.test(st.tint)) st.tint = DEF.tint;
    if (!BGS.some(function (b) { return b[0] === st.bg; })) st.bg = "aurora";
    delete st.style;   // the 0.17 look ("1" / "2" / "3")
  }

  function build(el) {
    E = U.env();
    st = S.store("glass", DEF);
    if (st.look === undefined || st.style !== undefined) { Object.keys(DEF).forEach(function (k) { if (k !== "bg" && k !== "name") st[k] = DEF[k]; }); }
    loadUser();
    loadPack();
    sanitize();
    ui.tiles = [];

    ui.pstage = U.stage(56.25);
    U.dock(ui.pstage, el);
    ui.pstage.el.style.cursor = "grab";
    // drag the glass around the preview (double-click lets it float again)
    ui.pstage.el.addEventListener("mousedown", function (e) {
      var r = ui.pstage.cv.getBoundingClientRect(), last = Ren.last || { cx: 0.5, cy: 0.5 };
      Ren.drift = false; Ren.cx = last.cx; Ren.cy = last.cy;
      var sx = e.clientX, sy = e.clientY, ox = Ren.cx, oy = Ren.cy;
      ui.pstage.el.style.cursor = "grabbing";
      function move(ev) { Ren.cx = clamp(ox + (ev.clientX - sx) / r.width, 0.04, 0.96); Ren.cy = clamp(oy + (ev.clientY - sy) / r.height, 0.04, 0.96); }
      function up() { document.removeEventListener("mousemove", move); document.removeEventListener("mouseup", up); ui.pstage.el.style.cursor = "grab"; }
      document.addEventListener("mousemove", move); document.addEventListener("mouseup", up);
      e.preventDefault();
    });
    ui.pstage.el.addEventListener("dblclick", function () { Ren.drift = true; });

    el.appendChild(U.head("Look"));
    el.appendChild(U.note("Select a glass you made (its Controls null) and every change here goes straight to it."));
    var lp = mk("div", "xpills"); ui.lookBtns = [];
    LOOKS.forEach(function (s) {
      var b = mk("button", "xpill", esc(s[1])); b.type = "button"; b.dataset.k = s[0];
      b.addEventListener("click", function () { setLook(s[0]); });
      lp.appendChild(b); ui.lookBtns.push(b);
    });
    el.appendChild(lp);

    el.appendChild(U.head("Panels"));
    el.appendChild(gallery(PANELS));
    el.appendChild(U.head("Icons"));
    el.appendChild(gallery(ICONS));
    ui.packHead = U.head("Icon pack");
    el.appendChild(ui.packHead);
    ui.packBox = mk("div");
    el.appendChild(ui.packBox);
    refreshPackBox();
    setTimeout(function () { refreshPack(false); }, 1500);   // a newer pack comes in quietly
    el.appendChild(U.head("My icons"));
    ui.mineBox = mk("div");
    ui.picker = mk("input"); ui.picker.type = "file"; ui.picker.multiple = true; ui.picker.accept = ".png,.svg,.jpg,.jpeg,.webp,image/png,image/svg+xml"; ui.picker.style.display = "none";
    ui.picker.addEventListener("change", function () { importFiles(ui.picker.files); });
    el.appendChild(ui.picker);
    el.appendChild(ui.mineBox);
    refreshMine();
    el.appendChild(U.note("Add your own icons: PNG or SVG, one icon per file, on a transparent background (or black on white). Each one is traced into a vector shape and kept in My icons."));
    el.appendChild(U.head("Your own layer"));
    el.appendChild(gallery(MINE));

    var c1 = mk("div", "card2");
    ui.rectBox = mk("div");
    ui.rectBox.appendChild(slider("Width", "w", 8, 140, 1, function (v) { return Math.round(v) + " %"; }, 100));
    ui.rectBox.appendChild(slider("Height", "h", 4, 140, 1, function (v) { return Math.round(v) + " %"; }, 100));
    ui.rectBox.appendChild(slider("Roundness", "rad", 0, 100, 1, function (v) { return v >= 100 ? "Round" : Math.round(v) + " %"; }));
    c1.appendChild(ui.rectBox);
    ui.sizeRow = mk("div");
    ui.sizeRow.appendChild(slider("Size", "size", 8, 120, 1, function (v) { return Math.round(v) + " %"; }));
    c1.appendChild(ui.sizeRow);
    ui.pathBox = mk("div");
    ui.pathBox.appendChild(slider("Corners", "round", 0, 20, 1, function (v) { return v === 0 ? "Sharp" : String(v); }));
    c1.appendChild(ui.pathBox);
    ui.layerNote = U.note("Select one shape or text layer in your comp and press Create: its outline becomes the glass (text is turned into shapes first). Your layer is hidden, not deleted. The preview shows a stand-in word.");
    c1.appendChild(ui.layerNote);
    var ar = mk("div", "xchoice"); ar.appendChild(mk("span", "", "Animate"));
    ui.anim = U.seg(ANIMS, st.anim, function (v) { st.anim = v; E.save(); pushLive(); }, "mini"); ar.appendChild(ui.anim.el);
    c1.appendChild(ar);
    el.appendChild(c1);

    el.appendChild(U.head("Glass", U.ghostBtn("Reset", function () { setLook(st.look); }, "Back to this look's settings")));
    var c2 = mk("div", "card2");
    c2.appendChild(slider("Bend", "glass", 0, 250, 1, function (v) { return Math.round(v) + " %"; }));
    c2.appendChild(slider("Bevel", "bevel", 4, 120, 1, function (v) { return v >= 100 ? "Dome" : Math.round(v) + " %"; }));
    c2.appendChild(slider("Frost", "frost", 0, 60, 1, function (v) { return v === 0 ? "Clear" : String(Math.round(v)); }));
    c2.appendChild(slider("Zoom", "zoom", 0, 60, 1, function (v) { return v === 0 ? "Off" : Math.round(v) + " %"; }));
    c2.appendChild(slider("Light", "light", 0, 200, 1, function (v) { return Math.round(v) + " %"; }));
    c2.appendChild(slider("Angle", "angle", -180, 180, 1, function (v) { return Math.round(v) + "°"; }));
    c2.appendChild(slider("Edge", "edge", 0, 20, 1, function (v) { return String(Math.round(v)); }));
    c2.appendChild(slider("Shadow", "shadow", 0, 100, 1, function (v) { return v === 0 ? "Off" : Math.round(v) + " %"; }));
    var tb = mk("div", "xchoice"); tb.appendChild(mk("span", "", "Tint"));
    ui.sw = U.swatches(TINTS, st.tint, function (v) { st.tint = v; E.save(); pushLive(); }, true); tb.appendChild(ui.sw.el);
    c2.appendChild(tb);
    c2.appendChild(slider("Tint amount", "tintAmt", 0, 80, 1, function (v) { return Math.round(v) + " %"; }));
    ui.prism = U.toggle("Prism edges (rainbow fringe)", !!st.prism, function (v) { st.prism = v; E.save(); });
    c2.appendChild(ui.prism.el);
    el.appendChild(c2);

    el.appendChild(U.head("Preview background"));
    var bgc = mk("div", "card2");
    ui.bgSeg = U.seg(BGS, st.bg, function (v) { st.bg = v; E.save(); });
    bgc.appendChild(ui.bgSeg.el);
    el.appendChild(bgc);
    el.appendChild(U.note("Glass only shows what is behind it: put it over footage, a photo or colors. In After Effects the “Controls” null is the master: move, scale or rotate it to place the glass, and use its sliders for the look. Drag the glass around the preview; double-click lets it float again."));
    sync();
    frame(0.6);
  }

  S.register("glass", {
    title: "Glass", rgb: [50, 173, 230], icon: "glass", build: build, frame: frame,
    show: function () { frame(0.6); },
    dock: function () {
      var g = E.gate(), s = E.sel(), hint, ok, k = st ? kind() : "rect", gl = s && s.glass;
      if (!g && s.hasComp && gl) return { name: "Update “" + gl + "”", hint: "→ the sliders change the selected glass live", ok: true, label: "Update" };
      if (g) { hint = g; ok = false; }
      else if (!s.hasComp) { hint = "Open a composition first"; ok = false; }
      else if (k === "layer") { ok = s.total === 1; hint = ok ? "→ your selected layer becomes glass" : "Select one shape or text layer"; }
      else { ok = true; hint = s.total > 0 ? "→ glass above your selection" : "→ glass over the whole composition"; }
      return { name: st ? title() : "Liquid Glass", hint: hint, ok: ok, label: "Create" };
    },
    apply: function () {
      var g = E.gate();
      if (g) return Promise.resolve({ ok: false, msg: g });
      if (selGlass()) {
        return E.call("ops_glassUpdate", toHost()).then(function (r) {
          if (r && r.ok) { var w = r.warnings || []; return { ok: true, msg: "Updated “" + r.name + "”", warn: w[0], done: "Updated" }; }
          return { ok: false, msg: (r && r.error) || "Could not update the glass" };
        });
      }
      return E.call("ops_glassShape", toHost()).then(function (r) {
        if (r && r.ok) {
          var w = r.warnings || [];
          return { ok: true, msg: "Created “" + r.name + "” · " + r.layers + " layers" + (w.length ? " · " + w.length + " note" + (w.length > 1 ? "s" : "") : ""), warn: w[0], done: "Created" };
        }
        return { ok: false, msg: (r && r.error) || "Could not build the glass" };
      });
    }
  });
  S._glass = { renderGlass: renderGlass, toHost: function () { return toHost(); }, shapes: function () { return SHAPES; }, looks: LOOKS, importFiles: function (f) { importFiles(f); }, user: function () { return USER; },
    pack: function () { return PACK; }, refreshPack: function (f) { return refreshPack(f); } };
})();
